<template>
  <div :class="[`text-search-field-5-1`, className || ``]"><search-icon2 :spanText="searchIcon2Props.spanText" /></div>
</template>

<script>
import SearchIcon2 from "./SearchIcon2";
export default {
  name: "Textsearchfield7",
  components: {
    SearchIcon2,
  },
  props: ["className", "searchIcon2Props"],
};
</script>

<style>
.text-search-field-5-1 {
  display: flex;
  height: 103px;
  justify-content: center;
  margin-bottom: -0.24px;
  margin-left: 8px;
  position: relative;
  width: 160px;
}

.text-search-field-5-1.text-search-field-7,
.text-search-field-5-1.text-search-field-9 {
  display: flex;
  height: 103px;
  justify-content: center;
  margin-bottom: -0.24px;
  margin-left: 9px;
  position: relative;
  width: 160px;
}

.text-search-field-5-1.text-search-field-8 {
  display: flex;
  height: 103px;
  justify-content: center;
  margin-bottom: -0.24px;
  position: relative;
  width: 160px;
}
</style>
