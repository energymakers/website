import React from "react";
import "./TEXTSEARCHFIELD4.css";

function TEXTSEARCHFIELD4(props) {
  const { className } = props;

  return (
    <div className={`text-search-field-12 ${className || ""}`}>
      <div className="search-icon-8">
        <p className="ema-326-joseph-mwil gellix-regular-normal-white-12px-2">
          <span className="span-4 gellix-regular-normal-white-12px">
            EMA
            <br />
          </span>
          <span className="span-4 gellix-regular-normal-dull-lavender-12px">
            32/6 Joseph Mwilwa Rd
            <br />
            Rhodes Park
            <br />
            Lusaka — Zambia
            <br />
            <br />
            View on Google Maps
            <br />
            <br />
            Email us
            <br />
            EMA Press kit
          </span>
        </p>
      </div>
    </div>
  );
}

export default TEXTSEARCHFIELD4;
