import Vue from "vue";
import Router from "vue-router";
import Android17 from "./components/Android17";
import Android23 from "./components/Android23";
import Android25 from "./components/Android25";
import Android21 from "./components/Android21";
import Android24 from "./components/Android24";
import MobWebsite1 from "./components/MobWebsite1";
import Frame21 from "./components/Frame21";
import PhotoSelects from "./components/PhotoSelects";
import Frame17 from "./components/Frame17";
import {
  android17Data,
  android23Data,
  android25Data,
  android21Data,
  android24Data,
  mobWebsite1Data,
  frame21Data,
} from "./data";

Vue.use(Router);

export default new Router({
  mode: "history",
  routes: [
    {
      path: "/android-17",
      component: Android17,
      props: { ...android17Data },
    },
    {
      path: "/android-23",
      component: Android23,
      props: { ...android23Data },
    },
    {
      path: "/android-25",
      component: Android25,
      props: { ...android25Data },
    },
    {
      path: "/android-21",
      component: Android21,
      props: { ...android21Data },
    },
    {
      path: "/android-24",
      component: Android24,
      props: { ...android24Data },
    },
    {
      path: "/frame-21",
      component: Frame21,
      props: { ...frame21Data },
    },
    {
      path: "/photo-selects",
      component: PhotoSelects,
    },
    {
      path: "/frame-17",
      component: Frame17,
    },
    {
      path: "*",
      component: MobWebsite1,
      props: { ...mobWebsite1Data },
    },
  ],
});
