<template>
  <div class="frame-1">
    <img
      class="vector-25"
      src="https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-18@2x.png"
    />
  </div>
</template>

<script>
export default {
  name: "Frame",
};
</script>

<style>
.frame-1,
.frame-2,
.frame-3,
.frame-4 {
  align-items: flex-start;
  display: flex;
  height: 29.94px;
  overflow: hidden;
  width: 81.83px;
}

.vector-25,
.vector-27,
.vector-28,
.vector-29 {
  height: 30px;
  margin-top: -0.28px;
  width: 82px;
}
</style>
