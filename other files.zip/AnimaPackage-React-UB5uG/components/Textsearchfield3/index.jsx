import React from "react";
import "./Textsearchfield3.css";

function Textsearchfield3(props) {
  const { className } = props;

  return (
    <div className={`text-search-field-18 ${className || ""}`}>
      <div className="search-icon-14">
        <p className="social-media-faceb gellix-regular-normal-white-12px-2">
          <span className="span-10 gellix-regular-normal-white-12px">
            SOCIAL MEDIA
            <br />
          </span>
          <span className="span-10 gellix-regular-normal-dull-lavender-12px">
            ↗ Facebook
            <br />↗ Twitter
            <br />↗ LinkedIn
            <br />↗ YouTube
            <br />↗ Instagram
          </span>
        </p>
      </div>
    </div>
  );
}

export default Textsearchfield3;
