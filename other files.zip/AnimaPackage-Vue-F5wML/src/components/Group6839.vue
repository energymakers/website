<template>
  <div :class="[`group-6839-2`, className || ``]">
    <div class="group-6839-3">
      <div class="overlap-group-11">
        <textsearchfield4 :className="tEXTSEARCHFIELD4Props.className" />
        <img class="vector-41-1" :src="vector41" /><img class="vector-42-1" :src="vector42" />
      </div>
    </div>
  </div>
</template>

<script>
import Textsearchfield4 from "./Textsearchfield4";
export default {
  name: "Group6839",
  components: {
    Textsearchfield4,
  },
  props: ["vector41", "vector42", "className", "tEXTSEARCHFIELD4Props"],
};
</script>

<style>
.group-6839-2 {
  display: flex;
  height: 285px;
  left: 0;
  position: absolute;
  top: 0;
  width: 152px;
}

.group-6839-3 {
  align-items: flex-start;
  display: flex;
  min-width: 152px;
}

.overlap-group-11 {
  height: 285px;
  position: relative;
  width: 152px;
}

.vector-41-1 {
  height: 2px;
  left: 1px;
  position: absolute;
  top: 94px;
  width: 126px;
}

.vector-42-1 {
  height: 2px;
  left: 1px;
  position: absolute;
  top: 142px;
  width: 77px;
}

.group-6839-2.group-6839-4,
.group-6839-2.group-6839-4 .overlap-group-11 {
  height: 283px;
}

.group-6839-2.group-6839-4 .group-6839-3 {
  height: 282.69px;
}

.group-6839-2.group-6839-4 .vector-41-1 {
  top: 93px;
}

.group-6839-2.group-6839-4 .vector-42-1 {
  top: 141px;
}
</style>
