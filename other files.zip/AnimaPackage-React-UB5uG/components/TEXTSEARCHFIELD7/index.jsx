import React from "react";
import "./TEXTSEARCHFIELD7.css";

function TEXTSEARCHFIELD7() {
  return (
    <div className="text-search-field-23">
      <div className="search-icon-19">
        <div className="projects valign-text-middle gellix-regular-normal-white-18px">PROJECTS</div>
      </div>
    </div>
  );
}

export default TEXTSEARCHFIELD7;
