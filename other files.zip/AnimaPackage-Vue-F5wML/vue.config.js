module.exports = {
  publicPath : './'
}