import React from "react";
import "./SearchIcon.css";

function SearchIcon(props) {
  const { children } = props;

  return (
    <div className="search-icon-1">
      <div className="join-a-programme valign-text-middle gellix-regular-normal-minsk-12px">{children}</div>
    </div>
  );
}

export default SearchIcon;
