<template>
  <div class="group-6" id="group-6851">
    <p class="energy-makers-ac gellix-regular-normal-white-16px" v-html="energyMakersAcadem"></p>
  </div>
</template>

<script>
export default {
  name: "Group6851",
  props: ["energyMakersAcadem"],
};
</script>

<style>
.group-6 {
  display: flex;
  height: 170px;
  left: 0;
  position: absolute;
  top: 0;
  width: 330px;
}

.energy-makers-ac {
  height: 170px;
  letter-spacing: 0.48px;
  line-height: 22px;
  text-align: justify;
  width: 328px;
}
</style>
