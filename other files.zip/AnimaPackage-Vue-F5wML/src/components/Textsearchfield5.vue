<template>
  <div :class="[`text-search-field-36-1`, className || ``]">
    <div class="search-icon-35">
      <p class="ema-326-joseph-mwil-2 gellix-regular-normal-white-12px" v-html="children"></p>
    </div>
  </div>
</template>

<script>
export default {
  name: "Textsearchfield5",
  props: ["children", "className"],
};
</script>

<style>
.text-search-field-36-1 {
  align-items: center;
  display: flex;
  height: 284px;
  left: 0;
  position: absolute;
  top: 0;
  width: 152px;
}

.search-icon-35 {
  align-items: center;
  display: flex;
  width: 154px;
}

.ema-326-joseph-mwil-2 {
  height: 284.09px;
  letter-spacing: 0.6px;
  line-height: 15.5px;
  width: 152px;
}

.text-search-field-36-1.text-search-field-38,
.text-search-field-36-1.text-search-field-38-1 {
  height: 282px;
}

.text-search-field-36-1.text-search-field-38-1 .ema-326-joseph-mwil-2,
.text-search-field-36-1.text-search-field-38 .ema-326-joseph-mwil-2 {
  height: 281.79px;
}
</style>
