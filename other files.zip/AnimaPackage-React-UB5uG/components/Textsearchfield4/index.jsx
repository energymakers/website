import React from "react";
import "./Textsearchfield4.css";

function Textsearchfield4(props) {
  const { className } = props;

  return (
    <div className={`text-search-field-33 ${className || ""}`}>
      <div className="search-icon-33">
        <p className="about-us-mission-v-2 gellix-regular-normal-white-12px-2">
          <span className="span-14 gellix-regular-normal-white-12px">
            ABOUT US
            <br />
            Mission &amp; vision
            <br />
            Team
            <br />
            Partners
            <br />
            Get involved
            <br />
            Sponsor us
            <br />
          </span>
          <span className="span-14 gellix-regular-normal-tasman-12px">
            <br />
          </span>
          <span className="span-14 gellix-regular-normal-white-12px">
            NEWS
            <br />
            Latest newsNewsletter
            <br />
            Gallery
          </span>
        </p>
      </div>
    </div>
  );
}

export default Textsearchfield4;
