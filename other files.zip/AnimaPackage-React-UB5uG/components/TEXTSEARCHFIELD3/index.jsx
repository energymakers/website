import React from "react";
import "./TEXTSEARCHFIELD3.css";

function TEXTSEARCHFIELD3() {
  return (
    <div className="text-search-field-10">
      <div className="search-icon-5">
        <div className="upcoming-programmes gellix-regular-normal-shamrock-12px">
          UPCOMING
          <br />
          PROGRAMMES
        </div>
      </div>
    </div>
  );
}

export default TEXTSEARCHFIELD3;
