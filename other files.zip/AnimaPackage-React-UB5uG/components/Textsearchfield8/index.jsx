import React from "react";
import SearchIcon from "../SearchIcon";
import "./Textsearchfield8.css";

function Textsearchfield8(props) {
  const { className, searchIconProps } = props;

  return (
    <div className={`text-search-field-3 ${className || ""}`}>
      <SearchIcon>{searchIconProps.children}</SearchIcon>
    </div>
  );
}

export default Textsearchfield8;
