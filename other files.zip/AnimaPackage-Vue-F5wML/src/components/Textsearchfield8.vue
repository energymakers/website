<template>
  <div :class="[`text-search-field-3`, className || ``]">
    <search-icon :joinAProgramme="searchIconProps.joinAProgramme" />
  </div>
</template>

<script>
import SearchIcon from "./SearchIcon";
export default {
  name: "Textsearchfield8",
  components: {
    SearchIcon,
  },
  props: ["className", "searchIconProps"],
};
</script>

<style>
.text-search-field-3 {
  background-color: var(--shamrock);
  border-radius: 8px;
  display: flex;
  height: 47px;
  justify-content: center;
  left: 82px;
  position: absolute;
  top: 540px;
  width: 201px;
}

.text-search-field-3.text-search-field-2,
.text-search-field-3.text-search-field-4 {
  left: unset;
  margin-left: 0.97px;
  margin-top: 8px;
  position: relative;
  top: unset;
}
</style>
