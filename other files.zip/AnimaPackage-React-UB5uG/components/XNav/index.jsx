import React from "react";
import "./XNav.css";

function XNav() {
  return (
    <div className="nav-1">
      <div className="group-6808-1">
        <div className="overlap-group-7">
          <div className="group-6806"></div>
          <img className="vector-35-4" src="/img/vector-35@2x.png" />
          <img className="vector-3-1" src="/img/vector-37-5@2x.png" />
          <img className="vector-3-1" src="/img/vector-38-5@2x.png" />
          <img className="vector-36-3" src="/img/vector-36-7@2x.png" />
        </div>
      </div>
    </div>
  );
}

export default XNav;
