import React from "react";
import Textsearchfield8 from "../Textsearchfield8";
import SearchIcon2 from "../SearchIcon2";
import Textsearchfield7 from "../Textsearchfield7";
import TEXTSEARCHFIELD3 from "../TEXTSEARCHFIELD3";
import Group6882 from "../Group6882";
import Vector from "../Vector";
import Vector2 from "../Vector2";
import Vector3 from "../Vector3";
import Vector4 from "../Vector4";
import Vector5 from "../Vector5";
import TEXTSEARCHFIELD4 from "../TEXTSEARCHFIELD4";
import Textsearchfield2 from "../Textsearchfield2";
import Textsearchfield3 from "../Textsearchfield3";
import Frame6 from "../Frame6";
import "./Android17.css";

function Android17(props) {
  const {
    x124860179_188885906187978_31258602,
    rectangle258,
    weTeachStudentsTh,
    vector26,
    ourMobileLearning,
    vector2,
    vector3,
    vector4,
    vector5,
    vector6,
    x121170480_176224507454118_11538062,
    title,
    x218432608_347909323618968_26240350,
    oel_Facebook,
    x129841425_202769898132912_96775093,
    vector36,
    vector35,
    vector7,
    vector38,
    vector37,
    vector39,
    vector382,
    emaFacebook,
    emaYoutube,
    emaTwitter,
    emaInstagram,
    emaLinkedin,
    vector392,
    vector352,
    vector353,
    vector393,
    vector372,
    vector362,
    vector354,
    updatesNews,
    yourEmailAddress,
    firstName,
    lastName,
    phoneNumber,
    submit,
    spanText,
    spanText2,
    spanText3,
    spanText4,
    spanText5,
    vector41,
    vector42,
    vector8,
    textsearchfield8Props,
    searchIcon2Props,
    textsearchfield7Props,
    textsearchfield72Props,
    textsearchfield73Props,
    textsearchfield74Props,
    textsearchfield75Props,
    textsearchfield76Props,
    textsearchfield77Props,
    group6882Props,
    group68822Props,
    group68823Props,
    group68824Props,
    vectorProps,
    vector2Props,
    vector3Props,
    vector4Props,
    vector5Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="android-17 screen">
        <div className="overlap-group11">
          <div className="rectangle-250"></div>
          <img className="x124860179_1888859061" src={x124860179_188885906187978_31258602} />
          <img className="rectangle-258" src={rectangle258} />
          <div className="we-teach-students-th">{weTeachStudentsTh}</div>
          <Textsearchfield8 searchIconProps={textsearchfield8Props.searchIconProps} />
          <div className="group-6879"></div>
          <div className="group-6880"></div>
          <div className="frame-14">
            <div className="text-search-field-container">
              <a href="#vector-26">
                <div className="text-search-field">
                  <SearchIcon2 spanText={searchIcon2Props.spanText} />
                </div>
              </a>
              <Textsearchfield7 searchIcon2Props={textsearchfield7Props.searchIcon2Props} />
              <Textsearchfield7 searchIcon2Props={textsearchfield72Props.searchIcon2Props} />
              <Textsearchfield7 searchIcon2Props={textsearchfield73Props.searchIcon2Props} />
              <Textsearchfield7
                className={textsearchfield74Props.className}
                searchIcon2Props={textsearchfield74Props.searchIcon2Props}
              />
              <Textsearchfield7 searchIcon2Props={textsearchfield75Props.searchIcon2Props} />
              <Textsearchfield7 searchIcon2Props={textsearchfield76Props.searchIcon2Props} />
              <Textsearchfield7 searchIcon2Props={textsearchfield77Props.searchIcon2Props} />
            </div>
          </div>
          <TEXTSEARCHFIELD3 />
          <img className="vector-26" id="vector-26" src={vector26} />
          <div className="group-6851">
            <p className="our-mobile-learning gellix-regular-normal-white-16px">{ourMobileLearning}</p>
            <div className="group-6864">
              <div className="group-6850"></div>
              <div className="group-685"></div>
              <div className="group-685"></div>
            </div>
          </div>
          <div className="group-6881">
            <div className="flex-row">
              <div className="vector-container">
                <img className="vector-1" src="/img/rectangle-258@2x.png" />
                <div className="vector-2">
                  <img className="vector-4" src={vector2} />
                </div>
                <img className="vector-5" src={vector3} />
              </div>
              <img className="vector-6" src={vector4} />
              <div className="vector-7">
                <img className="vector-8" src={vector5} />
              </div>
            </div>
            <div className="vector-9">
              <img className="vector-10" src={vector6} />
            </div>
          </div>
          <img className="x121170480_1762245074" src={x121170480_176224507454118_11538062} />
          <h1 className="title ballpill-normal-white-32px">{title}</h1>
          <Group6882 spanText={group6882Props.spanText} textsearchfield8Props={group6882Props.textsearchfield8Props} />
          <div className="overlap-group6">
            <Group6882
              spanText={group68822Props.spanText}
              className={group68822Props.className}
              textsearchfield8Props={group68822Props.textsearchfield8Props}
            />
            <img className="x218432608_3479093236" src={x218432608_347909323618968_26240350} />
          </div>
          <div className="overlap-group7">
            <Group6882
              spanText={group68823Props.spanText}
              className={group68823Props.className}
              textsearchfield8Props={group68823Props.textsearchfield8Props}
            />
            <img className="oel_facebook" src={oel_Facebook} />
          </div>
          <div className="overlap-group8">
            <Group6882
              spanText={group68824Props.spanText}
              className={group68824Props.className}
              textsearchfield8Props={group68824Props.textsearchfield8Props}
            />
            <img className="x129841425_2027698981" src={x129841425_202769898132912_96775093} />
          </div>
        </div>
        <div className="nav">
          <div className="group-container">
            <div className="group-6808">
              <img className="vector-36" src={vector36} />
              <div className="overlap-group-2">
                <img className="vector" src={vector35} />
              </div>
            </div>
            <div className="group-6810">
              <div className="frame">
                <img className="vector" src={vector7} />
              </div>
            </div>
          </div>
        </div>
        <div className="group-6825">
          <img className="vector-38" src={vector38} />
          <img className="vector-3" src={vector37} />
          <img className="vector-3" src={vector39} />
        </div>
        <div className="group-6909">
          <div className="overlap-group9">
            <div className="overlap-group">
              <img className="vector-38-1" src={vector382} />
              <div className="overlap-group">
                <div className="overlap-group-3 gellix-regular-normal-violet-red-12px">
                  <div className="ema-container">
                    <div className="ema">{emaFacebook}</div>
                    <div className="ema-you-tube">{emaYoutube}</div>
                  </div>
                  <div className="ema-container-1 gellix-regular-normal-violet-red-12px">
                    <div className="ema">{emaTwitter}</div>
                    <div className="ema-instagram">{emaInstagram}</div>
                  </div>
                  <div className="ema-linked-in">{emaLinkedin}</div>
                </div>
                <div className="group-6903">
                  <img className="vector-39" src={vector392} />
                  <img className="vector-35" src={vector352} />
                </div>
                <img className="vector-35-1" src={vector353} />
                <img className="vector-39-1" src={vector393} />
                <img className="vector-37" src={vector372} />
                <img className="vector-36-1" src={vector362} />
              </div>
              <img className="vector-35-2" src={vector354} />
            </div>
            <Vector src={vectorProps.src} />
            <Vector2 src={vector2Props.src} />
            <Vector3 src={vector3Props.src} />
            <Vector4 src={vector4Props.src} />
            <Vector5 src={vector5Props.src} />
          </div>
        </div>
        <div className="group-6895">
          <div className="overlap-group5">
            <div className="updates-news ballpill-normal-white-32px">{updatesNews}</div>
            <div className="group-6890">
              <div className="overlap-group-4">
                <div className="rectangle-257 border-1px-hit-pink"></div>
                <div className="your-email-address gellix-regular-normal-white-12px">{yourEmailAddress}</div>
              </div>
              <div className="overlap-group-1">
                <div className="rectangle-257 border-1px-hit-pink"></div>
                <div className="first-name gellix-regular-normal-white-12px">{firstName}</div>
              </div>
              <div className="overlap-group-1">
                <div className="rectangle-257 border-1px-hit-pink"></div>
                <div className="last-name gellix-regular-normal-white-12px">{lastName}</div>
              </div>
              <div className="overlap-group1">
                <div className="rectangle-257 border-1px-hit-pink"></div>
                <div className="phone-number gellix-regular-normal-white-12px">{phoneNumber}</div>
              </div>
              <div className="overlap-group2">
                <div className="submit gellix-regular-normal-white-12px">{submit}</div>
              </div>
            </div>
          </div>
        </div>
        <div className="group-6896">
          <div className="footer">
            <div className="overlap-group3">
              <div className="group-6838">
                <div className="overlap-group1-1">
                  <div className="text-search-field-1">
                    <div className="search-icon">
                      <p className="about-us-mission-v gellix-regular-normal-white-12px-2">
                        <span className="span gellix-regular-normal-white-12px">{spanText}</span>
                        <span className="span gellix-regular-normal-dull-lavender-12px">{spanText2}</span>
                        <span className="span gellix-regular-normal-tasman-12px">{spanText3}</span>
                        <span className="span gellix-regular-normal-white-12px">{spanText4}</span>
                        <span className="span gellix-regular-normal-dull-lavender-12px">{spanText5}</span>
                      </p>
                    </div>
                  </div>
                  <div className="group-6839">
                    <div className="group-6839-1">
                      <div className="overlap-group-5">
                        <TEXTSEARCHFIELD4 />
                        <img className="vector-41" src={vector41} />
                        <img className="vector-42" src={vector42} />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="text-search-field-container-1">
                  <Textsearchfield2 />
                  <Textsearchfield3 />
                </div>
              </div>
              <img className="vector-11" src={vector8} />
              <Frame6 />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Android17;
