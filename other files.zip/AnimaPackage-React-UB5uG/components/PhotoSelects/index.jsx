import React from "react";
import "./PhotoSelects.css";

function PhotoSelects() {
  return (
    <div className="container-center-horizontal">
      <div className="photo-selects screen"></div>
    </div>
  );
}

export default PhotoSelects;
