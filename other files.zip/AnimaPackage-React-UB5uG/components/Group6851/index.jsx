import React from "react";
import "./Group6851.css";

function Group6851(props) {
  const { energyMakersAcadem } = props;

  return (
    <div className="group-6" id="group-6851">
      <p className="energy-makers-ac gellix-regular-normal-white-16px">{energyMakersAcadem}</p>
    </div>
  );
}

export default Group6851;
