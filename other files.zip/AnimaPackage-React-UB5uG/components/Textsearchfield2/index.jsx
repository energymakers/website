import React from "react";
import "./Textsearchfield2.css";

function Textsearchfield2(props) {
  const { className } = props;

  return (
    <div className={`text-search-field-15 ${className || ""}`}>
      <div className="search-icon-11">
        <p className="programmes-programme gellix-regular-normal-white-12px-2">
          <span className="span-7 gellix-regular-normal-white-12px">
            PROGRAMMES
            <br />
          </span>
          <span className="span-7 gellix-regular-normal-dull-lavender-12px">
            Programme name 1<br />
            Name 2<br />
            Name 3<br />
            Name 4<br />
          </span>
          <span className="span-7 gellix-regular-normal-white-12px">
            <br />
            PROJECTS
            <br />
          </span>
          <span className="span-7 gellix-regular-normal-dull-lavender-12px">
            Project name 1<br />
            Name 2<br />
            Name 3
          </span>
        </p>
      </div>
    </div>
  );
}

export default Textsearchfield2;
