import React from "react";
import { Link } from "react-router-dom";
import Group6851 from "../Group6851";
import Textsearchfield7 from "../Textsearchfield7";
import SearchIcon2 from "../SearchIcon2";
import TEXTSEARCHFIELD3 from "../TEXTSEARCHFIELD3";
import SearchIcon from "../SearchIcon";
import Textsearchfield8 from "../Textsearchfield8";
import Group6853 from "../Group6853";
import Vector8 from "../Vector8";
import Vector2 from "../Vector2";
import Vector32 from "../Vector32";
import Vector4 from "../Vector4";
import Vector5 from "../Vector5";
import Group6840 from "../Group6840";
import Frame6 from "../Frame6";
import Group6825 from "../Group6825";
import "./MobWebsite1.css";

function MobWebsite1(props) {
  const {
    text,
    text1,
    text2,
    text5,
    text6,
    text3,
    text4,
    vector26,
    vector2,
    vector3,
    vector4,
    vector5,
    vector6,
    x121170480_176224507454118_115380622,
    answersHub,
    x131662611_3760936164026451_87872492,
    spanText,
    spanText2,
    spanText3,
    spanText4,
    x131662611_3760936164026451_87872493,
    whyPartnerWithUs,
    x218432608_347909323618968_26240350,
    x131662611_3760936164026451_87872494,
    whatHavePreviousStudentsSaid,
    oel_Facebook,
    x131662611_3760936164026451_87872495,
    spanText5,
    spanText6,
    spanText7,
    spanText8,
    x129841425_202769898132912_96775093,
    vector38,
    emaFacebook,
    emaYoutube,
    emaTwitter,
    emaInstagram,
    emaLinkedin,
    vector39,
    vector35,
    vector352,
    vector392,
    vector37,
    vector36,
    vector353,
    group6840,
    yourEmailAddress,
    firstName,
    lastName,
    phoneNumber,
    submit,
    firstName2,
    updatesNews,
    group6851Props,
    group68512Props,
    group68513Props,
    textsearchfield7Props,
    searchIcon2Props,
    textsearchfield72Props,
    textsearchfield73Props,
    textsearchfield74Props,
    textsearchfield75Props,
    textsearchfield76Props,
    textsearchfield77Props,
    searchIconProps,
    textsearchfield8Props,
    group6853Props,
    group68532Props,
    searchIcon2Props2,
    searchIcon3Props,
    vector8Props,
    vector2Props,
    vector32Props,
    vector4Props,
    vector5Props,
    group6840Props,
    group6825Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="mob-website-1 screen">
        <div className="overlap-group12-1">
          <img className="rectangle-250-2" src="/img/rectangle-250@1x.svg" />
          <img className="overlap-group12-item" src="/img/121170480-176224507454118-1153806274680853683-n@1x.svg" />
          <img className="overlap-group12-item" src="/img/131662611-3760936164026451-8787249473412765197-n@1x.svg" />
          <img className="rectangle-258-1" src="/img/rectangle-258@2x.svg" />
          <img
            className="learn-how-to-build-a-solar-energy-system"
            src="/img/learn-how-to-build-a-solar-energy-system-@2x.svg"
          />
          <Link to="/android-21">
            <img className="text-search-field-49" src="/img/text-search-field@2x.svg" />
          </Link>
          <div className="group-6879-1"></div>
          <div className="frame-15">
            <div className="text-2">{text}</div>
            <div className="overlap-group-container">
              <div className="overlap-group3-1">
                <Group6851 energyMakersAcadem={group6851Props.energyMakersAcadem} />
                <a href="#group-6908">
                  <div className="text valign-text-middle ballpill-normal-white-22px">{text1}</div>
                </a>
                <div className="text-1 valign-text-middle ballpill-normal-ebony-clay-22px">{text2}</div>
              </div>
              <div className="overlap-group-19">
                <Group6851 energyMakersAcadem={group68512Props.energyMakersAcadem} />
                <a href="#group-6909">
                  <div className="text valign-text-middle ballpill-normal-white-22px">{text5}</div>
                </a>
                <div className="text-1 valign-text-middle ballpill-normal-ebony-clay-22px">{text6}</div>
              </div>
              <div className="overlap-group-19">
                <Group6851 energyMakersAcadem={group68513Props.energyMakersAcadem} />
                <div className="text-3 valign-text-middle ballpill-normal-ebony-clay-22px">{text3}</div>
                <a href="#group-6851">
                  <div className="text-4 valign-text-middle ballpill-normal-white-22px">{text4}</div>
                </a>
              </div>
            </div>
          </div>
          <div className="frame-14-1">
            <div className="text-search-field-container-9">
              <Textsearchfield7
                className={textsearchfield7Props.className}
                searchIcon2Props={textsearchfield7Props.searchIcon2Props}
              />
              <Link to="/android-21">
                <div className="text-search-field-50">
                  <SearchIcon2 spanText={searchIcon2Props.spanText} />
                </div>
              </Link>
              <Textsearchfield7 searchIcon2Props={textsearchfield72Props.searchIcon2Props} />
              <Textsearchfield7 searchIcon2Props={textsearchfield73Props.searchIcon2Props} />
              <Textsearchfield7
                className={textsearchfield74Props.className}
                searchIcon2Props={textsearchfield74Props.searchIcon2Props}
              />
              <Textsearchfield7 searchIcon2Props={textsearchfield75Props.searchIcon2Props} />
              <Textsearchfield7 searchIcon2Props={textsearchfield76Props.searchIcon2Props} />
              <Textsearchfield7 searchIcon2Props={textsearchfield77Props.searchIcon2Props} />
            </div>
          </div>
          <TEXTSEARCHFIELD3 />
          <img className="vector-26-1" id="vector-26" src={vector26} />
          <div className="vector-container-1">
            <img className="vector-30" src="/img/vector-7@2x.png" />
            <img className="vector-31" src={vector2} />
            <div className="vector-32">
              <img className="vector-33" src={vector3} />
            </div>
            <div className="vector-34">
              <img className="vector-40" src={vector4} />
            </div>
            <div className="vector-43">
              <img className="vector-44" src={vector5} />
            </div>
            <img className="vector-45" src={vector6} />
          </div>
          <img className="x121170480_1762245074-1" src={x121170480_176224507454118_115380622} />
          <div className="answers-hub ballpill-normal-white-32px">{answersHub}</div>
          <div className="group-6882-1">
            <div className="group-6858-2">
              <img className="x131662611_3760936164-2" src={x131662611_3760936164026451_87872492} />
              <div className="group-6853-2">
                <div className="group-6814-1">
                  <div className="energy-makers-academ-container">
                    <p className="what gellix-regular-normal-white-12px-2">
                      <span className="span-18 gellix-regular-normal-white-12px">{spanText}</span>
                      <span className="span-18 gellix-regular-normal-minsk-12px">{spanText2}</span>
                    </p>
                    <p className="energy-makers-academ">
                      <span className="span0-1">{spanText3}</span>
                      <span className="span1-1">{spanText4}</span>
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <a href="#vector-26">
              <div className="text-search-field-48">
                <SearchIcon>{searchIconProps.children}</SearchIcon>
              </div>
            </a>
          </div>
          <div className="overlap-group7-2">
            <div className="group-container-6">
              <div className="group-688-1">
                <div className="group-6858-1">
                  <img className="x131662611_3760936164-1" src={x131662611_3760936164026451_87872493} />
                  <div className="group-6853-1">
                    <div className="group-6814-2">
                      <div className="why-partner-with-us gellix-regular-normal-white-12px">{whyPartnerWithUs}</div>
                    </div>
                  </div>
                </div>
                <Textsearchfield8
                  className={textsearchfield8Props.className}
                  searchIconProps={textsearchfield8Props.searchIconProps}
                />
              </div>
              <Group6853 spanText4={group6853Props.spanText4} />
            </div>
            <img className="x218432608_3479093236-1" src={x218432608_347909323618968_26240350} />
          </div>
          <div className="overlap-group8-1">
            <div className="group-688-1">
              <div className="group-6858-1">
                <img className="x131662611_3760936164-1" src={x131662611_3760936164026451_87872494} />
                <div className="group-6853-1">
                  <div className="group-6814-3">
                    <div className="overlap-group1-8">
                      <p className="what-have-previous-students-said gellix-regular-normal-white-12px">
                        {whatHavePreviousStudentsSaid}
                      </p>
                      <Group6853 spanText4={group68532Props.spanText4} className={group68532Props.className} />
                    </div>
                  </div>
                </div>
              </div>
              <a href="#vector-26">
                <div className="text-search-field-51">
                  <SearchIcon>{searchIcon2Props2.children}</SearchIcon>
                </div>
              </a>
            </div>
            <img className="oel_facebook-1" src={oel_Facebook} />
          </div>
          <div className="overlap-group9-2">
            <div className="group-6889">
              <div className="group-6858-3">
                <img className="x131662611_3760936164-3" src={x131662611_3760936164026451_87872495} />
                <div className="group-6853-3">
                  <div className="group-6814-4">
                    <div className="overlap-group-22 gellix-regular-normal-white-12px-2">
                      <p className="what">
                        <span className="span-18 gellix-regular-normal-white-12px">{spanText5}</span>
                        <span className="span-18 gellix-regular-normal-minsk-12px">{spanText6}</span>
                      </p>
                      <p className="through-hands-on-lea">
                        <span className="span-18 gellix-regular-normal-white-12px">{spanText7}</span>
                        <span className="span-18 gellix-regular-normal-minsk-12px">{spanText8}</span>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <a href="#vector-26">
                <div className="text-search-field-48">
                  <SearchIcon>{searchIcon3Props.children}</SearchIcon>
                </div>
              </a>
            </div>
            <img className="x129841425_2027698981-1" src={x129841425_202769898132912_96775093} />
          </div>
        </div>
        <div className="flex-row-1">
          <div className="overlap-group-container-1">
            <div className="overlap-group-20">
              <div className="overlap-group-20">
                <img className="vector-38-7" src={vector38} />
                <div className="overlap-group1-9">
                  <div className="overlap-group-23 gellix-regular-normal-violet-red-12px">
                    <div className="ema-container-2">
                      <div className="ema-1">{emaFacebook}</div>
                      <div className="ema-you-tube-1">{emaYoutube}</div>
                    </div>
                    <div className="ema-container-3 gellix-regular-normal-violet-red-12px">
                      <div className="ema-1">{emaTwitter}</div>
                      <div className="ema-instagram-1">{emaInstagram}</div>
                    </div>
                    <div className="ema-linked-in-1">{emaLinkedin}</div>
                  </div>
                  <div className="group-6903-1">
                    <img className="vector-39-7" src={vector39} />
                    <img className="vector-35-9" src={vector35} />
                  </div>
                  <img className="vector-35-10" src={vector352} />
                  <img className="vector-39-8" src={vector392} />
                  <img className="vector-37-6" src={vector37} />
                  <img className="vector-36-8" src={vector36} />
                </div>
                <img className="vector-35-11" src={vector353} />
              </div>
              <Vector8 src={vector8Props.src} />
              <Vector2 src={vector2Props.src} className={vector2Props.className} />
              <Vector32 src={vector32Props.src} />
              <Vector4 src={vector4Props.src} className={vector4Props.className} />
              <Vector5 src={vector5Props.src} className={vector5Props.className} />
            </div>
            <div className="group-container-7">
              <div className="group-6896-1">
                <div className="footer-2">
                  <div className="overlap-group3-2">
                    <Group6840
                      tEXTSEARCHFIELD5Props={group6840Props.tEXTSEARCHFIELD5Props}
                      tEXTSEARCHFIELD52Props={group6840Props.tEXTSEARCHFIELD52Props}
                    />
                    <div className="group-6840-5" style={{ backgroundImage: `url(${group6840})` }}></div>
                    <Frame6 />
                  </div>
                </div>
              </div>
              <div className="overlap-group11-2">
                <div className="rectangle-256"></div>
                <div className="group-6890-1 gellix-regular-normal-white-12px">
                  <div className="overlap-group3-3">
                    <div className="rectangle-257-1 border-1px-hit-pink"></div>
                    <div className="your-email-address-1">{yourEmailAddress}</div>
                  </div>
                  <div className="overlap-group-21">
                    <div className="rectangle-257-1 border-1px-hit-pink"></div>
                    <div className="first-name-1">{firstName}</div>
                  </div>
                  <div className="overlap-group-21">
                    <div className="rectangle-257-1 border-1px-hit-pink"></div>
                    <div className="last-name-1">{lastName}</div>
                  </div>
                  <div className="overlap-group-24">
                    <div className="rectangle-257-1 border-1px-hit-pink"></div>
                    <div className="phone-number-1">{phoneNumber}</div>
                  </div>
                  <div className="overlap-group4-2">
                    <div className="submit-1">{submit}</div>
                  </div>
                  <div className="first-name-2">{firstName2}</div>
                </div>
                <div className="updates-news-1 ballpill-normal-white-32px">{updatesNews}</div>
              </div>
            </div>
          </div>
        </div>
        <Group6825 className={group6825Props.className} />
        <img className="nav-5" src="/img/nav@2x.svg" />
        <a href="javascript:ShowOverlay('android-23', 'animate-appear');">
          <img className="group-6825-3" src="/img/group-6825@2x.svg" />
        </a>
      </div>
    </div>
  );
}

export default MobWebsite1;
