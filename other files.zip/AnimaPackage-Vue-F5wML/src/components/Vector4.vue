<template>
  <div :class="[`vector-19`, className || ``]"><img class="vector-20" :src="src" /></div>
</template>

<script>
export default {
  name: "Vector4",
  props: ["src", "className"],
};
</script>

<style>
.vector-19 {
  align-items: center;
  display: flex;
  height: 46px;
  left: 47px;
  min-width: 31px;
  padding: 0 15.3px;
  position: absolute;
  top: 23px;
  transform: rotate(90deg);
}

.vector-20 {
  height: 1px;
  transform: rotate(-90deg);
  width: 1px;
}

.vector-19.vector-21 {
  justify-content: center;
  padding: unset;
  top: 24px;
}

.vector-19.vector-21 .vector-20 {
  height: 32px;
  width: 46px;
}
</style>
