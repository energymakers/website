import React from "react";
import "./Group6853.css";

function Group6853(props) {
  const { spanText4, className } = props;

  return (
    <div className={`group-6853-4 ${className || ""}`}>
      <div className="group-6814-5">
        <div className="overlap-group-25 gellix-regular-normal-white-12px-2">
          <div className="text-5">
            <span className="span-19 gellix-regular-normal-white-12px">
              <br />
            </span>
            <span className="span-19 gellix-regular-normal-minsk-12px"></span>
          </div>
          <p className="we-work-with-organsa">
            <span className="span-19 gellix-regular-normal-white-12px">
              <br />
            </span>
            <span className="span-19 gellix-regular-normal-minsk-12px">{spanText4}</span>
          </p>
        </div>
      </div>
    </div>
  );
}

export default Group6853;
