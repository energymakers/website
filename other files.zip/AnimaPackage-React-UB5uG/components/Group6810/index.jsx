import React from "react";
import Frame from "../Frame";
import "./Group6810.css";

function Group6810() {
  return (
    <div className="group-6810-2">
      <Frame />
    </div>
  );
}

export default Group6810;
