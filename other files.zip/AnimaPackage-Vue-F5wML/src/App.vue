<template>
  <router-view />
</template>

<script>
export default {
  name: "App",
};
</script>

<style>
.frame-18 {
  height: 1414px;
  width: 360px;
}
</style>
