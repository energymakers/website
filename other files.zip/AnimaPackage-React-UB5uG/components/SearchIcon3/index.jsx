import React from "react";
import "./SearchIcon3.css";

function SearchIcon3() {
  return (
    <div className="search-icon-17">
      <div className="programmes valign-text-middle gellix-regular-normal-white-18px">PROGRAMMES</div>
    </div>
  );
}

export default SearchIcon3;
