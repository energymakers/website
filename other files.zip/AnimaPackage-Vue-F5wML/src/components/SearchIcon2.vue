<template>
  <div class="search-icon-3">
    <p class="title-of-programme gellix-regular-normal-white-12px-2">
      <span class="span-1 gellix-regular-normal-white-12px">{{ spanText }}</span
      ><span class="span-1 gellix-regular-normal-dull-lavender-12px">→ More info</span>
    </p>
  </div>
</template>

<script>
export default {
  name: "SearchIcon2",
  props: ["spanText"],
};
</script>

<style>
.search-icon-3,
.search-icon-4 {
  display: flex;
  justify-content: center;
  margin-left: 2px;
  width: 162px;
}

.title-of-programme,
.univaersity-of-zambi,
.copperbelt-universit,
.solwezi-trades-decem,
.lbtc-january-2022-more-info,
.libes-february-2022-more-info,
.nortec-march-2022-more-info,
.luanshya-trades-april-2022-more-info,
.chizongwe-tech-may-2022-more-info {
  height: 103.24px;
  letter-spacing: 0.6px;
  line-height: 15.5px;
  margin-left: -2px;
  width: 160px;
}

.span-1,
.span-2 {
  letter-spacing: 0.07px;
}
</style>
