<template>
  <div :class="[`text-search-field-12`, className || ``]">
    <div class="search-icon-8">
      <p class="ema-326-joseph-mwil gellix-regular-normal-white-12px-2">
        <span class="span-4 gellix-regular-normal-white-12px">EMA<br /></span
        ><span class="span-4 gellix-regular-normal-dull-lavender-12px"
          >32/6 Joseph Mwilwa Rd<br />Rhodes Park<br />Lusaka — Zambia<br /><br />View on Google Maps<br /><br />Email
          us<br />EMA Press kit</span
        >
      </p>
    </div>
  </div>
</template>

<script>
export default {
  name: "Textsearchfield4",
  props: ["className"],
};
</script>

<style>
.text-search-field-12 {
  align-items: center;
  display: flex;
  height: 285px;
  left: 0;
  position: absolute;
  top: 0;
  width: 152px;
}

.search-icon-8 {
  align-items: center;
  display: flex;
  width: 154px;
}

.ema-326-joseph-mwil {
  height: 285px;
  letter-spacing: 0.6px;
  line-height: 15.5px;
  width: 152px;
}

.span-4 {
  letter-spacing: 0.07px;
}

.text-search-field-12.text-search-field-14 {
  height: 283px;
}

.text-search-field-12.text-search-field-14 .ema-326-joseph-mwil {
  height: 282.69px;
}
</style>
