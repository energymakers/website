<template>
  <div class="vector-17"><img class="vector-18" :src="src" /></div>
</template>

<script>
export default {
  name: "Vector3",
  props: ["src"],
};
</script>

<style>
.vector-17 {
  align-items: center;
  display: flex;
  height: 22px;
  left: 274px;
  min-width: 57px;
  padding: 0 28.2px;
  position: absolute;
  top: 38px;
}

.vector-18 {
  height: 1px;
  width: 1px;
}
</style>
