<template>
  <div :class="[`group-6882`, className || ``]">
    <div class="group-6858">
      <img
        class="x131662611_3760936164"
        src="https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png"
      />
      <div class="group-6853">
        <div class="group-6814">
          <p class="what-is-energy-maker gellix-regular-normal-white-12px-2">
            <span class="span-3 gellix-regular-normal-white-12px">{{ spanText }}</span
            ><span class="span-3 gellix-regular-normal-minsk-12px"
              ><br />– EMA students learn practical skills<br />– EMA students become part of cohort<br />– EMA students
              learn practical skills<br />– EMA students become part of cohort</span
            >
          </p>
        </div>
      </div>
    </div>
    <textsearchfield8
      :className="textsearchfield8Props.className"
      :searchIconProps="textsearchfield8Props.searchIconProps"
    />
  </div>
</template>

<script>
import Textsearchfield8 from "./Textsearchfield8";
export default {
  name: "Group6882",
  components: {
    Textsearchfield8,
  },
  props: ["spanText", "className", "textsearchfield8Props"],
};
</script>

<style>
.group-6882 {
  align-items: center;
  display: flex;
  flex-direction: column;
  left: 64px;
  min-height: 331px;
  position: absolute;
  top: 1794px;
  width: 360px;
}

.group-6858 {
  align-items: center;
  display: flex;
  flex-direction: column;
  min-height: 276px;
  padding: 0px 0;
  width: 360px;
}

.x131662611_3760936164 {
  height: 1px;
  margin-left: 0;
  margin-top: 72px;
  object-fit: cover;
  width: 1px;
}

.group-6853 {
  align-items: flex-end;
  display: flex;
  height: 111px;
  margin-top: 93px;
  width: 360px;
}

.group-6814 {
  align-items: flex-end;
  display: flex;
  width: 362px;
}

.what-is-energy-maker {
  height: 111.33px;
  letter-spacing: 0.6px;
  line-height: 15.5px;
  text-align: center;
  width: 360px;
}

.span-3 {
  letter-spacing: 0.07px;
}

.group-6882.group-688 {
  left: 0;
  top: 0;
}
</style>
