export const searchIconData = {
    joinAProgramme: "→ JOIN A PROGRAMME",
};

export const textsearchfield8Data = {
    searchIconProps: searchIconData,
};

export const searchIcon2Data = {
    spanText: "TITLE OF PROGRAMME<br />October 2021<br /><br />",
};

export const searchIcon22Data = {
    spanText: "TITLE OF PROGRAMME<br />November 2021<br /><br />",
};

export const textsearchfield7Data = {
    searchIcon2Props: searchIcon22Data,
};

export const searchIcon23Data = {
    spanText: "TITLE OF PROGRAMME<br />December 2021<br /><br />",
};

export const textsearchfield72Data = {
    searchIcon2Props: searchIcon23Data,
};

export const searchIcon24Data = {
    spanText: "TITLE OF PROGRAMME<br />January 2022<br /><br />",
};

export const textsearchfield73Data = {
    searchIcon2Props: searchIcon24Data,
};

export const searchIcon25Data = {
    spanText: "TITLE OF PROGRAMME<br />February 2022<br /><br />",
};

export const textsearchfield74Data = {
    className: "text-search-field-7",
    searchIcon2Props: searchIcon25Data,
};

export const searchIcon26Data = {
    spanText: "TITLE OF PROGRAMME<br />March 2022<br /><br />",
};

export const textsearchfield75Data = {
    searchIcon2Props: searchIcon26Data,
};

export const searchIcon27Data = {
    spanText: "TITLE OF PROGRAMME<br />April 2022<br /><br />",
};

export const textsearchfield76Data = {
    searchIcon2Props: searchIcon27Data,
};

export const searchIcon28Data = {
    spanText: "TITLE OF PROGRAMME<br />May 2022<br /><br />",
};

export const textsearchfield77Data = {
    searchIcon2Props: searchIcon28Data,
};

export const searchIcon3Data = {
    joinAProgramme: "→ PARTNER WITH US",
};

export const textsearchfield82Data = {
    className: "text-search-field-2",
    searchIconProps: searchIcon3Data,
};

export const group6882Data = {
    spanText: "WHAT IS ENERGY MAKERS ACADEMY?<br />",
    textsearchfield8Props: textsearchfield82Data,
};

export const searchIcon4Data = {
    joinAProgramme: "→ JOIN A PROGRAMME",
};

export const textsearchfield83Data = {
    className: "text-search-field-2",
    searchIconProps: searchIcon4Data,
};

export const group68822Data = {
    spanText: "WHAT ARE THE BENEFITS OF JOINING?<br />",
    className: "group-688",
    textsearchfield8Props: textsearchfield83Data,
};

export const searchIcon5Data = {
    joinAProgramme: "→ PARTNER WITH US",
};

export const textsearchfield84Data = {
    className: "text-search-field-2",
    searchIconProps: searchIcon5Data,
};

export const group68823Data = {
    spanText: "GRAD SPOTLIGHT: FLORENCE LUNGU<br />",
    className: "group-688",
    textsearchfield8Props: textsearchfield84Data,
};

export const searchIcon6Data = {
    joinAProgramme: "→ JOIN A PROGRAMME",
};

export const textsearchfield85Data = {
    className: "text-search-field-2",
    searchIconProps: searchIcon6Data,
};

export const group68824Data = {
    spanText: "WHAT ARE THE BENEFITS OF JOINING?<br />",
    className: "group-688",
    textsearchfield8Props: textsearchfield85Data,
};

export const vectorData = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
};

export const vector2Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
};

export const vector3Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
};

export const vector4Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
};

export const vector5Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
};

export const android17Data = {
    x124860179_188885906187978_31258602: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/124860179-188885906187978-3125860231458806657-n@1x.png",
    rectangle258: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
    weTeachStudentsTh: "We teach students through a “learn by making” approach, providing them with the skills and knowledge to develop universal access to electricity.",
    vector26: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
    ourMobileLearning: "Our mobile learning platform and integrated hardware demystifies energy systems, and offers powerful capabilities for their design. We empower and inspire people and communities to innovate towards affordable, reliable and sustainable energy systems.",
    vector2: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
    vector3: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
    vector4: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
    vector5: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
    vector6: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
    x121170480_176224507454118_11538062: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
    title: "ANSWERS HUB",
    x218432608_347909323618968_26240350: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
    oel_Facebook: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
    x129841425_202769898132912_96775093: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
    vector36: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
    vector35: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
    vector7: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
    vector38: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
    vector37: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
    vector39: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
    vector382: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
    emaFacebook: "EMA Facebook",
    emaYoutube: "EMA YouTube",
    emaTwitter: "EMA<br />Twitter",
    emaInstagram: "EMA Instagram",
    emaLinkedin: "EMA LinkedIn",
    vector392: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
    vector352: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
    vector353: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
    vector393: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
    vector372: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
    vector362: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
    vector354: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
    updatesNews: "UPDATES & NEWS",
    yourEmailAddress: "Your email address*",
    firstName: "First name",
    lastName: "Last name",
    phoneNumber: "Phone number",
    submit: "→ SUBMIT",
    spanText: "ABOUT US<br />",
    spanText2: "Mission & vision<br />Team<br />Partners<br />Get involved<br />Sponsor us<br />",
    spanText3: "<br />",
    spanText4: "NEWS<br />",
    spanText5: "Latest newsNewsletter<br />Gallery",
    vector41: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
    vector42: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
    vector8: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png",
    textsearchfield8Props: textsearchfield8Data,
    searchIcon2Props: searchIcon2Data,
    textsearchfield7Props: textsearchfield7Data,
    textsearchfield72Props: textsearchfield72Data,
    textsearchfield73Props: textsearchfield73Data,
    textsearchfield74Props: textsearchfield74Data,
    textsearchfield75Props: textsearchfield75Data,
    textsearchfield76Props: textsearchfield76Data,
    textsearchfield77Props: textsearchfield77Data,
    group6882Props: group6882Data,
    group68822Props: group68822Data,
    group68823Props: group68823Data,
    group68824Props: group68824Data,
    vectorProps: vectorData,
    vector2Props: vector2Data,
    vector3Props: vector3Data,
    vector4Props: vector4Data,
    vector5Props: vector5Data,
};

export const android23Data = {
    vector38: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-38-4@2x.png",
    twitterFacebook: "↗ Twitter<br />↗ Facebook",
    linkedinInstagram: "↗ LinkedIn<br />↗ Instagram",
    vector35: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-38-4@2x.png",
    vector39: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-38-4@2x.png",
    vector36: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-38-4@2x.png",
    vector37: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-37-4@2x.png",
    newsletterSignUp: "NEWSLETTER SIGN-UP",
};

export const textsearchfieldData = {
    children: "↓  MEET THE EMA TEAM",
};

export const textsearchfield42Data = {
    className: "",
};

export const group6839Data = {
    vector41: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-41@2x.png",
    vector42: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-42@2x.png",
    tEXTSEARCHFIELD4Props: textsearchfield42Data,
};

export const textsearchfield5Data = {
    children: "EMA<br />32/6 Joseph Mwilwa Rd<br />Rhodes Park<br />Lusaka — Zambia<br /><br />View on Google Maps<br /><br />Email us<br />EMA Press kit",
};

export const textsearchfield52Data = {
    children: "PROGRAMMES<br />University of Zambia<br />Copperbelt University<br /><br /><br /><br />PROJECTS<br />Liquid Telcom<br />Name 2<br />Name 3",
};

export const group6840Data = {
    tEXTSEARCHFIELD5Props: textsearchfield5Data,
    tEXTSEARCHFIELD52Props: textsearchfield52Data,
};

export const frame62Data = {
    className: "frame-6-1",
};

export const android25Data = {
    polygon1: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/polygon-1-1@2x.png",
    partnersOfEma: "↓  PARTNERS OF EMA",
    getInvolvedWithEma: "↓  GET INVOLVED WITH EMA",
    spanText: "Mission and vision<br />",
    spanText2: "Team<br />Partners<br />Get involved<br />Sponsor<br />Share",
    spanText3: "ABOUT US<br />",
    spanText4: "Mission & vision<br />Team<br />Partners<br />Get involved<br />Sponsor us",
    spanText5: "NEWS<br />",
    spanText6: "Latest newsNewsletter<br />Gallery",
    group6840: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector@2x.png",
    vector35: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-35@2x.png",
    vector36: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-36@2x.png",
    textsearchfieldProps: textsearchfieldData,
    group6839Props: group6839Data,
    group6840Props: group6840Data,
    frame6Props: frame62Data,
};

export const textsearchfield9Data = {
    children: "→ JOIN US AT UNZA",
    className: "text-search-field-31",
};

export const textsearchfield10Data = {
    children: "→ JOIN US AT CBU",
    className: "text-search-field-32",
};

export const group681323Data = {
    className: "group-6911",
};

export const textsearchfield43Data = {
    className: "text-search-field-14",
};

export const group68392Data = {
    vector41: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c390fadbfb8eee2ef63e4f/img/vector-41-2@2x.png",
    vector42: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c390fadbfb8eee2ef63e4f/img/vector-42-2@2x.png",
    className: "group-6839-4",
    tEXTSEARCHFIELD4Props: textsearchfield43Data,
};

export const textsearchfield23Data = {
    className: "text-search-field-17",
};

export const textsearchfield323Data = {
    className: "text-search-field-20",
};

export const textsearchfield423Data = {
    className: "text-search-field-34",
};

export const textsearchfield53Data = {
    children: "EMA<br />32/6 Joseph Mwilwa Rd<br />Rhodes Park<br />Lusaka — Zambia<br /><br />View on Google Maps<br /><br />Email us<br />EMA Press kit",
    className: "text-search-field-38-1",
};

export const textsearchfield54Data = {
    children: "PROGRAMMES<br />University of Zambia<br />Copperbelt University<br /><br /><br /><br />PROJECTS<br />Liquid Telcom<br />Name 2<br />Name 3",
    className: "text-search-field-38",
};

export const textsearchfield62Data = {
    className: "text-search-field-41",
};

export const textsearchfield44Data = {
    className: "",
};

export const group68393Data = {
    vector41: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-41@2x.png",
    vector42: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-42@2x.png",
    tEXTSEARCHFIELD4Props: textsearchfield44Data,
};

export const textsearchfield55Data = {
    children: "EMA<br />32/6 Joseph Mwilwa Rd<br />Rhodes Park<br />Lusaka — Zambia<br /><br />View on Google Maps<br /><br />Email us<br />EMA Press kit",
};

export const textsearchfield56Data = {
    children: "PROGRAMMES<br />University of Zambia<br />Copperbelt University<br /><br /><br /><br />PROJECTS<br />Liquid Telcom<br />Name 2<br />Name 3",
};

export const group68402Data = {
    tEXTSEARCHFIELD5Props: textsearchfield55Data,
    tEXTSEARCHFIELD52Props: textsearchfield56Data,
};

export const android21Data = {
    x218432609: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61b8c319d1d7cd48b84e3938/img/-218432609@2x.png",
    universityOfZambia: "UNIVERSITY OF ZAMBIA<br />January 2022<br /><br />Join this TEVETA accredited programme delivered by UNZA. Through this programme you will gain skills in practical electronics, embedded software and energy system design. On completion you will be awarded a Skills Award in Solar Charge Controller Technology.",
    vector35: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-35@2x.png",
    vector36: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-36@2x.png",
    vector38: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-37@2x.png",
    vector37: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-37@2x.png",
    vector39: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-37@2x.png",
    copperbeltUniversit: "COPPERBELT UNIVERSITY<br />March 2022<br /><br />Join this TEVETA accredited programme delivered by one of the best training institutions in the Zambia. Through this programme you will gain skills in practical electronics, embedded software and energy system design. Once you have completed the programme you will be awarded a Skills Award in Solar Charge Controller Technology.",
    cbu1: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61b8c319d1d7cd48b84e3938/img/cbu-1@2x.png",
    spanText: "ABOUT US<br />",
    spanText2: "Mission & vision<br />Team<br />Partners<br />Get involved<br />Sponsor us",
    spanText3: "NEWS<br />",
    spanText4: "Latest newsNewsletter<br />Gallery",
    vector41: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c390fadbfb8eee2ef63e4f/img/vector-41-3@2x.png",
    vector42: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c390fadbfb8eee2ef63e4f/img/vector-42-3@2x.png",
    group6840: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector@2x.png",
    spanText5: "ABOUT US<br />",
    spanText6: "Mission & vision<br />Team<br />Partners<br />Get involved<br />Sponsor us",
    spanText7: "NEWS<br />",
    spanText8: "Latest newsNewsletter<br />Gallery",
    group6842: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector@2x.png",
    textsearchfieldProps: textsearchfield9Data,
    textsearchfield2Props: textsearchfield10Data,
    group68132Props: group681323Data,
    group6839Props: group68392Data,
    textsearchfield2Props2: textsearchfield23Data,
    textsearchfield32Props: textsearchfield323Data,
    textsearchfield42Props: textsearchfield423Data,
    textsearchfield5Props: textsearchfield53Data,
    textsearchfield52Props: textsearchfield54Data,
    textsearchfield6Props: textsearchfield62Data,
    group68392Props: group68393Data,
    group6840Props: group68402Data,
};

export const android24Data = {
    vector38: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-38-4@2x.png",
    twitterFacebook: "↗ Twitter<br />↗ Facebook",
    linkedinInstagram: "↗ LinkedIn<br />↗ Instagram",
    vector35: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-38-4@2x.png",
    vector39: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-38-4@2x.png",
    vector36: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-38-4@2x.png",
    vector37: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-37-4@2x.png",
    newsletterSignUp: "NEWSLETTER SIGN-UP",
};

export const group6851Data = {
    energyMakersAcadem: "Energy Makers Academy is a learning programme which teaches you how to build a charge controller.<br /><br />Learn by making your own electricity supply, able to light your room and charge your phone.",
};

export const group68512Data = {
    energyMakersAcadem: "The Energy Makers Academy app teaches you all you need to know to start building solar charge controllers. Learn about electronics, programming and energy system design using interactive illustrations, experiments and practical exercises.",
};

export const group68513Data = {
    energyMakersAcadem: "The Energy Makers Acaedmy hardware gives you hands-on experience of a solar charge controller. As you move through the programme you will design, test and build circuits on a dedicated printed circuit board (PCB), finishing with a fully fuctioning solar home system.",
};

export const searchIcon29Data = {
    spanText: "UNIVAERSITY OF ZAMBIA<br />October 2021<br /><br />",
};

export const textsearchfield78Data = {
    className: "text-search-field-8",
    searchIcon2Props: searchIcon29Data,
};

export const searchIcon210Data = {
    spanText: "COPPERBELT UNIVERSITY<br />November 2021<br /><br />",
};

export const searchIcon211Data = {
    spanText: "SOLWEZI TRADES<br />December 2021<br /><br />",
};

export const textsearchfield79Data = {
    searchIcon2Props: searchIcon211Data,
};

export const searchIcon212Data = {
    spanText: "LBTC<br />January 2022<br /><br />",
};

export const textsearchfield710Data = {
    searchIcon2Props: searchIcon212Data,
};

export const searchIcon213Data = {
    spanText: "LIBES<br />February 2022<br /><br />",
};

export const textsearchfield711Data = {
    className: "text-search-field-9",
    searchIcon2Props: searchIcon213Data,
};

export const searchIcon214Data = {
    spanText: "NORTEC<br />March 2022<br /><br />",
};

export const textsearchfield712Data = {
    searchIcon2Props: searchIcon214Data,
};

export const searchIcon215Data = {
    spanText: "LUANSHYA TRADES<br />April 2022<br /><br />",
};

export const textsearchfield713Data = {
    searchIcon2Props: searchIcon215Data,
};

export const searchIcon216Data = {
    spanText: "CHIZONGWE TECH<br />May 2022<br /><br />",
};

export const textsearchfield714Data = {
    searchIcon2Props: searchIcon216Data,
};

export const searchIcon7Data = {
    joinAProgramme: "→ JOIN A PROGRAMME",
};

export const searchIcon8Data = {
    joinAProgramme: "→ PARTNER WITH US",
};

export const textsearchfield86Data = {
    className: "text-search-field-4",
    searchIconProps: searchIcon8Data,
};

export const group6853Data = {
    spanText4: "<br />We work with organsations to help them maximise their impact  and  increase access to both educatioon, and energy.",
};

export const group68532Data = {
    spanText4: "<br />“I would recommend each and everyone to attend the workshop to try it out. Your lives won't be the same again.” - Wilson Banda",
    className: "group-6853-5",
};

export const searchIcon9Data = {
    joinAProgramme: "→ JOIN A PROGRAMME",
};

export const searchIcon10Data = {
    joinAProgramme: "→ LEARN MORE",
};

export const vector8Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c390fadbfb8eee2ef63e4f/img/vector-14@2x.png",
};

export const vector22Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c390fadbfb8eee2ef63e4f/img/vector-15@2x.png",
    className: "vector-16",
};

export const vector32Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c390fadbfb8eee2ef63e4f/img/vector-16@2x.png",
};

export const vector42Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c390fadbfb8eee2ef63e4f/img/vector-17@2x.png",
    className: "vector-21",
};

export const vector52Data = {
    src: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c390fadbfb8eee2ef63e4f/img/vector-18@2x.png",
    className: "vector-24",
};

export const textsearchfield57Data = {
    children: "EMA<br />32/6 Joseph Mwilwa Rd<br />Rhodes Park<br />Lusaka — Zambia<br /><br />View on Google Maps<br /><br />Email us<br />EMA Press kit",
};

export const textsearchfield58Data = {
    children: "PROGRAMMES<br />University of Zambia<br />Copperbelt University<br /><br /><br /><br />PROJECTS<br />Liquid Telcom<br />Name 2<br />Name 3",
};

export const group68403Data = {
    tEXTSEARCHFIELD5Props: textsearchfield57Data,
    tEXTSEARCHFIELD52Props: textsearchfield58Data,
};

export const group68252Data = {
    className: "group-6830",
};

export const mobWebsite1Data = {
    text: "",
    text1: "→",
    text2: "←",
    text5: "→",
    text6: "←",
    text3: "→",
    text4: "←",
    vector26: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c390fadbfb8eee2ef63e4f/img/vector-26@2x.png",
    vector2: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c390fadbfb8eee2ef63e4f/img/vector-8@2x.png",
    vector3: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c390fadbfb8eee2ef63e4f/img/vector-10@2x.png",
    vector4: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c390fadbfb8eee2ef63e4f/img/vector-11@2x.png",
    vector5: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c390fadbfb8eee2ef63e4f/img/vector-12@2x.png",
    vector6: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c390fadbfb8eee2ef63e4f/img/vector-9@2x.png",
    x121170480_176224507454118_115380622: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61b8c319d1d7cd48b84e3938/img/121170480-176224507454118-1153806274680853683-n-1@2x.png",
    answersHub: "ANSWERS HUB",
    x131662611_3760936164026451_87872492: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61b8c319d1d7cd48b84e3938/img/131662611-3760936164026451-8787249473412765197-n-1@2x.png",
    spanText: "WHAT IS ENERGY MAKERS ACADEMY?<br />",
    spanText2: "",
    spanText3: "<br />",
    spanText4: "<br />Energy Makers Academy is an app and hardware kit which teaches you how to build and maintain a solar charge controller.",
    x131662611_3760936164026451_87872493: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61b8c319d1d7cd48b84e3938/img/131662611-3760936164026451-8787249473412765197-n-1@2x.png",
    whyPartnerWithUs: "WHY PARTNER WITH US?",
    x218432608_347909323618968_26240350: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61b8c319d1d7cd48b84e3938/img/218432608-347909323618968-2624035040922722286-n@1x.png",
    x131662611_3760936164026451_87872494: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61b8c319d1d7cd48b84e3938/img/131662611-3760936164026451-8787249473412765197-n-1@2x.png",
    whatHavePreviousStudentsSaid: "WHAT HAVE PREVIOUS STUDENTS SAID?",
    oel_Facebook: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61b8c319d1d7cd48b84e3938/img/oel-facebook@2x.png",
    x131662611_3760936164026451_87872495: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61b8c319d1d7cd48b84e3938/img/131662611-3760936164026451-8787249473412765197-n-1@2x.png",
    spanText5: "WHAT ARE THE BENEFITS OF JOINING?<br />",
    spanText6: "",
    spanText7: "<br />",
    spanText8: "<br />Through hands-on learning, you will gain skills in designing circuits, writing embedded software,  and designing a Solar Home System.",
    x129841425_202769898132912_96775093: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61b8c319d1d7cd48b84e3938/img/129841425-202769898132912-967750932130838834-n@2x.png",
    vector38: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c390fadbfb8eee2ef63e4f/img/vector-38-6@2x.png",
    emaFacebook: "EMA Facebook",
    emaYoutube: "EMA YouTube",
    emaTwitter: "EMA<br />Twitter",
    emaInstagram: "EMA Instagram",
    emaLinkedin: "EMA LinkedIn",
    vector39: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c390fadbfb8eee2ef63e4f/img/vector-35-7@2x.png",
    vector35: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c390fadbfb8eee2ef63e4f/img/vector-35-7@2x.png",
    vector352: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c390fadbfb8eee2ef63e4f/img/vector-35-7@2x.png",
    vector392: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c390fadbfb8eee2ef63e4f/img/vector-35-7@2x.png",
    vector37: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c390fadbfb8eee2ef63e4f/img/vector-38-6@2x.png",
    vector36: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c390fadbfb8eee2ef63e4f/img/vector-36-6@2x.png",
    vector353: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c390fadbfb8eee2ef63e4f/img/vector-35-6@2x.png",
    group6840: "https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector@2x.png",
    yourEmailAddress: "Your email address*",
    firstName: "First name",
    lastName: "Last name",
    phoneNumber: "Phone number",
    submit: "→ SUBMIT",
    firstName2: "First name",
    updatesNews: "UPDATES & NEWS",
    group6851Props: group6851Data,
    group68512Props: group68512Data,
    group68513Props: group68513Data,
    textsearchfield7Props: textsearchfield78Data,
    searchIcon2Props: searchIcon210Data,
    textsearchfield72Props: textsearchfield79Data,
    textsearchfield73Props: textsearchfield710Data,
    textsearchfield74Props: textsearchfield711Data,
    textsearchfield75Props: textsearchfield712Data,
    textsearchfield76Props: textsearchfield713Data,
    textsearchfield77Props: textsearchfield714Data,
    searchIconProps: searchIcon7Data,
    textsearchfield8Props: textsearchfield86Data,
    group6853Props: group6853Data,
    group68532Props: group68532Data,
    searchIcon2Props2: searchIcon9Data,
    searchIcon3Props: searchIcon10Data,
    vector8Props: vector8Data,
    vector2Props: vector22Data,
    vector32Props: vector32Data,
    vector4Props: vector42Data,
    vector5Props: vector52Data,
    group6840Props: group68403Data,
    group6825Props: group68252Data,
};

export const frame65Data = {
    className: "frame-7-1",
};

export const frame21Data = {
    spanText: "ABOUT US<br />",
    spanText2: "Mission & vision<br />Team<br />Partners<br />Get involved<br />Sponsor us",
    spanText3: "NEWS<br />",
    spanText4: "Latest newsNewsletter<br />Gallery",
    spanText5: "PROGRAMMES<br />",
    spanText6: "Programme name 1<br />Name 2<br />Name 3<br />Name 4<br />",
    spanText7: "<br />PROJECTS<br />",
    spanText8: "Project name 1<br />Name 2<br />Name 3",
    spanText9: "SOCIAL MEDIA<br />",
    spanText10: "↗ Facebook<br />↗ Twitter<br />↗ LinkedIn<br />↗ YouTube<br />↗ Instagram",
    spanText11: "EMA<br />",
    spanText12: "32/6 Joseph Mwilwa Rd<br />Rhodes Park<br />Lusaka — Zambia<br /><br />View on Google Maps<br /><br />Email us<br />EMA Press kit",
    spanText13: "ABOUT US<br />Mission & vision<br />Team<br />Partners<br />Get involved<br />Sponsor us<br />",
    spanText14: "<br />",
    spanText15: "NEWS<br />Latest newsNewsletter<br />Gallery",
    ema326JosephMwil: "EMA<br />32/6 Joseph Mwilwa Rd<br />Rhodes Park<br />Lusaka — Zambia<br /><br />View on Google Maps<br /><br />Email us<br />EMA Press kit",
    programmesUniversit: "PROGRAMMES<br />University of Zambia<br />Copperbelt University<br /><br /><br /><br />PROJECTS<br />Liquid Telcom<br />Name 2<br />Name 3",
    socialMediaFaceb: "SOCIAL MEDIA<br />↗ Facebook<br />↗ Twitter<br />↗ LinkedIn<br />↗ YouTube<br />↗ Instagram",
    frame6Props: frame65Data,
};

