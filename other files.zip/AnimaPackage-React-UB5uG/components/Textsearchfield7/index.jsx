import React from "react";
import SearchIcon2 from "../SearchIcon2";
import "./Textsearchfield7.css";

function Textsearchfield7(props) {
  const { className, searchIcon2Props } = props;

  return (
    <div className={`text-search-field-5-1 ${className || ""}`}>
      <SearchIcon2 spanText={searchIcon2Props.spanText} />
    </div>
  );
}

export default Textsearchfield7;
