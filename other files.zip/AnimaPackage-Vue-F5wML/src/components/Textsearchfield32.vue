<template>
  <div :class="[`text-search-field-18`, className || ``]">
    <div class="search-icon-14">
      <p class="social-media-faceb gellix-regular-normal-white-12px-2">
        <span class="span-10 gellix-regular-normal-white-12px">SOCIAL MEDIA<br /></span
        ><span class="span-10 gellix-regular-normal-dull-lavender-12px"
          >↗ Facebook<br />↗ Twitter<br />↗ LinkedIn<br />↗ YouTube<br />↗ Instagram</span
        >
      </p>
    </div>
  </div>
</template>

<script>
export default {
  name: "Textsearchfield32",
  props: ["className"],
};
</script>

<style>
.text-search-field-18 {
  align-items: center;
  display: flex;
  height: 279px;
  left: 0;
  position: absolute;
  top: 170px;
  width: 151px;
}

.search-icon-14 {
  align-items: center;
  display: flex;
  width: 153px;
}

.social-media-faceb {
  height: 279.12px;
  letter-spacing: 0.6px;
  line-height: 15.5px;
  width: 151px;
}

.span-10 {
  letter-spacing: 0.07px;
}

.text-search-field-18.text-search-field-20 {
  height: 277px;
  top: 169px;
}

.text-search-field-18.text-search-field-20 .social-media-faceb {
  height: 276.86px;
}
</style>
