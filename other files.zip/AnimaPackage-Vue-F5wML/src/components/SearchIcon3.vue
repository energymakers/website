<template>
  <div class="search-icon-17">
    <div class="programmes valign-text-middle gellix-regular-normal-white-18px">PROGRAMMES</div>
  </div>
</template>

<script>
export default {
  name: "SearchIcon3",
};
</script>

<style>
.search-icon-17,
.search-icon-18 {
  align-items: center;
  display: flex;
  justify-content: center;
  margin-left: 2px;
  margin-top: 0.5px;
  width: 218.56px;
}

.programmes,
.programmes-1 {
  height: 20.13px;
  letter-spacing: 0.9px;
  line-height: 14.5px;
  margin-left: -2px;
  text-align: center;
  width: 216.56px;
}
</style>
