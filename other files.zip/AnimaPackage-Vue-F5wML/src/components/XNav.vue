<template>
  <div class="nav-1">
    <div class="group-6808-1">
      <div class="overlap-group-7">
        <div class="group-6806"></div>
        <img
          class="vector-35-4"
          src="https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-35@2x.png"
        />
        <img
          class="vector-3-1"
          src="https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-37-5@2x.png"
        />
        <img
          class="vector-3-1"
          src="https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-38-5@2x.png"
        />
        <img
          class="vector-36-3"
          src="https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-36-7@2x.png"
        />
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "XNav",
};
</script>

<style>
.nav-1,
.nav-2 {
  display: flex;
  height: 64px;
  left: 296px;
  position: fixed;
  top: 0;
  width: 64px;
  z-index: 2;
}

.group-6808-1,
.group-6808-2 {
  align-items: flex-end;
  background-color: var(--ema-violet);
  display: flex;
  height: 64px;
  min-width: 64px;
}

.overlap-group-7,
.overlap-group-8 {
  height: 65px;
  margin-bottom: -0.5px;
  margin-left: -1px;
  position: relative;
  width: 65px;
}

.group-6806,
.group-6806-1 {
  background-color: var(--dull-lavender-2);
  height: 64px;
  left: 1px;
  position: absolute;
  top: 0;
  width: 64px;
}

.vector-35-4,
.vector-35-5 {
  height: 64px;
  left: 0;
  position: absolute;
  top: 0;
  width: 2px;
}

.vector-3-1,
.vector-3-2 {
  height: 46px;
  left: 10px;
  position: absolute;
  top: 9px;
  width: 46px;
}

.vector-36-3,
.vector-36-4 {
  height: 1px;
  left: 1px;
  position: absolute;
  top: 64px;
  width: 64px;
}
</style>
