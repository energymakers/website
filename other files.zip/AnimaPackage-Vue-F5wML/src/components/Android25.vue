<template>
  <div class="container-center-horizontal">
    <div class="android-25 screen">
      <div class="overlap-group7-1">
        <div class="rectangle-250-1"></div>
        <div class="group-6817">
          <div class="group-6811"><img class="polygon-1" :src="polygon1" /></div>
        </div>
        <div class="overlap-group-9">
          <group6813 />
          <div class="text-search-field-27">
            <div class="search-icon-27">
              <p class="partners-of-ema valign-text-middle gellix-regular-normal-minsk-12px">{{ partnersOfEma }}</p>
            </div>
          </div>
        </div>
        <div class="overlap-group1-3">
          <group6813 />
          <div class="text-search-field-28">
            <div class="search-icon-28">
              <p class="get-involved-with-ema valign-text-middle gellix-regular-normal-minsk-12px">
                {{ getInvolvedWithEma }}
              </p>
            </div>
          </div>
        </div>
        <div class="mission-and-vision-t">
          <span class="span0">{{ spanText }}</span
          ><span class="span1">{{ spanText2 }}</span>
        </div>
        <div class="overlap-group2-2">
          <group6813 />
          <textsearchfield :children="textsearchfieldProps.children" />
        </div>
        <div class="group-6838-1">
          <div class="group-container-1">
            <div class="overlap-group4">
              <div class="text-search-field-29">
                <div class="search-icon-29">
                  <router-link to="/android-25">
                    <p class="about-us-mission-v-1 gellix-regular-normal-white-12px-2">
                      <span class="span-13 gellix-regular-normal-white-12px">{{ spanText3 }}</span
                      ><span class="span-13 gellix-regular-normal-dull-lavender-12px">{{ spanText4 }}</span>
                    </p>
                  </router-link>
                  <div class="news-latest-news-newsletter-gallery gellix-regular-normal-white-12px-2">
                    <span class="span-13 gellix-regular-normal-white-12px">{{ spanText5 }}</span
                    ><span class="span-13 gellix-regular-normal-dull-lavender-12px">{{ spanText6 }}</span>
                  </div>
                </div>
              </div>
              <group6839
                :vector41="group6839Props.vector41"
                :vector42="group6839Props.vector42"
                :tEXTSEARCHFIELD4Props="group6839Props.tEXTSEARCHFIELD4Props"
              />
            </div>
            <div class="text-search-field-container-2">
              <textsearchfield2 />
              <textsearchfield32 />
            </div>
            <group6840
              :tEXTSEARCHFIELD5Props="group6840Props.tEXTSEARCHFIELD5Props"
              :tEXTSEARCHFIELD52Props="group6840Props.tEXTSEARCHFIELD52Props"
            />
          </div>
        </div>
        <div class="group-6840" :style="{ 'background-image': 'url(' + group6840 + ')' }"></div>
        <frame6 :className="frame6Props.className" />
      </div>
      <a href="javascript:ShowOverlay('android-23', 'animate-appear');">
        <div class="nav-3">
          <div class="group-container-2">
            <div class="group-6808-3">
              <div class="overlap-group-10">
                <div class="group-6806-2"></div>
                <img class="vector-35-6" :src="vector35" /><img class="vector-36-5" :src="vector36" />
              </div>
            </div>
            <group6810 />
          </div></div></a
      ><group6825 />
    </div>
  </div>
</template>

<script>
import Group6813 from "./Group6813";
import Textsearchfield from "./Textsearchfield";
import Group6839 from "./Group6839";
import Textsearchfield2 from "./Textsearchfield2";
import Textsearchfield32 from "./Textsearchfield32";
import Group6840 from "./Group6840";
import Frame6 from "./Frame6";
import Group6810 from "./Group6810";
import Group6825 from "./Group6825";
export default {
  name: "Android25",
  components: {
    Group6813,
    Textsearchfield,
    Group6839,
    Textsearchfield2,
    Textsearchfield32,
    Group6840,
    Frame6,
    Group6810,
    Group6825,
  },
  props: [
    "polygon1",
    "partnersOfEma",
    "getInvolvedWithEma",
    "spanText",
    "spanText2",
    "spanText3",
    "spanText4",
    "spanText5",
    "spanText6",
    "group6840",
    "vector35",
    "vector36",
    "textsearchfieldProps",
    "group6839Props",
    "group6840Props",
    "frame6Props",
  ],
};
</script>

<style>
.android-25 {
  align-items: flex-start;
  background-color: #dbdbdb;
  display: flex;
  height: 640px;
  min-width: 360px;
  position: relative;
}

.overlap-group7-1 {
  height: 2405px;
  position: relative;
  width: 360px;
  z-index: 1;
}

.rectangle-250-1 {
  background-color: var(--lines);
  height: 1952px;
  left: 0;
  position: absolute;
  top: 0;
  width: 360px;
}

.group-6817 {
  background-color: var(--ema-yellow);
  display: flex;
  height: 178px;
  left: 16px;
  position: absolute;
  top: 85px;
  width: 328px;
}

.group-6811 {
  background-color: #453b7373;
  border-radius: 5px;
  display: flex;
  height: 35.24px;
  margin-left: 136.7px;
  margin-top: 71.6px;
  width: 55.44px;
}

.polygon-1 {
  height: 17.5px;
  margin-left: 18.5px;
  margin-top: 9.1px;
  width: 17px;
}

.overlap-group-9 {
  height: 371px;
  left: 18px;
  position: absolute;
  top: 953px;
  width: 326px;
}

.text-search-field-27 {
  align-items: center;
  background-color: var(--biloba-flower);
  border-radius: 8px;
  display: flex;
  height: 47px;
  justify-content: center;
  left: 1px;
  position: absolute;
  top: 263px;
  width: 190px;
}

.search-icon-27 {
  align-items: center;
  display: flex;
  justify-content: center;
  margin-left: 2.4px;
  margin-top: 0.7px;
  width: 168.5px;
}

.partners-of-ema {
  height: 18.4px;
  letter-spacing: 0.6px;
  line-height: 14.5px;
  margin-left: -2px;
  text-align: center;
  width: 166.5px;
}

.overlap-group1-3 {
  height: 371px;
  left: 18px;
  position: absolute;
  top: 1394px;
  width: 326px;
}

.text-search-field-28 {
  align-items: center;
  background-color: var(--biloba-flower);
  border-radius: 8px;
  display: flex;
  height: 47px;
  justify-content: center;
  left: 1px;
  position: absolute;
  top: 263px;
  width: 228px;
}

.search-icon-28 {
  align-items: center;
  display: flex;
  justify-content: center;
  margin-left: 2.5px;
  margin-top: 0.7px;
  width: 201.83px;
}

.get-involved-with-ema {
  height: 18.4px;
  letter-spacing: 0.6px;
  line-height: 14.5px;
  margin-left: -2px;
  text-align: center;
  width: 199.83px;
}

.mission-and-vision-t {
  color: transparent;
  font-family: var(--font-family-gellix-regular);
  font-size: var(--font-size-xl);
  font-weight: 400;
  left: 18px;
  letter-spacing: 0.48px;
  line-height: 21.5px;
  position: absolute;
  top: 320px;
  width: 171px;
}

.span0 {
  color: var(--ema-dark-violet);
  letter-spacing: 0.08px;
}

.span1 {
  color: #ffffff80;
  letter-spacing: 0.08px;
}

.overlap-group2-2 {
  height: 371px;
  left: 18px;
  position: absolute;
  top: 515px;
  width: 326px;
}

.group-6838-1 {
  align-items: flex-start;
  background-color: var(--ema-violet);
  display: flex;
  height: 627px;
  left: 0;
  min-width: 360px;
  position: absolute;
  top: 1765px;
}

.group-container-1 {
  height: 625px;
  position: relative;
  width: 360px;
}

.overlap-group4 {
  height: 449px;
  left: 16px;
  position: absolute;
  top: 114px;
  width: 154px;
}

.text-search-field-29 {
  align-items: center;
  display: flex;
  height: 279px;
  left: 2px;
  position: absolute;
  top: 170px;
  width: 152px;
}

.search-icon-29 {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  min-height: 279px;
  width: 156px;
}

.about-us-mission-v-1 {
  cursor: pointer;
  letter-spacing: 0.6px;
  line-height: 15.5px;
  min-height: 95px;
  width: 102px;
}

.span-13 {
  letter-spacing: 0.07px;
}

.news-latest-news-newsletter-gallery {
  letter-spacing: 0.6px;
  line-height: 15.5px;
  margin-top: 20px;
  min-height: 164px;
  width: 152px;
}

.text-search-field-container-2 {
  height: 449px;
  left: 184px;
  position: absolute;
  top: 114px;
  width: 152px;
}

.group-6840 {
  background-size: 100% 100%;
  height: 30px;
  left: 17px;
  position: absolute;
  top: 1784px;
  width: 82px;
}

.nav-3 {
  align-items: flex-start;
  cursor: pointer;
  display: flex;
  height: 64px;
  left: 0;
  min-width: 360px;
  position: fixed;
  top: 0;
  z-index: 2;
}

.group-container-2 {
  height: 64px;
  position: relative;
  width: 360px;
}

.group-6808-3 {
  align-items: flex-end;
  background-color: var(--ema-violet);
  display: flex;
  height: 64px;
  left: 0;
  min-width: 360px;
  position: absolute;
  top: 0;
}

.overlap-group-10 {
  height: 65px;
  margin-bottom: -0.5px;
  position: relative;
  width: 360px;
}

.group-6806-2 {
  background-color: var(--dull-lavender-2);
  height: 64px;
  left: 296px;
  position: absolute;
  top: 0;
  width: 64px;
}

.vector-35-6 {
  height: 64px;
  left: 295px;
  position: absolute;
  top: 0;
  width: 2px;
}

.vector-36-5 {
  height: 1px;
  left: 0;
  position: absolute;
  top: 64px;
  width: 360px;
}
</style>
