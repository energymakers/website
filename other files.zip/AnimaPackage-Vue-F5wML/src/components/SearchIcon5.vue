<template>
  <div class="search-icon-23"><div class="news valign-text-middle gellix-regular-normal-white-18px">NEWS</div></div>
</template>

<script>
export default {
  name: "SearchIcon5",
};
</script>

<style>
.search-icon-23,
.search-icon-24 {
  align-items: center;
  display: flex;
  justify-content: center;
  margin-left: 2px;
  margin-top: 0.5px;
  width: 124.85px;
}

.news,
.news-1 {
  height: 20.13px;
  letter-spacing: 0.9px;
  line-height: 14.5px;
  margin-left: -2px;
  text-align: center;
  width: 122.85px;
}
</style>
