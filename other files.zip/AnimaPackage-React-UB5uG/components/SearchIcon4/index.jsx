import React from "react";
import "./SearchIcon4.css";

function SearchIcon4() {
  return (
    <div className="search-icon-21">
      <div className="about valign-text-middle gellix-regular-normal-white-18px">ABOUT</div>
    </div>
  );
}

export default SearchIcon4;
