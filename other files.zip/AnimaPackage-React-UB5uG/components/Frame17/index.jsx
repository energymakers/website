import React from "react";
import "./Frame17.css";

function Frame17() {
  return (
    <div className="container-center-horizontal">
      <div className="frame-17 screen"></div>
    </div>
  );
}

export default Frame17;
