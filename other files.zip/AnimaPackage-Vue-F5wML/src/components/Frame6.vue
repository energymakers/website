<template>
  <div :class="[`frame-6`, className || ``]">
    <p class="copyright-2021-energy-makers-academy valign-text-middle gellix-regular-normal-white-11px">
      © Copyright 2021, Energy Makers Academy
    </p>
  </div>
</template>

<script>
export default {
  name: "Frame6",
  props: ["className"],
};
</script>

<style>
.frame-6 {
  align-items: center;
  background-color: var(--ema-dark-violet);
  display: flex;
  height: 33px;
  left: 0;
  position: absolute;
  top: 607px;
  width: 360px;
}

.copyright-2021-energy-makers-academy {
  height: 33px;
  letter-spacing: 0.55px;
  line-height: 14.5px;
  margin-left: 17px;
  width: 333px;
}

.frame-6.frame-6-1 {
  top: 2372px;
}

.frame-6.frame-7-1 {
  align-items: flex-start;
  justify-content: flex-end;
  min-width: 360px;
  padding: 0 10px;
  width: unset;
}

.frame-6.frame-7-1 .copyright-2021-energy-makers-academy {
  margin-left: unset;
}
</style>
