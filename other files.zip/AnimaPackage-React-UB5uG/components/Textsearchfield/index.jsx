import React from "react";
import "./Textsearchfield.css";

function Textsearchfield(props) {
  const { children, className } = props;

  return (
    <div className={`text-search-field-30 ${className || ""}`}>
      <div className="search-icon-31">
        <p className="meet-the-ema-team valign-text-middle gellix-regular-normal-minsk-12px">{children}</p>
      </div>
    </div>
  );
}

export default Textsearchfield;
