import React from "react";
import TEXTSEARCHFIELD4 from "../TEXTSEARCHFIELD4";
import "./Group6839.css";

function Group6839(props) {
  const { vector41, vector42, className, tEXTSEARCHFIELD4Props } = props;

  return (
    <div className={`group-6839-2 ${className || ""}`}>
      <div className="group-6839-3">
        <div className="overlap-group-11">
          <TEXTSEARCHFIELD4 className={tEXTSEARCHFIELD4Props.className} />
          <img className="vector-41-1" src={vector41} />
          <img className="vector-42-1" src={vector42} />
        </div>
      </div>
    </div>
  );
}

export default Group6839;
