import React from "react";
import Textsearchfield8 from "../Textsearchfield8";
import "./Group6882.css";

function Group6882(props) {
  const { spanText, className, textsearchfield8Props } = props;

  return (
    <div className={`group-6882 ${className || ""}`}>
      <div className="group-6858">
        <img className="x131662611_3760936164" src="/img/rectangle-258@2x.png" />
        <div className="group-6853">
          <div className="group-6814">
            <p className="what-is-energy-maker gellix-regular-normal-white-12px-2">
              <span className="span-3 gellix-regular-normal-white-12px">{spanText}</span>
              <span className="span-3 gellix-regular-normal-minsk-12px">
                <br />– EMA students learn practical skills
                <br />– EMA students become part of cohort
                <br />– EMA students learn practical skills
                <br />– EMA students become part of cohort
              </span>
            </p>
          </div>
        </div>
      </div>
      <Textsearchfield8
        className={textsearchfield8Props.className}
        searchIconProps={textsearchfield8Props.searchIconProps}
      />
    </div>
  );
}

export default Group6882;
