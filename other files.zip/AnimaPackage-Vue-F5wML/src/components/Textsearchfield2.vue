<template>
  <div :class="[`text-search-field-15`, className || ``]">
    <div class="search-icon-11">
      <p class="programmes-programme gellix-regular-normal-white-12px-2">
        <span class="span-7 gellix-regular-normal-white-12px">PROGRAMMES<br /></span
        ><span class="span-7 gellix-regular-normal-dull-lavender-12px"
          >Programme name 1<br />Name 2<br />Name 3<br />Name 4<br /></span
        ><span class="span-7 gellix-regular-normal-white-12px"><br />PROJECTS<br /></span
        ><span class="span-7 gellix-regular-normal-dull-lavender-12px">Project name 1<br />Name 2<br />Name 3</span>
      </p>
    </div>
  </div>
</template>

<script>
export default {
  name: "Textsearchfield2",
  props: ["className"],
};
</script>

<style>
.text-search-field-15 {
  align-items: center;
  display: flex;
  height: 285px;
  left: 0;
  position: absolute;
  top: 0;
  width: 152px;
}

.search-icon-11 {
  align-items: center;
  display: flex;
  width: 154px;
}

.programmes-programme {
  height: 285px;
  letter-spacing: 0.6px;
  line-height: 15.5px;
  width: 152px;
}

.span-7 {
  letter-spacing: 0.07px;
}

.text-search-field-15.text-search-field-17 {
  height: 283px;
}

.text-search-field-15.text-search-field-17 .programmes-programme {
  height: 282.69px;
}
</style>
