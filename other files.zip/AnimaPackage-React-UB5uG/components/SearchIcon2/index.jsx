import React from "react";
import "./SearchIcon2.css";

function SearchIcon2(props) {
  const { spanText } = props;

  return (
    <div className="search-icon-3">
      <p className="title-of-programme gellix-regular-normal-white-12px-2">
        <span className="span-1 gellix-regular-normal-white-12px">{spanText}</span>
        <span className="span-1 gellix-regular-normal-dull-lavender-12px">→ More info</span>
      </p>
    </div>
  );
}

export default SearchIcon2;
