<template>
  <div :class="[`text-search-field-33`, className || ``]">
    <div class="search-icon-33">
      <p class="about-us-mission-v-2 gellix-regular-normal-white-12px-2">
        <span class="span-14 gellix-regular-normal-white-12px"
          >ABOUT US<br />Mission &amp; vision<br />Team<br />Partners<br />Get involved<br />Sponsor us<br /></span
        ><span class="span-14 gellix-regular-normal-tasman-12px"><br /></span
        ><span class="span-14 gellix-regular-normal-white-12px">NEWS<br />Latest newsNewsletter<br />Gallery</span>
      </p>
    </div>
  </div>
</template>

<script>
export default {
  name: "Textsearchfield42",
  props: ["className"],
};
</script>

<style>
.text-search-field-33 {
  align-items: center;
  display: flex;
  height: 278px;
  left: 2px;
  position: absolute;
  top: 169px;
  width: 152px;
}

.search-icon-33 {
  align-items: center;
  display: flex;
  width: 154px;
}

.about-us-mission-v-2 {
  height: 278.23px;
  letter-spacing: 0.6px;
  line-height: 15.5px;
  width: 152px;
}

.span-14 {
  letter-spacing: 0.07px;
}

.text-search-field-33.text-search-field-34 {
  height: 276px;
  top: 168px;
}

.text-search-field-33.text-search-field-34 .about-us-mission-v-2 {
  height: 275.98px;
}
</style>
