import React from "react";
import "./Vector.css";

function Vector(props) {
  const { src } = props;

  return (
    <div className="vector-12">
      <img className="vector-13" src={src} />
    </div>
  );
}

export default Vector;
