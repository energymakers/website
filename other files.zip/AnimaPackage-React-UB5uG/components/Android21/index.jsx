import React from "react";
import { Link } from "react-router-dom";
import Textsearchfield from "../Textsearchfield";
import Frame from "../Frame";
import Group68132 from "../Group68132";
import Group6839 from "../Group6839";
import Textsearchfield2 from "../Textsearchfield2";
import Textsearchfield3 from "../Textsearchfield3";
import Textsearchfield4 from "../Textsearchfield4";
import Textsearchfield5 from "../Textsearchfield5";
import Textsearchfield6 from "../Textsearchfield6";
import Group6840 from "../Group6840";
import Frame6 from "../Frame6";
import "./Android21.css";

function Android21(props) {
  const {
    x218432609,
    universityOfZambia,
    vector35,
    vector36,
    vector38,
    vector37,
    vector39,
    copperbeltUniversit,
    cbu1,
    spanText,
    spanText2,
    spanText3,
    spanText4,
    vector41,
    vector42,
    group6840,
    spanText5,
    spanText6,
    spanText7,
    spanText8,
    group6842,
    textsearchfieldProps,
    textsearchfield2Props,
    group68132Props,
    group6839Props,
    textsearchfield2Props2,
    textsearchfield3Props,
    textsearchfield4Props,
    textsearchfield5Props,
    textsearchfield52Props,
    textsearchfield6Props,
    group68392Props,
    group6840Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="android-21 screen">
        <div className="overlap-group12">
          <div className="overlap-group13">
            <div className="rectangle-261"></div>
            <img className="x218432609" src={x218432609} />
          </div>
          <p className="university-of-zambia gellix-regular-normal-white-15-9px">{universityOfZambia}</p>
          <Textsearchfield className={textsearchfieldProps.className}>{textsearchfieldProps.children}</Textsearchfield>
        </div>
        <div className="nav-4">
          <div className="group-container-3">
            <div className="overlap-group-16">
              <div className="group-6806-3"></div>
              <img className="vector-35-7" src={vector35} />
              <img className="vector-36-6" src={vector36} />
            </div>
            <Link to="/mob-website-1">
              <div className="group-6810-3">
                <Frame />
              </div>
            </Link>
          </div>
        </div>
        <a href="javascript:ShowOverlay('android-24', 'animate-appear');">
          <div className="group-6825-2">
            <img className="vector-38-5" src={vector38} />
            <img className="vector-37-4" src={vector37} />
            <img className="vector-39-5" src={vector39} />
          </div>
        </a>
        <Group68132 />
        <div className="overlap-group11-1">
          <div className="group-6912">
            <div className="rectangle-261-1"></div>
            <p className="copperbelt-universit-1 gellix-regular-normal-white-15-9px">{copperbeltUniversit}</p>
            <Textsearchfield className={textsearchfield2Props.className}>
              {textsearchfield2Props.children}
            </Textsearchfield>
            <Group68132 className={group68132Props.className} />
          </div>
          <img className="cbu-1" src={cbu1} />
        </div>
        <div className="footer-1">
          <div className="overlap-group9-1">
            <div className="group-6838-3">
              <div className="group-container-4">
                <div className="overlap-group4-1">
                  <div className="text-search-field-42">
                    <div className="search-icon-41">
                      <Link to="/android-25">
                        <p className="about-us-mission-v-3 gellix-regular-normal-white-12px-2">
                          <span className="span-17 gellix-regular-normal-white-12px">{spanText}</span>
                          <span className="span-17 gellix-regular-normal-dull-lavender-12px">{spanText2}</span>
                        </p>
                      </Link>
                      <div className="news-latest-news-newsletter-gallery-1 gellix-regular-normal-white-12px-2">
                        <span className="span-17 gellix-regular-normal-white-12px">{spanText3}</span>
                        <span className="span-17 gellix-regular-normal-dull-lavender-12px">{spanText4}</span>
                      </div>
                    </div>
                  </div>
                  <Group6839
                    vector41={group6839Props.vector41}
                    vector42={group6839Props.vector42}
                    className={group6839Props.className}
                    tEXTSEARCHFIELD4Props={group6839Props.tEXTSEARCHFIELD4Props}
                  />
                </div>
                <div className="text-search-field-container-6">
                  <Textsearchfield2 className={textsearchfield2Props2.className} />
                  <Textsearchfield3 className={textsearchfield3Props.className} />
                </div>
                <div className="group-6840-3">
                  <div className="overlap-group1-6">
                    <Textsearchfield4 className={textsearchfield4Props.className} />
                    <div className="group-6839-13">
                      <div className="group-6839-14">
                        <div className="overlap-group-17">
                          <Textsearchfield5 className={textsearchfield5Props.className}>
                            {textsearchfield5Props.children}
                          </Textsearchfield5>
                          <img className="vector-41-6" src={vector41} />
                          <img className="vector-42-6" src={vector42} />
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="text-search-field-container-7">
                    <Textsearchfield5 className={textsearchfield52Props.className}>
                      {textsearchfield52Props.children}
                    </Textsearchfield5>
                    <Textsearchfield6 className={textsearchfield6Props.className} />
                  </div>
                </div>
              </div>
            </div>
            <div className="group-6840-4" style={{ backgroundImage: `url(${group6840})` }}></div>
            <div className="group-6841">
              <div className="group-container-5">
                <div className="overlap-group6-1">
                  <div className="text-search-field-43">
                    <div className="search-icon-42">
                      <Link to="/android-25">
                        <p className="about-us-mission-v-6 gellix-regular-normal-white-12px-2">
                          <span className="span-17 gellix-regular-normal-white-12px">{spanText5}</span>
                          <span className="span-17 gellix-regular-normal-dull-lavender-12px">{spanText6}</span>
                        </p>
                      </Link>
                      <div className="news-latest-news-newsletter-gallery-2 gellix-regular-normal-white-12px-2">
                        <span className="span-17 gellix-regular-normal-white-12px">{spanText7}</span>
                        <span className="span-17 gellix-regular-normal-dull-lavender-12px">{spanText8}</span>
                      </div>
                    </div>
                  </div>
                  <Group6839
                    vector41={group68392Props.vector41}
                    vector42={group68392Props.vector42}
                    tEXTSEARCHFIELD4Props={group68392Props.tEXTSEARCHFIELD4Props}
                  />
                </div>
                <div className="text-search-field-container-8">
                  <Textsearchfield2 />
                  <Textsearchfield3 />
                </div>
                <Group6840
                  tEXTSEARCHFIELD5Props={group6840Props.tEXTSEARCHFIELD5Props}
                  tEXTSEARCHFIELD52Props={group6840Props.tEXTSEARCHFIELD52Props}
                />
              </div>
            </div>
            <div className="group-6842" style={{ backgroundImage: `url(${group6842})` }}></div>
            <Frame6 />
          </div>
        </div>
      </div>
    </div>
  );
}

export default Android21;
