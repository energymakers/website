import React from "react";
import "./SearchIcon5.css";

function SearchIcon5() {
  return (
    <div className="search-icon-23">
      <div className="news valign-text-middle gellix-regular-normal-white-18px">NEWS</div>
    </div>
  );
}

export default SearchIcon5;
