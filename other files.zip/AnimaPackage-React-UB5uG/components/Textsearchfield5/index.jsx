import React from "react";
import "./Textsearchfield5.css";

function Textsearchfield5(props) {
  const { children, className } = props;

  return (
    <div className={`text-search-field-36-1 ${className || ""}`}>
      <div className="search-icon-35">
        <p className="ema-326-joseph-mwil-2 gellix-regular-normal-white-12px">{children}</p>
      </div>
    </div>
  );
}

export default Textsearchfield5;
