import React from "react";
import "./Group6813.css";

function Group6813() {
  return (
    <div className="group-6813">
      <p className="we-teach-students-th-1 gellix-regular-normal-minsk-15-9px">
        We teach students through a “learn by making” approach, providing them with the skills and knowledge to develop
        universal access to electricity. Our mobile learning platform and integrated hardware demystifies energy
        systems, and offers powerful capabilities for their design. We empower and inspire people and communities to
        innovate towards affordable, reliable and sustainable energy systems.
      </p>
      <img className="vector-25-1" src="/img/vector-25@2x.png" />
    </div>
  );
}

export default Group6813;
