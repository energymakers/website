import React from "react";
import Textsearchfield4 from "../Textsearchfield4";
import Textsearchfield5 from "../Textsearchfield5";
import Textsearchfield6 from "../Textsearchfield6";
import "./Group6840.css";

function Group6840(props) {
  const { tEXTSEARCHFIELD5Props, tEXTSEARCHFIELD52Props } = props;

  return (
    <div className="group-6840-1">
      <div className="overlap-group1-4">
        <Textsearchfield4 />
        <div className="group-6839-5">
          <div className="group-6839-8">
            <div className="overlap-group-12">
              <Textsearchfield5>{tEXTSEARCHFIELD5Props.children}</Textsearchfield5>
              <img className="vector-41-2" src="/img/vector-41-1@2x.png" />
              <img className="vector-42-2" src="/img/vector-42-1@2x.png" />
            </div>
          </div>
        </div>
      </div>
      <div className="text-search-field-container-3">
        <Textsearchfield5>{tEXTSEARCHFIELD52Props.children}</Textsearchfield5>
        <Textsearchfield6 />
      </div>
    </div>
  );
}

export default Group6840;
