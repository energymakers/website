import React from "react";
import "./Frame.css";

function Frame() {
  return (
    <div className="frame-1">
      <img className="vector-25" src="/img/vector-18@2x.png" />
    </div>
  );
}

export default Frame;
