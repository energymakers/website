<template>
  <div class="container-center-horizontal">
    <div class="frame-21 screen">
      <a href="javascript:ShowOverlay('android-23', 'animate-appear');">
        <div class="nav-6">
          <div class="overlap-group4-3">
            <div class="overlap-group-26">
              <div class="rectangle-236"></div>
              <div class="group-6806-4"></div>
              <img
                class="vector-35-12"
                src="https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61b8c319d1d7cd48b84e3938/img/vector-35-10@2x.svg"
              />
              <img
                class="vector-36-9"
                src="https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61b8c319d1d7cd48b84e3938/img/vector-36-2@2x.svg"
              />
            </div>
            <div class="frame-5">
              <img
                class="vector-48"
                src="https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61b8c319d1d7cd48b84e3938/img/vector-5@2x.svg"
              />
            </div>
          </div></div
      ></a>
      <div class="overlap-group5-1">
        <div class="group-6841-1">
          <div class="overlap-group3-4 gellix-regular-normal-white-12px-2">
            <div class="group-6815">
              <router-link to="/android-25">
                <p class="about-us-mission-v-7 gellix-regular-normal-white-12px-2">
                  <span class="span-20 gellix-regular-normal-white-12px">{{ spanText }}</span
                  ><span class="span-20 gellix-regular-normal-dull-lavender-12px">{{ spanText2 }}</span>
                </p>
              </router-link>
              <div class="news-latest-news-newsletter-gallery-3 gellix-regular-normal-white-12px-2">
                <span class="span-20 gellix-regular-normal-white-12px">{{ spanText3 }}</span
                ><span class="span-20 gellix-regular-normal-dull-lavender-12px">{{ spanText4 }}</span>
              </div>
            </div>
            <p class="programmes-programme-2">
              <span class="span-20 gellix-regular-normal-white-12px">{{ spanText5 }}</span
              ><span class="span-20 gellix-regular-normal-dull-lavender-12px">{{ spanText6 }}</span
              ><span class="span-20 gellix-regular-normal-white-12px">{{ spanText7 }}</span
              ><span class="span-20 gellix-regular-normal-dull-lavender-12px">{{ spanText8 }}</span>
            </p>
            <p class="social-media-faceb-4">
              <span class="span-20 gellix-regular-normal-white-12px">{{ spanText9 }}</span
              ><span class="span-20 gellix-regular-normal-dull-lavender-12px">{{ spanText10 }}</span>
            </p>
            <div class="overlap-group-27">
              <p class="ema-326-joseph-mwil-4">
                <span class="span-20 gellix-regular-normal-white-12px">{{ spanText11 }}</span
                ><span class="span-20 gellix-regular-normal-dull-lavender-12px">{{ spanText12 }}</span>
              </p>
              <img
                class="vector-41-7"
                src="https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61b8c319d1d7cd48b84e3938/img/vector-41@2x.svg"
              />
              <img
                class="vector-42-7"
                src="https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61b8c319d1d7cd48b84e3938/img/vector-42@2x.svg"
              />
            </div>
            <div class="group-6840-6">
              <div class="overlap-group1-10">
                <p class="about-us-mission-v-8">
                  <span class="span-20 gellix-regular-normal-white-12px">{{ spanText13 }}</span
                  ><span class="span-20 gellix-regular-normal-tasman-12px">{{ spanText14 }}</span
                  ><span class="span-20 gellix-regular-normal-white-12px">{{ spanText15 }}</span>
                </p>
                <div class="overlap-group-28">
                  <p class="ema-326-joseph-mwil-7 gellix-regular-normal-white-12px" v-html="ema326JosephMwil"></p>
                  <img
                    class="vector-41-7"
                    src="https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61b8c319d1d7cd48b84e3938/img/vector-41-8@2x.svg"
                  />
                  <img
                    class="vector-42-7"
                    src="https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61b8c319d1d7cd48b84e3938/img/vector-42-8@2x.svg"
                  />
                </div>
              </div>
              <div class="overlap-group2-5 gellix-regular-normal-white-12px">
                <p class="programmes-universit-1">{{ programmesUniversit }}</p>
                <p class="social-media-faceb-7" v-html="socialMediaFaceb"></p>
              </div>
            </div>
          </div>
        </div>
        <div class="group-6842-1"></div>
        <frame6 :className="frame6Props.className" />
      </div>
    </div>
  </div>
</template>

<script>
import Frame6 from "./Frame6";
export default {
  name: "Frame21",
  components: {
    Frame6,
  },
  props: [
    "spanText",
    "spanText2",
    "spanText3",
    "spanText4",
    "spanText5",
    "spanText6",
    "spanText7",
    "spanText8",
    "spanText9",
    "spanText10",
    "spanText11",
    "spanText12",
    "spanText13",
    "spanText14",
    "spanText15",
    "ema326JosephMwil",
    "programmesUniversit",
    "socialMediaFaceb",
    "frame6Props",
  ],
};
</script>

<style>
.frame-21 {
  align-items: flex-start;
  background-color: var(--ema-white);
  display: flex;
  min-width: 360px;
  overflow-x: hidden;
}

.nav-6 {
  align-items: flex-end;
  cursor: pointer;
  display: flex;
  height: 64px;
  left: -2px;
  min-width: 362px;
  position: fixed;
  top: 0;
  z-index: 2;
}

.overlap-group4-3 {
  height: 65px;
  margin-bottom: -1px;
  position: relative;
  width: 362px;
}

.overlap-group-26 {
  height: 65px;
  left: 0;
  position: absolute;
  top: 0;
  width: 362px;
}

.rectangle-236 {
  background-color: var(--ema-violet);
  height: 64px;
  left: 2px;
  position: absolute;
  top: 0;
  width: 360px;
}

.group-6806-4 {
  background-color: var(--dull-lavender-2);
  height: 64px;
  left: 296px;
  position: absolute;
  top: 0;
  width: 64px;
}

.vector-35-12 {
  height: 64px;
  left: 295px;
  position: absolute;
  top: 0;
  width: 2px;
}

.vector-36-9 {
  height: 2px;
  left: 0;
  position: absolute;
  top: 63px;
  width: 360px;
}

.frame-5 {
  align-items: flex-start;
  display: flex;
  height: 30px;
  left: 20px;
  overflow: hidden;
  position: absolute;
  top: 19px;
  width: 82px;
}

.vector-48 {
  height: 31px;
  margin-left: -1px;
  margin-top: -0.53px;
  width: 83px;
}

.overlap-group5-1 {
  height: 640px;
  margin-top: 704.07px;
  position: relative;
  width: 360px;
  z-index: 1;
}

.group-6841-1 {
  align-items: flex-start;
  background-color: var(--ema-violet);
  display: flex;
  height: 627px;
  left: 0;
  min-width: 360px;
  position: absolute;
  top: 0;
}

.overlap-group3-4 {
  height: 625px;
  position: relative;
  width: 360px;
}

.group-6815 {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  left: 18px;
  min-height: 279px;
  position: absolute;
  top: 284px;
  width: 152px;
}

.about-us-mission-v-7 {
  cursor: pointer;
  letter-spacing: 0.6px;
  line-height: 15.5px;
  min-height: 95px;
  width: 102px;
}

.span-20 {
  letter-spacing: 0.07px;
}

.news-latest-news-newsletter-gallery-3 {
  letter-spacing: 0.6px;
  line-height: 15.5px;
  margin-top: 20px;
  min-height: 164px;
  width: 152px;
}

.programmes-programme-2 {
  left: 184px;
  letter-spacing: 0.6px;
  line-height: 15.5px;
  position: absolute;
  top: 114px;
  width: 152px;
}

.social-media-faceb-4 {
  left: 184px;
  letter-spacing: 0.6px;
  line-height: 15.5px;
  position: absolute;
  top: 284px;
  width: 151px;
}

.overlap-group-27 {
  height: 285px;
  left: 16px;
  position: absolute;
  top: 114px;
  width: 152px;
}

.ema-326-joseph-mwil-4,
.ema-326-joseph-mwil-7,
.programmes-universit-1 {
  left: 0;
  letter-spacing: 0.6px;
  line-height: 15.5px;
  position: absolute;
  top: 0;
  width: 152px;
}

.vector-41-7 {
  height: 2px;
  left: 1px;
  position: absolute;
  top: 94px;
  width: 126px;
}

.vector-42-7 {
  height: 2px;
  left: 1px;
  position: absolute;
  top: 142px;
  width: 77px;
}

.group-6840-6 {
  align-items: flex-end;
  background-color: var(--ema-violet);
  display: flex;
  height: 625px;
  left: 0;
  min-width: 360px;
  padding: 63.7px 16px;
  position: absolute;
  top: 0;
}

.overlap-group1-10 {
  height: 448px;
  position: relative;
  width: 154px;
}

.about-us-mission-v-8 {
  left: 2px;
  letter-spacing: 0.6px;
  line-height: 15.5px;
  position: absolute;
  top: 169px;
  width: 152px;
}

.overlap-group-28 {
  height: 284px;
  left: 0;
  position: absolute;
  top: 0;
  width: 152px;
}

.overlap-group2-5 {
  height: 448px;
  margin-left: 14px;
  position: relative;
  width: 152px;
}

.social-media-faceb-7 {
  left: 0;
  letter-spacing: 0.6px;
  line-height: 15.5px;
  position: absolute;
  top: 169px;
  width: 151px;
}

.group-6842-1 {
  background-image: url(https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61b8c319d1d7cd48b84e3938/img/vector-1@2x.svg);
  background-size: 100% 100%;
  height: 30px;
  left: 17px;
  position: absolute;
  top: 19px;
  width: 82px;
}
</style>
