<template>
  <div :class="[`group-6825-1`, className || ``]">
    <img
      class="vector-38-3"
      src="https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-37@2x.png"
    />
    <img
      class="vector-37-2"
      src="https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-37@2x.png"
    />
    <img
      class="vector-39-3"
      src="https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-37@2x.png"
    />
  </div>
</template>

<script>
export default {
  name: "Group6825",
  props: ["className"],
};
</script>

<style>
.group-6825-1 {
  align-items: flex-end;
  display: flex;
  flex-direction: column;
  height: 16px;
  left: 311px;
  position: fixed;
  top: 24px;
  width: 35px;
  z-index: 3;
}

.vector-38-3 {
  height: 1px;
  margin-right: -0.4px;
  margin-top: -0.5px;
  width: 36px;
}

.vector-37-2 {
  height: 1px;
  margin-right: -0.4px;
  margin-top: 7px;
  width: 36px;
}

.vector-39-3 {
  height: 1px;
  margin-right: -0.4px;
  margin-top: 7px;
  width: 36px;
}

.group-6825-1.group-6830 {
  left: -251px;
  position: absolute;
  z-index: unset;
}
</style>
