import React from "react";
import "./Vector2.css";

function Vector2(props) {
  const { src, className } = props;

  return (
    <div className={`vector-14 ${className || ""}`}>
      <img className="vector-15" src={src} />
    </div>
  );
}

export default Vector2;
