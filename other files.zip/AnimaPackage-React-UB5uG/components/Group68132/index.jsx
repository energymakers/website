import React from "react";
import "./Group68132.css";

function Group68132(props) {
  const { className } = props;

  return (
    <div className={`group-6813-2 ${className || ""}`}>
      <div className="group-6813-1">
        <img className="vector-25-2" src="/img/vector-25-3@2x.png" />
      </div>
    </div>
  );
}

export default Group68132;
