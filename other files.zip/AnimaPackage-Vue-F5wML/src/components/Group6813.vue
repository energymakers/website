<template>
  <div class="group-6813">
    <p class="we-teach-students-th-1 gellix-regular-normal-minsk-15-9px">
      We teach students through a “learn by making” approach, providing them with the skills and knowledge to develop
      universal access to electricity. Our mobile learning platform and integrated hardware demystifies energy systems,
      and offers powerful capabilities for their design. We empower and inspire people and communities to innovate
      towards affordable, reliable and sustainable energy systems.
    </p>
    <img
      class="vector-25-1"
      src="https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-25@2x.png"
    />
  </div>
</template>

<script>
export default {
  name: "Group6813",
};
</script>

<style>
.group-6813 {
  display: flex;
  flex-direction: column;
  height: 371px;
  left: 0;
  position: absolute;
  top: 0;
  width: 326px;
}

.we-teach-students-th-1 {
  height: 229.37px;
  letter-spacing: 0.48px;
  line-height: 21.3px;
  width: 324px;
}

.vector-25-1 {
  flex: 1;
  margin-left: -0.1px;
  margin-right: 3.1px;
  margin-top: 140.8px;
  max-height: 1.5px;
}
</style>
