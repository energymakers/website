<template>
  <div class="container-center-horizontal">
    <div class="frame-17 screen"></div>
  </div>
</template>

<script>
export default {
  name: "Frame17",
};
</script>

<style>
.frame-17,
.frame-18 {
  height: 1414px;
  width: 360px;
}
</style>
