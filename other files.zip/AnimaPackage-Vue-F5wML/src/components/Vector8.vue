<template>
  <div class="vector-46" :style="{ 'background-image': 'url(' + src + ')' }"></div>
</template>

<script>
export default {
  name: "Vector8",
  props: ["src"],
};
</script>

<style>
.vector-46 {
  background-size: 100% 100%;
  height: 34px;
  left: 45px;
  position: absolute;
  top: 159px;
  width: 33px;
}
</style>
