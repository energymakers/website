<template>
  <div :class="[`text-search-field-40`, className || ``]">
    <div class="search-icon-39">
      <p class="social-media-faceb-2 gellix-regular-normal-white-12px">
        SOCIAL MEDIA<br />↗ Facebook<br />↗ Twitter<br />↗ LinkedIn<br />↗ YouTube<br />↗ Instagram
      </p>
    </div>
  </div>
</template>

<script>
export default {
  name: "Textsearchfield6",
  props: ["className"],
};
</script>

<style>
.text-search-field-40 {
  align-items: center;
  display: flex;
  height: 278px;
  left: 0;
  position: absolute;
  top: 169px;
  width: 151px;
}

.search-icon-39 {
  align-items: center;
  display: flex;
  width: 153px;
}

.social-media-faceb-2 {
  height: 278.23px;
  letter-spacing: 0.6px;
  line-height: 15.5px;
  width: 151px;
}

.text-search-field-40.text-search-field-41 {
  height: 276px;
  top: 168px;
}

.text-search-field-40.text-search-field-41 .social-media-faceb-2 {
  height: 275.98px;
}
</style>
