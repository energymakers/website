import React from "react";
import "./Group6825.css";

function Group6825(props) {
  const { className } = props;

  return (
    <div className={`group-6825-1 ${className || ""}`}>
      <img className="vector-38-3" src="/img/vector-37@2x.png" />
      <img className="vector-37-2" src="/img/vector-37@2x.png" />
      <img className="vector-39-3" src="/img/vector-37@2x.png" />
    </div>
  );
}

export default Group6825;
