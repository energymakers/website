<template>
  <div :class="[`vector-22`, className || ``]"><img class="vector-23" :src="src" /></div>
</template>

<script>
export default {
  name: "Vector5",
  props: ["src", "className"],
};
</script>

<style>
.vector-22 {
  align-items: center;
  display: flex;
  height: 48px;
  left: 167px;
  min-width: 26px;
  padding: 0 12.8px;
  position: absolute;
  top: 22px;
  transform: rotate(-90deg);
}

.vector-23 {
  height: 1px;
  transform: rotate(90deg);
  width: 1px;
}

.vector-22.vector-24 {
  justify-content: center;
  padding: unset;
  top: 23px;
}

.vector-22.vector-24 .vector-23 {
  height: 26px;
  width: 48px;
}
</style>
