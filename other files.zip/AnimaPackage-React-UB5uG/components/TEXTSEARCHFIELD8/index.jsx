import React from "react";
import "./TEXTSEARCHFIELD8.css";

function TEXTSEARCHFIELD8() {
  return (
    <div className="text-search-field-25">
      <div className="search-icon-25">
        <div className="contact-us valign-text-middle gellix-regular-normal-white-18px">CONTACT US</div>
      </div>
    </div>
  );
}

export default TEXTSEARCHFIELD8;
