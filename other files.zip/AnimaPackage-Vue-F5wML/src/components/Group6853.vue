<template>
  <div :class="[`group-6853-4`, className || ``]">
    <div class="group-6814-5">
      <div class="overlap-group-25 gellix-regular-normal-white-12px-2">
        <div class="text-5">
          <span class="span-19 gellix-regular-normal-white-12px"><br /></span
          ><span class="span-19 gellix-regular-normal-minsk-12px"></span>
        </div>
        <p class="we-work-with-organsa">
          <span class="span-19 gellix-regular-normal-white-12px"><br /></span
          ><span class="span-19 gellix-regular-normal-minsk-12px">{{ spanText4 }}</span>
        </p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Group6853",
  props: ["spanText4", "className"],
};
</script>

<style>
.group-6853-4 {
  align-items: flex-end;
  display: flex;
  height: 111px;
  left: 72px;
  position: absolute;
  top: 165px;
  width: 216px;
}

.group-6814-5 {
  align-items: flex-start;
  display: flex;
  min-width: 220px;
}

.overlap-group-25 {
  height: 111px;
  position: relative;
  width: 216px;
}

.text-5 {
  left: 107px;
  letter-spacing: 0.6px;
  line-height: 15.5px;
  position: absolute;
  text-align: center;
  top: 0;
}

.span-19 {
  letter-spacing: 0.07px;
}

.we-work-with-organsa {
  left: 0;
  letter-spacing: 0.6px;
  line-height: 15.5px;
  position: absolute;
  text-align: justify;
  top: 0;
  width: 216px;
}

.group-6853-4.group-6853-5 {
  left: 73px;
  top: 0;
}
</style>
