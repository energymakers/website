<template>
  <div class="text-search-field-25">
    <div class="search-icon-25">
      <div class="contact-us valign-text-middle gellix-regular-normal-white-18px">CONTACT US</div>
    </div>
  </div>
</template>

<script>
export default {
  name: "TEXTSEARCHFIELD8",
};
</script>

<style>
.text-search-field-25,
.text-search-field-26 {
  align-items: center;
  display: flex;
  height: 35.71px;
  justify-content: center;
  margin-left: 7px;
  margin-top: 12.1px;
  width: 202.17px;
}

.search-icon-25,
.search-icon-26 {
  align-items: center;
  display: flex;
  justify-content: center;
  margin-left: 2.2px;
  margin-top: 0.5px;
  width: 203.95px;
}

.contact-us,
.contact-us-1 {
  height: 20.13px;
  letter-spacing: 0.9px;
  line-height: 14.5px;
  margin-left: -2px;
  text-align: center;
  width: 201.95px;
}
</style>
