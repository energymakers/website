import "./App.css";
import React from "react";
import { Switch, BrowserRouter as Router, Route } from "react-router-dom";
import Android17 from "./components/Android17";
import Android23 from "./components/Android23";
import Android25 from "./components/Android25";
import Android21 from "./components/Android21";
import Android24 from "./components/Android24";
import MobWebsite1 from "./components/MobWebsite1";
import Frame21 from "./components/Frame21";
import PhotoSelects from "./components/PhotoSelects";
import Frame17 from "./components/Frame17";

function App() {
  return (
    <Router>
      <Switch>
        <Route path="/android-17">
          <Android17 {...android17Data} />
        </Route>
        <Route path="/android-23">
          <Android23 {...android23Data} />
        </Route>
        <Route path="/android-25">
          <Android25 {...android25Data} />
        </Route>
        <Route path="/android-21">
          <Android21 {...android21Data} />
        </Route>
        <Route path="/android-24">
          <Android24 {...android24Data} />
        </Route>
        <Route path="/:path(|mob-website-1)">
          <MobWebsite1 {...mobWebsite1Data} />
        </Route>
        <Route path="/frame-21">
          <Frame21 {...frame21Data} />
        </Route>
        <Route path="/photo-selects">
          <PhotoSelects />
        </Route>
        <Route path="/frame-17">
          <Frame17 />
        </Route>
        <Route path="/frame-18">
          <Frame17 />
        </Route>
      </Switch>
    </Router>
  );
}

export default App;
const searchIconData = {
    children: "→ JOIN A PROGRAMME",
};

const textsearchfield8Data = {
    searchIconProps: searchIconData,
};

const searchIcon2Data = {
    spanText: <>TITLE OF PROGRAMME<br />October 2021<br /><br /></>,
};

const searchIcon22Data = {
    spanText: <>TITLE OF PROGRAMME<br />November 2021<br /><br /></>,
};

const textsearchfield7Data = {
    searchIcon2Props: searchIcon22Data,
};

const searchIcon23Data = {
    spanText: <>TITLE OF PROGRAMME<br />December 2021<br /><br /></>,
};

const textsearchfield72Data = {
    searchIcon2Props: searchIcon23Data,
};

const searchIcon24Data = {
    spanText: <>TITLE OF PROGRAMME<br />January 2022<br /><br /></>,
};

const textsearchfield73Data = {
    searchIcon2Props: searchIcon24Data,
};

const searchIcon25Data = {
    spanText: <>TITLE OF PROGRAMME<br />February 2022<br /><br /></>,
};

const textsearchfield74Data = {
    className: "text-search-field-7",
    searchIcon2Props: searchIcon25Data,
};

const searchIcon26Data = {
    spanText: <>TITLE OF PROGRAMME<br />March 2022<br /><br /></>,
};

const textsearchfield75Data = {
    searchIcon2Props: searchIcon26Data,
};

const searchIcon27Data = {
    spanText: <>TITLE OF PROGRAMME<br />April 2022<br /><br /></>,
};

const textsearchfield76Data = {
    searchIcon2Props: searchIcon27Data,
};

const searchIcon28Data = {
    spanText: <>TITLE OF PROGRAMME<br />May 2022<br /><br /></>,
};

const textsearchfield77Data = {
    searchIcon2Props: searchIcon28Data,
};

const searchIcon3Data = {
    children: "→ PARTNER WITH US",
};

const textsearchfield82Data = {
    className: "text-search-field-2",
    searchIconProps: searchIcon3Data,
};

const group6882Data = {
    spanText: <>WHAT IS ENERGY MAKERS ACADEMY?<br /></>,
    textsearchfield8Props: textsearchfield82Data,
};

const searchIcon4Data = {
    children: "→ JOIN A PROGRAMME",
};

const textsearchfield83Data = {
    className: "text-search-field-2",
    searchIconProps: searchIcon4Data,
};

const group68822Data = {
    spanText: <>WHAT ARE THE BENEFITS OF JOINING?<br /></>,
    className: "group-688",
    textsearchfield8Props: textsearchfield83Data,
};

const searchIcon5Data = {
    children: "→ PARTNER WITH US",
};

const textsearchfield84Data = {
    className: "text-search-field-2",
    searchIconProps: searchIcon5Data,
};

const group68823Data = {
    spanText: <>GRAD SPOTLIGHT: FLORENCE LUNGU<br /></>,
    className: "group-688",
    textsearchfield8Props: textsearchfield84Data,
};

const searchIcon6Data = {
    children: "→ JOIN A PROGRAMME",
};

const textsearchfield85Data = {
    className: "text-search-field-2",
    searchIconProps: searchIcon6Data,
};

const group68824Data = {
    spanText: <>WHAT ARE THE BENEFITS OF JOINING?<br /></>,
    className: "group-688",
    textsearchfield8Props: textsearchfield85Data,
};

const vectorData = {
    src: "/img/rectangle-258@2x.png",
};

const vector2Data = {
    src: "/img/rectangle-258@2x.png",
};

const vector3Data = {
    src: "/img/rectangle-258@2x.png",
};

const vector4Data = {
    src: "/img/rectangle-258@2x.png",
};

const vector5Data = {
    src: "/img/rectangle-258@2x.png",
};

const android17Data = {
    x124860179_188885906187978_31258602: "/img/124860179-188885906187978-3125860231458806657-n@1x.png",
    rectangle258: "/img/rectangle-258@2x.png",
    weTeachStudentsTh: "We teach students through a “learn by making” approach, providing them with the skills and knowledge to develop universal access to electricity.",
    vector26: "/img/rectangle-258@2x.png",
    ourMobileLearning: "Our mobile learning platform and integrated hardware demystifies energy systems, and offers powerful capabilities for their design. We empower and inspire people and communities to innovate towards affordable, reliable and sustainable energy systems.",
    vector2: "/img/rectangle-258@2x.png",
    vector3: "/img/rectangle-258@2x.png",
    vector4: "/img/rectangle-258@2x.png",
    vector5: "/img/rectangle-258@2x.png",
    vector6: "/img/rectangle-258@2x.png",
    x121170480_176224507454118_11538062: "/img/rectangle-258@2x.png",
    title: "ANSWERS HUB",
    x218432608_347909323618968_26240350: "/img/rectangle-258@2x.png",
    oel_Facebook: "/img/rectangle-258@2x.png",
    x129841425_202769898132912_96775093: "/img/rectangle-258@2x.png",
    vector36: "/img/rectangle-258@2x.png",
    vector35: "/img/rectangle-258@2x.png",
    vector7: "/img/rectangle-258@2x.png",
    vector38: "/img/rectangle-258@2x.png",
    vector37: "/img/rectangle-258@2x.png",
    vector39: "/img/rectangle-258@2x.png",
    vector382: "/img/rectangle-258@2x.png",
    emaFacebook: "EMA Facebook",
    emaYoutube: "EMA YouTube",
    emaTwitter: <>EMA<br />Twitter</>,
    emaInstagram: "EMA Instagram",
    emaLinkedin: "EMA LinkedIn",
    vector392: "/img/rectangle-258@2x.png",
    vector352: "/img/rectangle-258@2x.png",
    vector353: "/img/rectangle-258@2x.png",
    vector393: "/img/rectangle-258@2x.png",
    vector372: "/img/rectangle-258@2x.png",
    vector362: "/img/rectangle-258@2x.png",
    vector354: "/img/rectangle-258@2x.png",
    updatesNews: "UPDATES & NEWS",
    yourEmailAddress: "Your email address*",
    firstName: "First name",
    lastName: "Last name",
    phoneNumber: "Phone number",
    submit: "→ SUBMIT",
    spanText: <>ABOUT US<br /></>,
    spanText2: <>Mission &amp; vision<br />Team<br />Partners<br />Get involved<br />Sponsor us<br /></>,
    spanText3: <><br /></>,
    spanText4: <>NEWS<br /></>,
    spanText5: <>Latest newsNewsletter<br />Gallery</>,
    vector41: "/img/rectangle-258@2x.png",
    vector42: "/img/rectangle-258@2x.png",
    vector8: "/img/rectangle-258@2x.png",
    textsearchfield8Props: textsearchfield8Data,
    searchIcon2Props: searchIcon2Data,
    textsearchfield7Props: textsearchfield7Data,
    textsearchfield72Props: textsearchfield72Data,
    textsearchfield73Props: textsearchfield73Data,
    textsearchfield74Props: textsearchfield74Data,
    textsearchfield75Props: textsearchfield75Data,
    textsearchfield76Props: textsearchfield76Data,
    textsearchfield77Props: textsearchfield77Data,
    group6882Props: group6882Data,
    group68822Props: group68822Data,
    group68823Props: group68823Data,
    group68824Props: group68824Data,
    vectorProps: vectorData,
    vector2Props: vector2Data,
    vector3Props: vector3Data,
    vector4Props: vector4Data,
    vector5Props: vector5Data,
};

const android23Data = {
    vector38: "/img/vector-38-4@2x.png",
    twitterFacebook: <>↗ Twitter<br />↗ Facebook</>,
    linkedinInstagram: <>↗ LinkedIn<br />↗ Instagram</>,
    vector35: "/img/vector-38-4@2x.png",
    vector39: "/img/vector-38-4@2x.png",
    vector36: "/img/vector-38-4@2x.png",
    vector37: "/img/vector-37-4@2x.png",
    newsletterSignUp: "NEWSLETTER SIGN-UP",
};

const textsearchfieldData = {
    children: "↓  MEET THE EMA TEAM",
};

const tEXTSEARCHFIELD42Data = {
    className: "",
};

const group6839Data = {
    vector41: "/img/vector-41@2x.png",
    vector42: "/img/vector-42@2x.png",
    tEXTSEARCHFIELD4Props: tEXTSEARCHFIELD42Data,
};

const textsearchfield5Data = {
    children: <>EMA<br />32/6 Joseph Mwilwa Rd<br />Rhodes Park<br />Lusaka — Zambia<br /><br />View on Google Maps<br /><br />Email us<br />EMA Press kit</>,
};

const textsearchfield52Data = {
    children: <>PROGRAMMES<br />University of Zambia<br />Copperbelt University<br /><br /><br /><br />PROJECTS<br />Liquid Telcom<br />Name 2<br />Name 3</>,
};

const group6840Data = {
    tEXTSEARCHFIELD5Props: textsearchfield5Data,
    tEXTSEARCHFIELD52Props: textsearchfield52Data,
};

const frame62Data = {
    className: "frame-6-1",
};

const android25Data = {
    polygon1: "/img/polygon-1-1@2x.png",
    partnersOfEma: "↓  PARTNERS OF EMA",
    getInvolvedWithEma: "↓  GET INVOLVED WITH EMA",
    spanText: <>Mission and vision<br /></>,
    spanText2: <>Team<br />Partners<br />Get involved<br />Sponsor<br />Share</>,
    spanText3: <>ABOUT US<br /></>,
    spanText4: <>Mission &amp; vision<br />Team<br />Partners<br />Get involved<br />Sponsor us</>,
    spanText5: <>NEWS<br /></>,
    spanText6: <>Latest newsNewsletter<br />Gallery</>,
    group6840: "/img/vector@2x.png",
    vector35: "/img/vector-35@2x.png",
    vector36: "/img/vector-36@2x.png",
    textsearchfieldProps: textsearchfieldData,
    group6839Props: group6839Data,
    group6840Props: group6840Data,
    frame6Props: frame62Data,
};

const textsearchfield9Data = {
    children: "→ JOIN US AT UNZA",
    className: "text-search-field-31",
};

const textsearchfield10Data = {
    children: "→ JOIN US AT CBU",
    className: "text-search-field-32",
};

const group681323Data = {
    className: "group-6911",
};

const tEXTSEARCHFIELD43Data = {
    className: "text-search-field-14",
};

const group68392Data = {
    vector41: "/img/vector-41-2@2x.png",
    vector42: "/img/vector-42-2@2x.png",
    className: "group-6839-4",
    tEXTSEARCHFIELD4Props: tEXTSEARCHFIELD43Data,
};

const textsearchfield23Data = {
    className: "text-search-field-17",
};

const textsearchfield33Data = {
    className: "text-search-field-20",
};

const textsearchfield42Data = {
    className: "text-search-field-34",
};

const textsearchfield53Data = {
    children: <>EMA<br />32/6 Joseph Mwilwa Rd<br />Rhodes Park<br />Lusaka — Zambia<br /><br />View on Google Maps<br /><br />Email us<br />EMA Press kit</>,
    className: "text-search-field-38-1",
};

const textsearchfield54Data = {
    children: <>PROGRAMMES<br />University of Zambia<br />Copperbelt University<br /><br /><br /><br />PROJECTS<br />Liquid Telcom<br />Name 2<br />Name 3</>,
    className: "text-search-field-38",
};

const textsearchfield62Data = {
    className: "text-search-field-41",
};

const tEXTSEARCHFIELD44Data = {
    className: "",
};

const group68393Data = {
    vector41: "/img/vector-41@2x.png",
    vector42: "/img/vector-42@2x.png",
    tEXTSEARCHFIELD4Props: tEXTSEARCHFIELD44Data,
};

const textsearchfield55Data = {
    children: <>EMA<br />32/6 Joseph Mwilwa Rd<br />Rhodes Park<br />Lusaka — Zambia<br /><br />View on Google Maps<br /><br />Email us<br />EMA Press kit</>,
};

const textsearchfield56Data = {
    children: <>PROGRAMMES<br />University of Zambia<br />Copperbelt University<br /><br /><br /><br />PROJECTS<br />Liquid Telcom<br />Name 2<br />Name 3</>,
};

const group68402Data = {
    tEXTSEARCHFIELD5Props: textsearchfield55Data,
    tEXTSEARCHFIELD52Props: textsearchfield56Data,
};

const android21Data = {
    x218432609: "/img/-218432609@2x.png",
    universityOfZambia: <>UNIVERSITY OF ZAMBIA<br />January 2022<br /><br />Join this TEVETA accredited programme delivered by UNZA. Through this programme you will gain skills in practical electronics, embedded software and energy system design. On completion you will be awarded a Skills Award in Solar Charge Controller Technology.</>,
    vector35: "/img/vector-35@2x.png",
    vector36: "/img/vector-36@2x.png",
    vector38: "/img/vector-37@2x.png",
    vector37: "/img/vector-37@2x.png",
    vector39: "/img/vector-37@2x.png",
    copperbeltUniversit: <>COPPERBELT UNIVERSITY<br />March 2022<br /><br />Join this TEVETA accredited programme delivered by one of the best training institutions in the Zambia. Through this programme you will gain skills in practical electronics, embedded software and energy system design. Once you have completed the programme you will be awarded a Skills Award in Solar Charge Controller Technology.</>,
    cbu1: "/img/cbu-1@2x.png",
    spanText: <>ABOUT US<br /></>,
    spanText2: <>Mission &amp; vision<br />Team<br />Partners<br />Get involved<br />Sponsor us</>,
    spanText3: <>NEWS<br /></>,
    spanText4: <>Latest newsNewsletter<br />Gallery</>,
    vector41: "/img/vector-41-3@2x.png",
    vector42: "/img/vector-42-3@2x.png",
    group6840: "/img/vector@2x.png",
    spanText5: <>ABOUT US<br /></>,
    spanText6: <>Mission &amp; vision<br />Team<br />Partners<br />Get involved<br />Sponsor us</>,
    spanText7: <>NEWS<br /></>,
    spanText8: <>Latest newsNewsletter<br />Gallery</>,
    group6842: "/img/vector@2x.png",
    textsearchfieldProps: textsearchfield9Data,
    textsearchfield2Props: textsearchfield10Data,
    group68132Props: group681323Data,
    group6839Props: group68392Data,
    textsearchfield2Props2: textsearchfield23Data,
    textsearchfield3Props: textsearchfield33Data,
    textsearchfield4Props: textsearchfield42Data,
    textsearchfield5Props: textsearchfield53Data,
    textsearchfield52Props: textsearchfield54Data,
    textsearchfield6Props: textsearchfield62Data,
    group68392Props: group68393Data,
    group6840Props: group68402Data,
};

const android24Data = {
    vector38: "/img/vector-38-4@2x.png",
    twitterFacebook: <>↗ Twitter<br />↗ Facebook</>,
    linkedinInstagram: <>↗ LinkedIn<br />↗ Instagram</>,
    vector35: "/img/vector-38-4@2x.png",
    vector39: "/img/vector-38-4@2x.png",
    vector36: "/img/vector-38-4@2x.png",
    vector37: "/img/vector-37-4@2x.png",
    newsletterSignUp: "NEWSLETTER SIGN-UP",
};

const group6851Data = {
    energyMakersAcadem: <>Energy Makers Academy is a learning programme which teaches you how to build a charge controller.<br /><br />Learn by making your own electricity supply, able to light your room and charge your phone.</>,
};

const group68512Data = {
    energyMakersAcadem: "The Energy Makers Academy app teaches you all you need to know to start building solar charge controllers. Learn about electronics, programming and energy system design using interactive illustrations, experiments and practical exercises.",
};

const group68513Data = {
    energyMakersAcadem: "The Energy Makers Acaedmy hardware gives you hands-on experience of a solar charge controller. As you move through the programme you will design, test and build circuits on a dedicated printed circuit board (PCB), finishing with a fully fuctioning solar home system.",
};

const searchIcon29Data = {
    spanText: <>UNIVAERSITY OF ZAMBIA<br />October 2021<br /><br /></>,
};

const textsearchfield78Data = {
    className: "text-search-field-8",
    searchIcon2Props: searchIcon29Data,
};

const searchIcon210Data = {
    spanText: <>COPPERBELT UNIVERSITY<br />November 2021<br /><br /></>,
};

const searchIcon211Data = {
    spanText: <>SOLWEZI TRADES<br />December 2021<br /><br /></>,
};

const textsearchfield79Data = {
    searchIcon2Props: searchIcon211Data,
};

const searchIcon212Data = {
    spanText: <>LBTC<br />January 2022<br /><br /></>,
};

const textsearchfield710Data = {
    searchIcon2Props: searchIcon212Data,
};

const searchIcon213Data = {
    spanText: <>LIBES<br />February 2022<br /><br /></>,
};

const textsearchfield711Data = {
    className: "text-search-field-9",
    searchIcon2Props: searchIcon213Data,
};

const searchIcon214Data = {
    spanText: <>NORTEC<br />March 2022<br /><br /></>,
};

const textsearchfield712Data = {
    searchIcon2Props: searchIcon214Data,
};

const searchIcon215Data = {
    spanText: <>LUANSHYA TRADES<br />April 2022<br /><br /></>,
};

const textsearchfield713Data = {
    searchIcon2Props: searchIcon215Data,
};

const searchIcon216Data = {
    spanText: <>CHIZONGWE TECH<br />May 2022<br /><br /></>,
};

const textsearchfield714Data = {
    searchIcon2Props: searchIcon216Data,
};

const searchIcon7Data = {
    children: "→ JOIN A PROGRAMME",
};

const searchIcon8Data = {
    children: "→ PARTNER WITH US",
};

const textsearchfield86Data = {
    className: "text-search-field-4",
    searchIconProps: searchIcon8Data,
};

const group6853Data = {
    spanText4: <><br />We work with organsations to help them maximise their impact  and  increase access to both educatioon, and energy.</>,
};

const group68532Data = {
    spanText4: <><br />“I would recommend each and everyone to attend the workshop to try it out. Your lives won&#x27;t be the same again.” - Wilson Banda</>,
    className: "group-6853-5",
};

const searchIcon9Data = {
    children: "→ JOIN A PROGRAMME",
};

const searchIcon10Data = {
    children: "→ LEARN MORE",
};

const vector8Data = {
    src: "/img/vector-14@2x.png",
};

const vector22Data = {
    src: "/img/vector-15@2x.png",
    className: "vector-16",
};

const vector32Data = {
    src: "/img/vector-16@2x.png",
};

const vector42Data = {
    src: "/img/vector-17@2x.png",
    className: "vector-21",
};

const vector52Data = {
    src: "/img/vector-18@2x.png",
    className: "vector-24",
};

const textsearchfield57Data = {
    children: <>EMA<br />32/6 Joseph Mwilwa Rd<br />Rhodes Park<br />Lusaka — Zambia<br /><br />View on Google Maps<br /><br />Email us<br />EMA Press kit</>,
};

const textsearchfield58Data = {
    children: <>PROGRAMMES<br />University of Zambia<br />Copperbelt University<br /><br /><br /><br />PROJECTS<br />Liquid Telcom<br />Name 2<br />Name 3</>,
};

const group68403Data = {
    tEXTSEARCHFIELD5Props: textsearchfield57Data,
    tEXTSEARCHFIELD52Props: textsearchfield58Data,
};

const group68252Data = {
    className: "group-6830",
};

const mobWebsite1Data = {
    text: "",
    text1: "→",
    text2: "←",
    text5: "→",
    text6: "←",
    text3: "→",
    text4: "←",
    vector26: "/img/vector-26@2x.png",
    vector2: "/img/vector-8@2x.png",
    vector3: "/img/vector-10@2x.png",
    vector4: "/img/vector-11@2x.png",
    vector5: "/img/vector-12@2x.png",
    vector6: "/img/vector-9@2x.png",
    x121170480_176224507454118_115380622: "/img/121170480-176224507454118-1153806274680853683-n-1@2x.png",
    answersHub: "ANSWERS HUB",
    x131662611_3760936164026451_87872492: "/img/131662611-3760936164026451-8787249473412765197-n-1@2x.png",
    spanText: <>WHAT IS ENERGY MAKERS ACADEMY?<br /></>,
    spanText2: "",
    spanText3: <><br /></>,
    spanText4: <><br />Energy Makers Academy is an app and hardware kit which teaches you how to build and maintain a solar charge controller.</>,
    x131662611_3760936164026451_87872493: "/img/131662611-3760936164026451-8787249473412765197-n-1@2x.png",
    whyPartnerWithUs: "WHY PARTNER WITH US?",
    x218432608_347909323618968_26240350: "/img/218432608-347909323618968-2624035040922722286-n@1x.png",
    x131662611_3760936164026451_87872494: "/img/131662611-3760936164026451-8787249473412765197-n-1@2x.png",
    whatHavePreviousStudentsSaid: "WHAT HAVE PREVIOUS STUDENTS SAID?",
    oel_Facebook: "/img/oel-facebook@2x.png",
    x131662611_3760936164026451_87872495: "/img/131662611-3760936164026451-8787249473412765197-n-1@2x.png",
    spanText5: <>WHAT ARE THE BENEFITS OF JOINING?<br /></>,
    spanText6: "",
    spanText7: <><br /></>,
    spanText8: <><br />Through hands-on learning, you will gain skills in designing circuits, writing embedded software,  and designing a Solar Home System.</>,
    x129841425_202769898132912_96775093: "/img/129841425-202769898132912-967750932130838834-n@2x.png",
    vector38: "/img/vector-38-6@2x.png",
    emaFacebook: "EMA Facebook",
    emaYoutube: "EMA YouTube",
    emaTwitter: <>EMA<br />Twitter</>,
    emaInstagram: "EMA Instagram",
    emaLinkedin: "EMA LinkedIn",
    vector39: "/img/vector-35-7@2x.png",
    vector35: "/img/vector-35-7@2x.png",
    vector352: "/img/vector-35-7@2x.png",
    vector392: "/img/vector-35-7@2x.png",
    vector37: "/img/vector-38-6@2x.png",
    vector36: "/img/vector-36-6@2x.png",
    vector353: "/img/vector-35-6@2x.png",
    group6840: "/img/vector@2x.png",
    yourEmailAddress: "Your email address*",
    firstName: "First name",
    lastName: "Last name",
    phoneNumber: "Phone number",
    submit: "→ SUBMIT",
    firstName2: "First name",
    updatesNews: "UPDATES & NEWS",
    group6851Props: group6851Data,
    group68512Props: group68512Data,
    group68513Props: group68513Data,
    textsearchfield7Props: textsearchfield78Data,
    searchIcon2Props: searchIcon210Data,
    textsearchfield72Props: textsearchfield79Data,
    textsearchfield73Props: textsearchfield710Data,
    textsearchfield74Props: textsearchfield711Data,
    textsearchfield75Props: textsearchfield712Data,
    textsearchfield76Props: textsearchfield713Data,
    textsearchfield77Props: textsearchfield714Data,
    searchIconProps: searchIcon7Data,
    textsearchfield8Props: textsearchfield86Data,
    group6853Props: group6853Data,
    group68532Props: group68532Data,
    searchIcon2Props2: searchIcon9Data,
    searchIcon3Props: searchIcon10Data,
    vector8Props: vector8Data,
    vector2Props: vector22Data,
    vector32Props: vector32Data,
    vector4Props: vector42Data,
    vector5Props: vector52Data,
    group6840Props: group68403Data,
    group6825Props: group68252Data,
};

const frame65Data = {
    className: "frame-7-1",
};

const frame21Data = {
    spanText: <>ABOUT US<br /></>,
    spanText2: <>Mission &amp; vision<br />Team<br />Partners<br />Get involved<br />Sponsor us</>,
    spanText3: <>NEWS<br /></>,
    spanText4: <>Latest newsNewsletter<br />Gallery</>,
    spanText5: <>PROGRAMMES<br /></>,
    spanText6: <>Programme name 1<br />Name 2<br />Name 3<br />Name 4<br /></>,
    spanText7: <><br />PROJECTS<br /></>,
    spanText8: <>Project name 1<br />Name 2<br />Name 3</>,
    spanText9: <>SOCIAL MEDIA<br /></>,
    spanText10: <>↗ Facebook<br />↗ Twitter<br />↗ LinkedIn<br />↗ YouTube<br />↗ Instagram</>,
    spanText11: <>EMA<br /></>,
    spanText12: <>32/6 Joseph Mwilwa Rd<br />Rhodes Park<br />Lusaka — Zambia<br /><br />View on Google Maps<br /><br />Email us<br />EMA Press kit</>,
    spanText13: <>ABOUT US<br />Mission &amp; vision<br />Team<br />Partners<br />Get involved<br />Sponsor us<br /></>,
    spanText14: <><br /></>,
    spanText15: <>NEWS<br />Latest newsNewsletter<br />Gallery</>,
    ema326JosephMwil: <>EMA<br />32/6 Joseph Mwilwa Rd<br />Rhodes Park<br />Lusaka — Zambia<br /><br />View on Google Maps<br /><br />Email us<br />EMA Press kit</>,
    programmesUniversit: <>PROGRAMMES<br />University of Zambia<br />Copperbelt University<br /><br /><br /><br />PROJECTS<br />Liquid Telcom<br />Name 2<br />Name 3</>,
    socialMediaFaceb: <>SOCIAL MEDIA<br />↗ Facebook<br />↗ Twitter<br />↗ LinkedIn<br />↗ YouTube<br />↗ Instagram</>,
    frame6Props: frame65Data,
};

