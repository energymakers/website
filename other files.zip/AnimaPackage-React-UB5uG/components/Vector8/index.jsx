import React from "react";
import "./Vector8.css";

function Vector8(props) {
  const { src } = props;

  return <div className="vector-46" style={{ backgroundImage: `url(${src})` }}></div>;
}

export default Vector8;
