import React from "react";
import "./Vector4.css";

function Vector4(props) {
  const { src, className } = props;

  return (
    <div className={`vector-19 ${className || ""}`}>
      <img className="vector-20" src={src} />
    </div>
  );
}

export default Vector4;
