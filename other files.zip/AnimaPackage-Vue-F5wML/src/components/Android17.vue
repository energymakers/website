<template>
  <div class="container-center-horizontal">
    <div class="android-17 screen">
      <div class="overlap-group11">
        <div class="rectangle-250"></div>
        <img class="x124860179_1888859061" :src="x124860179_188885906187978_31258602" /><img
          class="rectangle-258"
          :src="rectangle258"
        />
        <div class="we-teach-students-th">{{ weTeachStudentsTh }}</div>
        <textsearchfield8 :searchIconProps="textsearchfield8Props.searchIconProps" />
        <div class="group-6879"></div>
        <div class="group-6880"></div>
        <div class="frame-14">
          <div class="text-search-field-container">
            <a href="#vector-26">
              <div class="text-search-field"><search-icon2 :spanText="searchIcon2Props.spanText" /></div></a
            ><textsearchfield7 :searchIcon2Props="textsearchfield7Props.searchIcon2Props" />
            <textsearchfield7 :searchIcon2Props="textsearchfield72Props.searchIcon2Props" />
            <textsearchfield7 :searchIcon2Props="textsearchfield73Props.searchIcon2Props" />
            <textsearchfield7
              :className="textsearchfield74Props.className"
              :searchIcon2Props="textsearchfield74Props.searchIcon2Props"
            />
            <textsearchfield7 :searchIcon2Props="textsearchfield75Props.searchIcon2Props" />
            <textsearchfield7 :searchIcon2Props="textsearchfield76Props.searchIcon2Props" />
            <textsearchfield7 :searchIcon2Props="textsearchfield77Props.searchIcon2Props" />
          </div>
        </div>
        <textsearchfield3 />
        <img class="vector-26" id="vector-26" :src="vector26" />
        <div class="group-6851">
          <p class="our-mobile-learning gellix-regular-normal-white-16px" v-html="ourMobileLearning"></p>
          <div class="group-6864">
            <div class="group-6850"></div>
            <div class="group-685"></div>
            <div class="group-685"></div>
          </div>
        </div>
        <div class="group-6881">
          <div class="flex-row">
            <div class="vector-container">
              <img
                class="vector-1"
                src="https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bef93e6d04a82cf9930d0c/img/rectangle-258@2x.png"
              />
              <div class="vector-2"><img class="vector-4" :src="vector2" /></div>
              <img class="vector-5" :src="vector3" />
            </div>
            <img class="vector-6" :src="vector4" />
            <div class="vector-7"><img class="vector-8" :src="vector5" /></div>
          </div>
          <div class="vector-9"><img class="vector-10" :src="vector6" /></div>
        </div>
        <img class="x121170480_1762245074" :src="x121170480_176224507454118_11538062" />
        <h1 class="title ballpill-normal-white-32px">{{ title }}</h1>
        <group6882 :spanText="group6882Props.spanText" :textsearchfield8Props="group6882Props.textsearchfield8Props" />
        <div class="overlap-group6">
          <group6882
            :spanText="group68822Props.spanText"
            :className="group68822Props.className"
            :textsearchfield8Props="group68822Props.textsearchfield8Props"
          />
          <img class="x218432608_3479093236" :src="x218432608_347909323618968_26240350" />
        </div>
        <div class="overlap-group7">
          <group6882
            :spanText="group68823Props.spanText"
            :className="group68823Props.className"
            :textsearchfield8Props="group68823Props.textsearchfield8Props"
          />
          <img class="oel_facebook" :src="oel_Facebook" />
        </div>
        <div class="overlap-group8">
          <group6882
            :spanText="group68824Props.spanText"
            :className="group68824Props.className"
            :textsearchfield8Props="group68824Props.textsearchfield8Props"
          />
          <img class="x129841425_2027698981" :src="x129841425_202769898132912_96775093" />
        </div>
      </div>
      <div class="nav">
        <div class="group-container">
          <div class="group-6808">
            <img class="vector-36" :src="vector36" />
            <div class="overlap-group-2"><img class="vector" :src="vector35" /></div>
          </div>
          <div class="group-6810">
            <div class="frame"><img class="vector" :src="vector7" /></div>
          </div>
        </div>
      </div>
      <div class="group-6825">
        <img class="vector-38" :src="vector38" /><img class="vector-3" :src="vector37" /><img
          class="vector-3"
          :src="vector39"
        />
      </div>
      <div class="group-6909">
        <div class="overlap-group9">
          <div class="overlap-group">
            <img class="vector-38-1" :src="vector382" />
            <div class="overlap-group">
              <div class="overlap-group-3 gellix-regular-normal-violet-red-12px">
                <div class="ema-container">
                  <div class="ema">{{ emaFacebook }}</div>
                  <div class="ema-you-tube">{{ emaYoutube }}</div>
                </div>
                <div class="ema-container-1 gellix-regular-normal-violet-red-12px">
                  <div class="ema">{{ emaTwitter }}</div>
                  <div class="ema-instagram">{{ emaInstagram }}</div>
                </div>
                <div class="ema-linked-in">{{ emaLinkedin }}</div>
              </div>
              <div class="group-6903">
                <img class="vector-39" :src="vector392" /><img class="vector-35" :src="vector352" />
              </div>
              <img class="vector-35-1" :src="vector353" /><img class="vector-39-1" :src="vector393" /><img
                class="vector-37"
                :src="vector372"
              /><img class="vector-36-1" :src="vector362" />
            </div>
            <img class="vector-35-2" :src="vector354" />
          </div>
          <vector :src="vectorProps.src" />
          <vector2 :src="vector2Props.src" />
          <vector3 :src="vector3Props.src" />
          <vector4 :src="vector4Props.src" />
          <vector5 :src="vector5Props.src" />
        </div>
      </div>
      <div class="group-6895">
        <div class="overlap-group5">
          <div class="updates-news ballpill-normal-white-32px">{{ updatesNews }}</div>
          <div class="group-6890">
            <div class="overlap-group-4">
              <div class="rectangle-257 border-1px-hit-pink"></div>
              <div class="your-email-address gellix-regular-normal-white-12px">{{ yourEmailAddress }}</div>
            </div>
            <div class="overlap-group-1">
              <div class="rectangle-257 border-1px-hit-pink"></div>
              <div class="first-name gellix-regular-normal-white-12px">{{ firstName }}</div>
            </div>
            <div class="overlap-group-1">
              <div class="rectangle-257 border-1px-hit-pink"></div>
              <div class="last-name gellix-regular-normal-white-12px">{{ lastName }}</div>
            </div>
            <div class="overlap-group1">
              <div class="rectangle-257 border-1px-hit-pink"></div>
              <div class="phone-number gellix-regular-normal-white-12px">{{ phoneNumber }}</div>
            </div>
            <div class="overlap-group2">
              <div class="submit gellix-regular-normal-white-12px">{{ submit }}</div>
            </div>
          </div>
        </div>
      </div>
      <div class="group-6896">
        <div class="footer">
          <div class="overlap-group3">
            <div class="group-6838">
              <div class="overlap-group1-1">
                <div class="text-search-field-1">
                  <div class="search-icon">
                    <p class="about-us-mission-v gellix-regular-normal-white-12px-2">
                      <span class="span gellix-regular-normal-white-12px">{{ spanText }}</span
                      ><span class="span gellix-regular-normal-dull-lavender-12px">{{ spanText2 }}</span
                      ><span class="span gellix-regular-normal-tasman-12px">{{ spanText3 }}</span
                      ><span class="span gellix-regular-normal-white-12px">{{ spanText4 }}</span
                      ><span class="span gellix-regular-normal-dull-lavender-12px">{{ spanText5 }}</span>
                    </p>
                  </div>
                </div>
                <div class="group-6839">
                  <div class="group-6839-1">
                    <div class="overlap-group-5">
                      <textsearchfield4 /> <img class="vector-41" :src="vector41" /><img
                        class="vector-42"
                        :src="vector42"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div class="text-search-field-container-1">
                <textsearchfield2 />
                <textsearchfield32 />
              </div>
            </div>
            <img class="vector-11" :src="vector8" /><frame6 />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Textsearchfield8 from "./Textsearchfield8";
import SearchIcon2 from "./SearchIcon2";
import Textsearchfield7 from "./Textsearchfield7";
import Textsearchfield3 from "./Textsearchfield3";
import Group6882 from "./Group6882";
import Vector from "./Vector";
import Vector2 from "./Vector2";
import Vector3 from "./Vector3";
import Vector4 from "./Vector4";
import Vector5 from "./Vector5";
import Textsearchfield4 from "./Textsearchfield4";
import Textsearchfield2 from "./Textsearchfield2";
import Textsearchfield32 from "./Textsearchfield32";
import Frame6 from "./Frame6";
export default {
  name: "Android17",
  components: {
    Textsearchfield8,
    SearchIcon2,
    Textsearchfield7,
    Textsearchfield3,
    Group6882,
    Vector,
    Vector2,
    Vector3,
    Vector4,
    Vector5,
    Textsearchfield4,
    Textsearchfield2,
    Textsearchfield32,
    Frame6,
  },
  props: [
    "x124860179_188885906187978_31258602",
    "rectangle258",
    "weTeachStudentsTh",
    "vector26",
    "ourMobileLearning",
    "vector2",
    "vector3",
    "vector4",
    "vector5",
    "vector6",
    "x121170480_176224507454118_11538062",
    "title",
    "x218432608_347909323618968_26240350",
    "oel_Facebook",
    "x129841425_202769898132912_96775093",
    "vector36",
    "vector35",
    "vector7",
    "vector38",
    "vector37",
    "vector39",
    "vector382",
    "emaFacebook",
    "emaYoutube",
    "emaTwitter",
    "emaInstagram",
    "emaLinkedin",
    "vector392",
    "vector352",
    "vector353",
    "vector393",
    "vector372",
    "vector362",
    "vector354",
    "updatesNews",
    "yourEmailAddress",
    "firstName",
    "lastName",
    "phoneNumber",
    "submit",
    "spanText",
    "spanText2",
    "spanText3",
    "spanText4",
    "spanText5",
    "vector41",
    "vector42",
    "vector8",
    "textsearchfield8Props",
    "searchIcon2Props",
    "textsearchfield7Props",
    "textsearchfield72Props",
    "textsearchfield73Props",
    "textsearchfield74Props",
    "textsearchfield75Props",
    "textsearchfield76Props",
    "textsearchfield77Props",
    "group6882Props",
    "group68822Props",
    "group68823Props",
    "group68824Props",
    "vectorProps",
    "vector2Props",
    "vector3Props",
    "vector4Props",
    "vector5Props",
  ],
};
</script>

<style>
.android-17 {
  align-items: flex-end;
  background-color: var(--ema-pale-violet);
  display: flex;
  flex-direction: column;
  min-height: 640px;
  overflow-x: hidden;
  width: 360px;
}

.overlap-group11 {
  height: 3341px;
  margin-right: -105px;
  position: relative;
  width: 529px;
  z-index: 1;
}

.rectangle-250 {
  background-color: var(--ema-pale-violet);
  height: 3341px;
  left: 64px;
  position: absolute;
  top: 0;
  width: 360px;
}

.x124860179_1888859061 {
  height: 1px;
  left: 243px;
  position: absolute;
  top: 320px;
  width: 1px;
}

.rectangle-258 {
  height: 1px;
  left: 244px;
  position: absolute;
  top: 505px;
  width: 1px;
}

.we-teach-students-th {
  color: var(--ema-white);
  font-family: var(--font-family-gellix-regular);
  font-size: var(--font-size-xxxl);
  font-weight: 400;
  left: 82px;
  letter-spacing: 0.75px;
  line-height: 33px;
  position: absolute;
  top: 266px;
  width: 310px;
}

.group-6879 {
  background-color: var(--blue-violet);
  height: 640px;
  left: 64px;
  position: absolute;
  top: 640px;
  width: 360px;
}

.group-6880 {
  background-color: var(--blue-violet);
  height: 329px;
  left: 64px;
  position: absolute;
  top: 1280px;
  width: 360px;
}

.frame-14::-webkit-scrollbar {
  display: none;
  width: 0;
}

.frame-14 {
  align-items: flex-end;
  display: flex;
  height: 209px;
  justify-content: flex-end;
  left: 64px;
  min-width: 360px;
  overflow-x: scroll;
  position: absolute;
  top: 640px;
}

.text-search-field-container {
  align-items: flex-end;
  background-color: var(--ema-violet);
  display: flex;
  height: 250px;
  margin-bottom: -62px;
  min-width: 1521px;
  padding: 0 16px;
  position: relative;
}

.text-search-field {
  cursor: pointer;
  display: flex;
  height: 103px;
  justify-content: center;
  margin-bottom: -0.24px;
  position: relative;
  width: 160px;
}

.vector-26 {
  height: 1px;
  left: 244px;
  position: absolute;
  top: 786px;
  width: 1px;
}

.group-6851 {
  display: flex;
  flex-direction: column;
  height: 186px;
  left: 89px;
  position: absolute;
  top: 1386px;
  width: 312px;
}

.our-mobile-learning {
  height: 170px;
  letter-spacing: 0.48px;
  line-height: 22px;
  text-align: center;
  width: 310px;
}

.group-6864 {
  display: flex;
  margin-left: 140px;
  margin-top: 10px;
  width: 30px;
}

.group-6850 {
  background-color: var(--ema-white);
  border-radius: 3px;
  height: 6px;
  width: 6px;
}

.group-685 {
  background-color: var(--dull-lavender);
  border-radius: 3px;
  height: 6px;
  margin-left: 6px;
  margin-top: 0;
  width: 6px;
}

.group-6881 {
  align-items: flex-end;
  display: flex;
  flex-direction: column;
  left: 0;
  min-height: 330px;
  padding: 29.1px 15.5px;
  position: absolute;
  top: 1001px;
  width: 529px;
}

.flex-row {
  align-items: flex-end;
  display: flex;
  height: 216px;
  margin-top: 8px;
  min-width: 455px;
}

.vector-container {
  align-self: flex-start;
  height: 176px;
  position: relative;
  width: 207px;
}

.vector-1 {
  height: 1px;
  left: 160px;
  position: absolute;
  top: 108px;
  width: 1px;
}

.vector-2 {
  align-items: center;
  display: flex;
  height: 207px;
  left: 15px;
  min-width: 176px;
  padding: 0 87.8px;
  position: absolute;
  top: -15px;
  transform: rotate(-90deg);
}

.vector-4 {
  height: 1px;
  transform: rotate(90deg);
  width: 1px;
}

.vector-5 {
  height: 1px;
  left: 22px;
  position: absolute;
  top: 160px;
  width: 1px;
}

.vector-6 {
  height: 1px;
  margin-bottom: 14.69px;
  margin-left: 55px;
  width: 1px;
}

.vector-7 {
  align-items: flex-end;
  display: flex;
  height: 184px;
  justify-content: flex-end;
  margin-left: 40px;
  min-width: 153px;
  padding: 91.1px 75.6px;
  transform: rotate(90deg);
}

.vector-8 {
  height: 1px;
  transform: rotate(-90deg);
  width: 1px;
}

.vector-9 {
  align-items: center;
  align-self: center;
  display: flex;
  height: 29px;
  margin-left: 73px;
  margin-top: 19px;
  min-width: 132px;
  padding: 0 65.8px;
  transform: rotate(-180deg);
}

.vector-10 {
  height: 1px;
  transform: rotate(180deg);
  width: 1px;
}

.x121170480_1762245074 {
  height: 1px;
  left: 244px;
  object-fit: cover;
  position: absolute;
  top: 1165px;
  width: 1px;
}

.title {
  left: 64px;
  letter-spacing: 0.64px;
  position: absolute;
  text-align: center;
  top: 1689px;
  width: 360px;
}

.overlap-group6 {
  height: 331px;
  left: 64px;
  position: absolute;
  top: 2931px;
  width: 360px;
}

.x218432608_3479093236,
.oel_facebook,
.x129841425_2027698981 {
  height: 1px;
  left: 180px;
  object-fit: cover;
  position: absolute;
  top: 72px;
  width: 1px;
}

.overlap-group7 {
  height: 331px;
  left: 64px;
  position: absolute;
  top: 2552px;
  width: 360px;
}

.overlap-group8 {
  height: 331px;
  left: 64px;
  position: absolute;
  top: 2173px;
  width: 360px;
}

.nav {
  align-items: flex-start;
  display: flex;
  height: 64px;
  left: 0;
  min-width: 360px;
  position: fixed;
  top: 0;
  z-index: 5;
}

.group-container {
  height: 64px;
  position: relative;
  width: 360px;
}

.group-6808 {
  align-items: flex-start;
  display: flex;
  height: 64px;
  justify-content: flex-end;
  left: 0;
  min-width: 360px;
  padding: 0 0px;
  position: absolute;
  top: 0;
}

.vector-36 {
  align-self: flex-end;
  height: 1px;
  margin-bottom: -0.25px;
  width: 1px;
}

.overlap-group-2 {
  align-items: flex-start;
  background-color: var(--dull-lavender-2);
  display: flex;
  height: 64px;
  margin-left: 116px;
  min-width: 64px;
  padding: 31.7px 0;
}

.vector {
  height: 1px;
  width: 1px;
}

.group-6810 {
  display: flex;
  height: 30px;
  left: 18px;
  position: absolute;
  top: 19px;
  width: 82px;
}

.frame {
  align-items: flex-end;
  display: flex;
  height: 29.94px;
  padding: 14.7px 40.7px;
  width: 81.83px;
}

.group-6825 {
  align-items: flex-end;
  display: flex;
  flex-direction: column;
  height: 16px;
  left: 311px;
  position: fixed;
  top: 24px;
  width: 35px;
  z-index: 6;
}

.vector-38 {
  height: 0.5px;
  margin-right: 17.3px;
  margin-top: -0.2px;
  width: 0.5px;
}

.vector-3 {
  height: 0.5px;
  margin-right: 17.3px;
  margin-top: 7.5px;
  width: 0.5px;
}

.group-6909 {
  align-items: flex-start;
  display: flex;
  justify-content: flex-end;
  min-width: 360px;
  z-index: 4;
}

.overlap-group9 {
  height: 256px;
  position: relative;
  width: 360px;
}

.overlap-group {
  height: 256px;
  left: 0;
  position: absolute;
  top: 0;
  width: 360px;
}

.vector-38-1 {
  height: 1px;
  left: 0;
  position: absolute;
  top: 32px;
  width: 1px;
}

.overlap-group-3 {
  align-items: flex-end;
  background-color: var(--princess-perfume);
  display: flex;
  height: 256px;
  justify-content: flex-end;
  left: 0;
  min-width: 360px;
  padding: 11px 25px;
  position: absolute;
  top: 0;
}

.ema-container {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  min-height: 170px;
  width: 65px;
}

.ema {
  letter-spacing: 0.6px;
  line-height: 15.5px;
  min-height: 43px;
  text-align: center;
  width: 65px;
}

.ema-you-tube {
  letter-spacing: 0.6px;
  line-height: 15.5px;
  margin-top: 84px;
  min-height: 43px;
  text-align: center;
  width: 65px;
}

.ema-container-1 {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  margin-left: 55px;
  min-height: 169px;
  width: 65px;
}

.ema-instagram {
  letter-spacing: 0.6px;
  line-height: 15.5px;
  margin-top: 83px;
  min-height: 43px;
  text-align: center;
  width: 65px;
}

.ema-linked-in {
  align-self: center;
  letter-spacing: 0.6px;
  line-height: 15.5px;
  margin-bottom: 62.97px;
  margin-left: 55px;
  min-height: 43px;
  text-align: center;
  width: 66px;
}

.group-6903 {
  display: flex;
  height: 128px;
  justify-content: flex-end;
  left: 120px;
  position: absolute;
  top: 0;
  width: 120px;
}

.vector-39 {
  height: 0.5px;
  margin-right: 119.5px;
  margin-top: 63.8px;
  width: 0.5px;
}

.vector-35 {
  height: 0.5px;
  margin-right: -0.3px;
  margin-top: 63.8px;
  width: 0.5px;
}

.vector-35-1 {
  height: 1px;
  left: 240px;
  position: absolute;
  top: 192px;
  width: 1px;
}

.vector-39-1 {
  height: 1px;
  left: 120px;
  position: absolute;
  top: 192px;
  width: 1px;
}

.vector-37 {
  height: 1px;
  left: 360px;
  position: absolute;
  top: 32px;
  width: 1px;
}

.vector-36-1 {
  height: 1px;
  left: 180px;
  position: absolute;
  top: 128px;
  width: 1px;
}

.vector-35-2 {
  height: 1px;
  left: 300px;
  position: absolute;
  top: 192px;
  width: 1px;
}

.group-6895 {
  align-items: flex-start;
  display: flex;
  height: 640px;
  margin-right: -2px;
  min-width: 362px;
  z-index: 2;
}

.overlap-group5 {
  align-items: flex-end;
  background-color: var(--burnt-orange);
  display: flex;
  flex-direction: column;
  min-height: 640px;
  padding: 81px 2px;
  width: 360px;
}

.updates-news {
  align-self: center;
  letter-spacing: 0.64px;
  margin-left: 5px;
  min-height: 105px;
  text-align: center;
  width: 275px;
}

.group-6890 {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  margin-top: 33px;
  min-height: 312px;
  width: 344px;
}

.overlap-group-4 {
  height: 54px;
  position: relative;
  width: 334px;
}

.rectangle-257 {
  background-color: var(--burnt-orange);
  height: 54px;
  left: 29px;
  position: absolute;
  top: 0;
  width: 274px;
}

.your-email-address,
.first-name,
.last-name {
  left: 0;
  letter-spacing: 0.36px;
  line-height: 21.5px;
  position: absolute;
  text-align: center;
  top: 15px;
  white-space: nowrap;
  width: 334px;
}

.overlap-group-1 {
  height: 54px;
  margin-top: 6px;
  position: relative;
  width: 334px;
}

.overlap-group1 {
  height: 54px;
  margin-top: 6px;
  position: relative;
  width: 333px;
}

.phone-number {
  left: 0;
  letter-spacing: 0.36px;
  line-height: 21.5px;
  position: absolute;
  text-align: center;
  top: 15px;
  white-space: nowrap;
  width: 333px;
}

.overlap-group2 {
  align-items: flex-end;
  align-self: center;
  background-color: var(--hit-pink);
  border-radius: 8px;
  display: flex;
  height: 47px;
  justify-content: flex-end;
  margin-right: 12px;
  margin-top: 31px;
  min-width: 200px;
  padding: 11px 28px;
}

.submit {
  letter-spacing: 0.6px;
  line-height: 21.5px;
  min-height: 24px;
  text-align: center;
  white-space: nowrap;
  width: 143px;
}

.group-6896 {
  align-items: flex-end;
  display: flex;
  width: 360px;
  z-index: 3;
}

.footer {
  align-items: flex-end;
  display: flex;
  height: 399px;
  min-width: 360px;
}

.overlap-group3 {
  height: 640px;
  margin-bottom: -241px;
  position: relative;
  width: 360px;
}

.group-6838 {
  align-items: flex-end;
  background-color: var(--ema-violet);
  display: flex;
  height: 627px;
  left: 0;
  min-width: 360px;
  padding: 63.9px 16px;
  position: absolute;
  top: 0;
}

.overlap-group1-1 {
  height: 449px;
  position: relative;
  width: 154px;
}

.text-search-field-1 {
  align-items: center;
  display: flex;
  height: 279px;
  left: 2px;
  position: absolute;
  top: 170px;
  width: 152px;
}

.search-icon {
  align-items: center;
  display: flex;
  width: 154px;
}

.about-us-mission-v {
  height: 279.12px;
  letter-spacing: 0.6px;
  line-height: 15.5px;
  width: 152px;
}

.span {
  letter-spacing: 0.07px;
}

.group-6839 {
  display: flex;
  height: 285px;
  left: 0;
  position: absolute;
  top: 0;
  width: 152px;
}

.group-6839-1 {
  align-items: flex-start;
  display: flex;
  min-width: 152px;
}

.overlap-group-5 {
  height: 285px;
  position: relative;
  width: 152px;
}

.vector-41 {
  height: 1px;
  left: 64px;
  position: absolute;
  top: 95px;
  width: 1px;
}

.vector-42 {
  height: 1px;
  left: 39px;
  position: absolute;
  top: 143px;
  width: 1px;
}

.text-search-field-container-1 {
  height: 449px;
  margin-left: 14px;
  position: relative;
  width: 152px;
}

.vector-11 {
  height: 1px;
  left: 59px;
  position: absolute;
  top: 34px;
  width: 1px;
}
</style>
