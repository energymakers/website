<template>
  <div class="container-center-horizontal">
    <div class="photo-selects screen"></div>
  </div>
</template>

<script>
export default {
  name: "PhotoSelects",
};
</script>

<style>
.photo-selects {
  background-color: var(--ema-white);
  height: 11604px;
  width: 13856px;
}
</style>
