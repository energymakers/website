<template>
  <div class="vector-47" :style="{ 'background-image': 'url(' + src + ')' }"></div>
</template>

<script>
export default {
  name: "Vector32",
  props: ["src"],
};
</script>

<style>
.vector-47 {
  background-size: 100% 100%;
  height: 22px;
  left: 274px;
  position: absolute;
  top: 39px;
  width: 57px;
}
</style>
