<template>
  <div class="container-center-horizontal">
    <div class="mob-website-1 screen">
      <div class="overlap-group12-1">
        <img
          class="rectangle-250-2"
          src="https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c25c8d26aedea5b1848018/img/rectangle-250@1x.svg"
        />
        <img
          class="overlap-group12-item"
          src="https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c25c8d26aedea5b1848018/img/121170480-176224507454118-1153806274680853683-n@1x.svg"
        />
        <img
          class="overlap-group12-item"
          src="https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c25c8d26aedea5b1848018/img/131662611-3760936164026451-8787249473412765197-n@1x.svg"
        />
        <img
          class="rectangle-258-1"
          src="https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61b8c319d1d7cd48b84e3938/img/rectangle-258@2x.svg"
        />
        <img
          class="learn-how-to-build-a-solar-energy-system"
          src="https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c25c8d26aedea5b1848018/img/learn-how-to-build-a-solar-energy-system-@2x.svg"
        />
        <router-link to="/android-21"
          ><img
            class="text-search-field-49"
            src="https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c25c8d26aedea5b1848018/img/text-search-field@2x.svg"
          />
        </router-link>
        <div class="group-6879-1"></div>
        <div class="frame-15">
          <div class="text-2">{{ text }}</div>
          <div class="overlap-group-container">
            <div class="overlap-group3-1">
              <group6851 :energyMakersAcadem="group6851Props.energyMakersAcadem" />
              <a href="#group-6908">
                <div class="text valign-text-middle ballpill-normal-white-22px">{{ text1 }}</div>
              </a>
              <div class="text-1 valign-text-middle ballpill-normal-ebony-clay-22px">{{ text2 }}</div>
            </div>
            <div class="overlap-group-19">
              <group6851 :energyMakersAcadem="group68512Props.energyMakersAcadem" />
              <a href="#group-6909">
                <div class="text valign-text-middle ballpill-normal-white-22px">{{ text5 }}</div>
              </a>
              <div class="text-1 valign-text-middle ballpill-normal-ebony-clay-22px">{{ text6 }}</div>
            </div>
            <div class="overlap-group-19">
              <group6851 :energyMakersAcadem="group68513Props.energyMakersAcadem" />
              <div class="text-3 valign-text-middle ballpill-normal-ebony-clay-22px">{{ text3 }}</div>
              <a href="#group-6851">
                <div class="text-4 valign-text-middle ballpill-normal-white-22px">{{ text4 }}</div>
              </a>
            </div>
          </div>
        </div>
        <div class="frame-14-1">
          <div class="text-search-field-container-9">
            <textsearchfield7
              :className="textsearchfield7Props.className"
              :searchIcon2Props="textsearchfield7Props.searchIcon2Props"
            />
            <router-link to="/android-21">
              <div class="text-search-field-50">
                <search-icon2 :spanText="searchIcon2Props.spanText" /></div></router-link
            ><textsearchfield7 :searchIcon2Props="textsearchfield72Props.searchIcon2Props" />
            <textsearchfield7 :searchIcon2Props="textsearchfield73Props.searchIcon2Props" />
            <textsearchfield7
              :className="textsearchfield74Props.className"
              :searchIcon2Props="textsearchfield74Props.searchIcon2Props"
            />
            <textsearchfield7 :searchIcon2Props="textsearchfield75Props.searchIcon2Props" />
            <textsearchfield7 :searchIcon2Props="textsearchfield76Props.searchIcon2Props" />
            <textsearchfield7 :searchIcon2Props="textsearchfield77Props.searchIcon2Props" />
          </div>
        </div>
        <textsearchfield3 />
        <img class="vector-26-1" id="vector-26" :src="vector26" />
        <div class="vector-container-1">
          <img
            class="vector-30"
            src="https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c390fadbfb8eee2ef63e4f/img/vector-7@2x.png"
          />
          <img class="vector-31" :src="vector2" />
          <div class="vector-32"><img class="vector-33" :src="vector3" /></div>
          <div class="vector-34"><img class="vector-40" :src="vector4" /></div>
          <div class="vector-43"><img class="vector-44" :src="vector5" /></div>
          <img class="vector-45" :src="vector6" />
        </div>
        <img class="x121170480_1762245074-1" :src="x121170480_176224507454118_115380622" />
        <div class="answers-hub ballpill-normal-white-32px">{{ answersHub }}</div>
        <div class="group-6882-1">
          <div class="group-6858-2">
            <img class="x131662611_3760936164-2" :src="x131662611_3760936164026451_87872492" />
            <div class="group-6853-2">
              <div class="group-6814-1">
                <div class="energy-makers-academ-container">
                  <p class="what gellix-regular-normal-white-12px-2">
                    <span class="span-18 gellix-regular-normal-white-12px">{{ spanText }}</span
                    ><span class="span-18 gellix-regular-normal-minsk-12px">{{ spanText2 }}</span>
                  </p>
                  <p class="energy-makers-academ">
                    <span class="span0-1">{{ spanText3 }}</span
                    ><span class="span1-1">{{ spanText4 }}</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
          <a href="#vector-26">
            <div class="text-search-field-48"><search-icon :joinAProgramme="searchIconProps.joinAProgramme" /></div
          ></a>
        </div>
        <div class="overlap-group7-2">
          <div class="group-container-6">
            <div class="group-688-1">
              <div class="group-6858-1">
                <img class="x131662611_3760936164-1" :src="x131662611_3760936164026451_87872493" />
                <div class="group-6853-1">
                  <div class="group-6814-2">
                    <div class="why-partner-with-us gellix-regular-normal-white-12px" v-html="whyPartnerWithUs"></div>
                  </div>
                </div>
              </div>
              <textsearchfield8
                :className="textsearchfield8Props.className"
                :searchIconProps="textsearchfield8Props.searchIconProps"
              />
            </div>
            <group6853 :spanText4="group6853Props.spanText4" />
          </div>
          <img class="x218432608_3479093236-1" :src="x218432608_347909323618968_26240350" />
        </div>
        <div class="overlap-group8-1">
          <div class="group-688-1">
            <div class="group-6858-1">
              <img class="x131662611_3760936164-1" :src="x131662611_3760936164026451_87872494" />
              <div class="group-6853-1">
                <div class="group-6814-3">
                  <div class="overlap-group1-8">
                    <p class="what-have-previous-students-said gellix-regular-normal-white-12px">
                      {{ whatHavePreviousStudentsSaid }}
                    </p>
                    <group6853 :spanText4="group68532Props.spanText4" :className="group68532Props.className" />
                  </div>
                </div>
              </div>
            </div>
            <a href="#vector-26">
              <div class="text-search-field-51"><search-icon :joinAProgramme="searchIcon2Props2.joinAProgramme" /></div
            ></a>
          </div>
          <img class="oel_facebook-1" :src="oel_Facebook" />
        </div>
        <div class="overlap-group9-2">
          <div class="group-6889">
            <div class="group-6858-3">
              <img class="x131662611_3760936164-3" :src="x131662611_3760936164026451_87872495" />
              <div class="group-6853-3">
                <div class="group-6814-4">
                  <div class="overlap-group-22 gellix-regular-normal-white-12px-2">
                    <p class="what">
                      <span class="span-18 gellix-regular-normal-white-12px">{{ spanText5 }}</span
                      ><span class="span-18 gellix-regular-normal-minsk-12px">{{ spanText6 }}</span>
                    </p>
                    <p class="through-hands-on-lea">
                      <span class="span-18 gellix-regular-normal-white-12px">{{ spanText7 }}</span
                      ><span class="span-18 gellix-regular-normal-minsk-12px">{{ spanText8 }}</span>
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <a href="#vector-26">
              <div class="text-search-field-48"><search-icon :joinAProgramme="searchIcon3Props.joinAProgramme" /></div
            ></a>
          </div>
          <img class="x129841425_2027698981-1" :src="x129841425_202769898132912_96775093" />
        </div>
      </div>
      <div class="flex-row-1">
        <div class="overlap-group-container-1">
          <div class="overlap-group-20">
            <div class="overlap-group-20">
              <img class="vector-38-7" :src="vector38" />
              <div class="overlap-group1-9">
                <div class="overlap-group-23 gellix-regular-normal-violet-red-12px">
                  <div class="ema-container-2">
                    <div class="ema-1">{{ emaFacebook }}</div>
                    <div class="ema-you-tube-1">{{ emaYoutube }}</div>
                  </div>
                  <div class="ema-container-3 gellix-regular-normal-violet-red-12px">
                    <div class="ema-1">{{ emaTwitter }}</div>
                    <div class="ema-instagram-1">{{ emaInstagram }}</div>
                  </div>
                  <div class="ema-linked-in-1">{{ emaLinkedin }}</div>
                </div>
                <div class="group-6903-1">
                  <img class="vector-39-7" :src="vector39" /><img class="vector-35-9" :src="vector35" />
                </div>
                <img class="vector-35-10" :src="vector352" /><img class="vector-39-8" :src="vector392" /><img
                  class="vector-37-6"
                  :src="vector37"
                /><img class="vector-36-8" :src="vector36" />
              </div>
              <img class="vector-35-11" :src="vector353" />
            </div>
            <vector8 :src="vector8Props.src" />
            <vector2 :src="vector2Props.src" :className="vector2Props.className" />
            <vector32 :src="vector32Props.src" />
            <vector4 :src="vector4Props.src" :className="vector4Props.className" />
            <vector5 :src="vector5Props.src" :className="vector5Props.className" />
          </div>
          <div class="group-container-7">
            <div class="group-6896-1">
              <div class="footer-2">
                <div class="overlap-group3-2">
                  <group6840
                    :tEXTSEARCHFIELD5Props="group6840Props.tEXTSEARCHFIELD5Props"
                    :tEXTSEARCHFIELD52Props="group6840Props.tEXTSEARCHFIELD52Props"
                  />
                  <div class="group-6840-5" :style="{ 'background-image': 'url(' + group6840 + ')' }"></div>
                  <frame6 />
                </div>
              </div>
            </div>
            <div class="overlap-group11-2">
              <div class="rectangle-256"></div>
              <div class="group-6890-1 gellix-regular-normal-white-12px">
                <div class="overlap-group3-3">
                  <div class="rectangle-257-1 border-1px-hit-pink"></div>
                  <div class="your-email-address-1">{{ yourEmailAddress }}</div>
                </div>
                <div class="overlap-group-21">
                  <div class="rectangle-257-1 border-1px-hit-pink"></div>
                  <div class="first-name-1">{{ firstName }}</div>
                </div>
                <div class="overlap-group-21">
                  <div class="rectangle-257-1 border-1px-hit-pink"></div>
                  <div class="last-name-1">{{ lastName }}</div>
                </div>
                <div class="overlap-group-24">
                  <div class="rectangle-257-1 border-1px-hit-pink"></div>
                  <div class="phone-number-1">{{ phoneNumber }}</div>
                </div>
                <div class="overlap-group4-2">
                  <div class="submit-1">{{ submit }}</div>
                </div>
                <div class="first-name-2">{{ firstName2 }}</div>
              </div>
              <div class="updates-news-1 ballpill-normal-white-32px">{{ updatesNews }}</div>
            </div>
          </div>
        </div>
      </div>
      <group6825 :className="group6825Props.className" />
      <img
        class="nav-5"
        src="https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c25c8d26aedea5b1848018/img/nav@2x.svg"
      />
      <a href="javascript:ShowOverlay('android-23', 'animate-appear');"
        ><img
          class="group-6825-3"
          src="https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c25c8d26aedea5b1848018/img/group-6825@2x.svg"
        />
      </a>
    </div>
  </div>
</template>

<script>
import Group6851 from "./Group6851";
import Textsearchfield7 from "./Textsearchfield7";
import SearchIcon2 from "./SearchIcon2";
import Textsearchfield3 from "./Textsearchfield3";
import SearchIcon from "./SearchIcon";
import Textsearchfield8 from "./Textsearchfield8";
import Group6853 from "./Group6853";
import Vector8 from "./Vector8";
import Vector2 from "./Vector2";
import Vector32 from "./Vector32";
import Vector4 from "./Vector4";
import Vector5 from "./Vector5";
import Group6840 from "./Group6840";
import Frame6 from "./Frame6";
import Group6825 from "./Group6825";
export default {
  name: "MobWebsite1",
  components: {
    Group6851,
    Textsearchfield7,
    SearchIcon2,
    Textsearchfield3,
    SearchIcon,
    Textsearchfield8,
    Group6853,
    Vector8,
    Vector2,
    Vector32,
    Vector4,
    Vector5,
    Group6840,
    Frame6,
    Group6825,
  },
  props: [
    "text",
    "text1",
    "text2",
    "text5",
    "text6",
    "text3",
    "text4",
    "vector26",
    "vector2",
    "vector3",
    "vector4",
    "vector5",
    "vector6",
    "x121170480_176224507454118_115380622",
    "answersHub",
    "x131662611_3760936164026451_87872492",
    "spanText",
    "spanText2",
    "spanText3",
    "spanText4",
    "x131662611_3760936164026451_87872493",
    "whyPartnerWithUs",
    "x218432608_347909323618968_26240350",
    "x131662611_3760936164026451_87872494",
    "whatHavePreviousStudentsSaid",
    "oel_Facebook",
    "x131662611_3760936164026451_87872495",
    "spanText5",
    "spanText6",
    "spanText7",
    "spanText8",
    "x129841425_202769898132912_96775093",
    "vector38",
    "emaFacebook",
    "emaYoutube",
    "emaTwitter",
    "emaInstagram",
    "emaLinkedin",
    "vector39",
    "vector35",
    "vector352",
    "vector392",
    "vector37",
    "vector36",
    "vector353",
    "group6840",
    "yourEmailAddress",
    "firstName",
    "lastName",
    "phoneNumber",
    "submit",
    "firstName2",
    "updatesNews",
    "group6851Props",
    "group68512Props",
    "group68513Props",
    "textsearchfield7Props",
    "searchIcon2Props",
    "textsearchfield72Props",
    "textsearchfield73Props",
    "textsearchfield74Props",
    "textsearchfield75Props",
    "textsearchfield76Props",
    "textsearchfield77Props",
    "searchIconProps",
    "textsearchfield8Props",
    "group6853Props",
    "group68532Props",
    "searchIcon2Props2",
    "searchIcon3Props",
    "vector8Props",
    "vector2Props",
    "vector32Props",
    "vector4Props",
    "vector5Props",
    "group6840Props",
    "group6825Props",
  ],
};
</script>

<style>
.mob-website-1 {
  background-color: var(--ema-pale-violet);
  height: 640px;
  overflow-x: hidden;
  position: relative;
  width: 360px;
}

.overlap-group12-1 {
  height: 3341px;
  left: -64px;
  position: absolute;
  top: 0;
  width: 529px;
}

.rectangle-250-2 {
  height: 3341px;
  left: 64px;
  position: absolute;
  top: 0;
  width: 360px;
}

.overlap-group12-item {
  height: 640px;
  left: 64px;
  position: absolute;
  top: 0;
  width: 360px;
}

.rectangle-258-1 {
  height: 283px;
  left: 64px;
  position: absolute;
  top: 364px;
  width: 360px;
}

.learn-how-to-build-a-solar-energy-system {
  height: 89px;
  left: 149px;
  position: absolute;
  top: 330px;
  width: 176px;
}

.text-search-field-49 {
  cursor: pointer;
  height: 47px;
  left: 82px;
  position: absolute;
  top: 540px;
  width: 201px;
}

.group-6879-1 {
  background-color: var(--blue-violet);
  height: 969px;
  left: 64px;
  position: absolute;
  top: 640px;
  width: 360px;
}

.frame-15::-webkit-scrollbar,
.frame-14-1::-webkit-scrollbar {
  display: none;
  width: 0;
}

.frame-15 {
  align-items: flex-end;
  display: flex;
  height: 278px;
  left: 64px;
  min-width: 360px;
  overflow-x: scroll;
  position: absolute;
  top: 1331px;
}

.text-2 {
  color: var(--black);
  font-family: var(--font-family-gellix-regular);
  font-size: var(--font-size-m);
  font-weight: 400;
  letter-spacing: 0.6px;
  line-height: 15.5px;
  margin-bottom: -6954px;
  margin-left: -3677px;
  min-height: 16px;
  min-width: 0;
  text-align: center;
  white-space: nowrap;
}

.overlap-group-container {
  align-items: flex-end;
  background-color: var(--blue-violet);
  display: flex;
  height: 278px;
  justify-content: flex-end;
  margin-left: 3677px;
  min-width: 1081px;
  padding: 9px 15px;
}

.overlap-group3-1 {
  height: 214px;
  position: relative;
  width: 330px;
}

.text {
  cursor: pointer;
  height: 64px;
  left: 152px;
  letter-spacing: 0.33px;
  position: absolute;
  text-align: right;
  top: 150px;
  width: 48px;
}

.text-1 {
  height: 64px;
  left: 128px;
  letter-spacing: 0.33px;
  opacity: 0.15;
  position: absolute;
  top: 150px;
  width: 48px;
}

.overlap-group-19 {
  height: 214px;
  margin-left: 30px;
  position: relative;
  width: 330px;
}

.text-3 {
  height: 64px;
  left: 152px;
  letter-spacing: 0.33px;
  opacity: 0.15;
  position: absolute;
  text-align: right;
  top: 150px;
  width: 48px;
}

.text-4 {
  cursor: pointer;
  height: 64px;
  left: 128px;
  letter-spacing: 0.33px;
  position: absolute;
  top: 150px;
  width: 48px;
}

.frame-14-1 {
  align-items: flex-end;
  display: flex;
  height: 209px;
  justify-content: flex-end;
  left: 64px;
  min-width: 360px;
  overflow-x: scroll;
  position: absolute;
  top: 640px;
}

.text-search-field-container-9 {
  align-items: flex-end;
  background-color: var(--ema-violet);
  display: flex;
  height: 250px;
  margin-bottom: -62px;
  min-width: 1521px;
  padding: 0 16px;
  position: relative;
}

.text-search-field-50 {
  cursor: pointer;
  display: flex;
  height: 103px;
  justify-content: center;
  margin-bottom: -0.24px;
  margin-left: 8px;
  position: relative;
  width: 160px;
}

.vector-26-1 {
  height: 251px;
  left: 64px;
  position: absolute;
  top: 660px;
  width: 360px;
}

.vector-container-1 {
  height: 330px;
  left: 0;
  position: absolute;
  top: 1001px;
  width: 529px;
}

.vector-30 {
  height: 289px;
  left: 125px;
  position: absolute;
  top: 0;
  width: 187px;
}

.vector-31 {
  height: 186px;
  left: 212px;
  position: absolute;
  top: 145px;
  width: 216px;
}

.vector-32 {
  align-items: flex-start;
  display: flex;
  height: 29px;
  left: 235px;
  min-width: 132px;
  position: absolute;
  top: 272px;
  transform: rotate(-180deg);
}

.vector-33 {
  height: 29px;
  margin-top: 0;
  transform: rotate(180deg);
  width: 132px;
}

.vector-34 {
  align-items: flex-end;
  display: flex;
  height: 184px;
  justify-content: flex-end;
  left: 360px;
  min-width: 153px;
  padding: 14.6px 0;
  position: absolute;
  top: 69px;
  transform: rotate(90deg);
}

.vector-40 {
  height: 154px;
  transform: rotate(-90deg);
  width: 184px;
}

.vector-43 {
  align-items: center;
  display: flex;
  height: 207px;
  justify-content: center;
  left: 74px;
  min-width: 176px;
  position: absolute;
  top: 22px;
  transform: rotate(-90deg);
}

.vector-44 {
  height: 176px;
  transform: rotate(90deg);
  width: 207px;
}

.vector-45 {
  height: 187px;
  left: 0;
  position: absolute;
  top: 103px;
  width: 162px;
}

.x121170480_1762245074-1 {
  height: 218px;
  left: 81px;
  object-fit: cover;
  position: absolute;
  top: 1056px;
  width: 327px;
}

.answers-hub {
  left: 64px;
  letter-spacing: 0.64px;
  position: absolute;
  text-align: center;
  top: 1689px;
  width: 360px;
}

.group-6882-1 {
  align-items: center;
  display: flex;
  flex-direction: column;
  left: 131px;
  min-height: 331px;
  position: absolute;
  top: 1794px;
  width: 225px;
}

.group-6858-2 {
  align-items: flex-end;
  display: flex;
  flex-direction: column;
  min-height: 276px;
  width: 225px;
}

.x131662611_3760936164-2 {
  height: 144px;
  margin-right: 4px;
  object-fit: cover;
  width: 216px;
}

.group-6853-2 {
  align-items: flex-end;
  display: flex;
  margin-top: 21px;
  width: 225px;
}

.group-6814-1 {
  align-items: flex-start;
  display: flex;
  min-width: 229px;
}

.energy-makers-academ-container {
  height: 111px;
  position: relative;
  width: 225px;
}

.what {
  left: 0;
  letter-spacing: 0.6px;
  line-height: 15.5px;
  position: absolute;
  text-align: center;
  top: 0;
}

.span-18 {
  letter-spacing: 0.07px;
}

.energy-makers-academ {
  color: transparent;
  font-family: var(--font-family-gellix_trial-regular);
  font-size: var(--font-size-m);
  font-weight: 400;
  left: 5px;
  letter-spacing: 0.6px;
  line-height: 15.5px;
  position: absolute;
  text-align: justify;
  top: 0;
  width: 216px;
}

.span0-1 {
  color: var(--ema-white);
  letter-spacing: 0.07px;
}

.span1-1 {
  color: var(--ema-dark-violet);
  letter-spacing: 0.07px;
}

.text-search-field-48 {
  background-color: var(--shamrock);
  border-radius: 8px;
  cursor: pointer;
  display: flex;
  height: 47px;
  justify-content: center;
  margin-left: 1.97px;
  margin-top: 8px;
  position: relative;
  width: 201px;
}

.overlap-group7-2 {
  height: 331px;
  left: 64px;
  position: absolute;
  top: 2931px;
  width: 360px;
}

.group-container-6 {
  height: 331px;
  left: 0;
  position: absolute;
  top: 0;
  width: 360px;
}

.group-688-1 {
  align-items: center;
  display: flex;
  flex-direction: column;
  left: 0;
  min-height: 331px;
  position: absolute;
  top: 0;
  width: 360px;
}

.group-6858-1 {
  align-items: center;
  display: flex;
  flex-direction: column;
  min-height: 276px;
  width: 360px;
}

.x131662611_3760936164-1 {
  height: 144px;
  margin-left: 0;
  object-fit: cover;
  width: 216px;
}

.group-6853-1 {
  align-items: flex-end;
  display: flex;
  height: 111px;
  margin-top: 21px;
  width: 360px;
}

.group-6814-2 {
  align-items: flex-end;
  display: flex;
  width: 362px;
}

.why-partner-with-us {
  height: 111.33px;
  letter-spacing: 0.6px;
  line-height: 15.5px;
  text-align: center;
  width: 360px;
}

.x218432608_3479093236-1,
.oel_facebook-1 {
  height: 144px;
  left: 72px;
  object-fit: cover;
  position: absolute;
  top: 0;
  width: 216px;
}

.overlap-group8-1 {
  height: 331px;
  left: 64px;
  position: absolute;
  top: 2552px;
  width: 360px;
}

.group-6814-3 {
  align-items: flex-start;
  display: flex;
  height: 111.33px;
  min-width: 362px;
}

.overlap-group1-8 {
  height: 111px;
  position: relative;
  width: 360px;
}

.what-have-previous-students-said {
  left: 0;
  letter-spacing: 0.6px;
  line-height: 15.5px;
  position: absolute;
  text-align: center;
  top: 0;
  width: 360px;
}

.text-search-field-51 {
  background-color: var(--shamrock);
  border-radius: 8px;
  cursor: pointer;
  display: flex;
  height: 47px;
  justify-content: center;
  margin-left: 0.97px;
  margin-top: 8px;
  position: relative;
  width: 201px;
}

.overlap-group9-2 {
  height: 331px;
  left: 129px;
  position: absolute;
  top: 2173px;
  width: 229px;
}

.group-6889 {
  align-items: center;
  display: flex;
  flex-direction: column;
  left: 0;
  min-height: 331px;
  position: absolute;
  top: 0;
  width: 229px;
}

.group-6858-3 {
  align-items: center;
  display: flex;
  flex-direction: column;
  min-height: 276px;
  width: 229px;
}

.x131662611_3760936164-3 {
  height: 144px;
  margin-left: 1px;
  object-fit: cover;
  width: 216px;
}

.group-6853-3 {
  align-items: flex-end;
  display: flex;
  margin-top: 21px;
  width: 229px;
}

.group-6814-4 {
  align-items: flex-start;
  display: flex;
  min-width: 233px;
}

.overlap-group-22 {
  height: 111px;
  position: relative;
  width: 229px;
}

.through-hands-on-lea {
  left: 7px;
  letter-spacing: 0.6px;
  line-height: 15.5px;
  position: absolute;
  text-align: justify;
  top: 0;
  width: 216px;
}

.x129841425_2027698981-1 {
  height: 144px;
  left: 7px;
  object-fit: cover;
  position: absolute;
  top: 0;
  width: 216px;
}

.flex-row-1 {
  align-items: flex-start;
  display: flex;
  height: 4874px;
  left: 0;
  min-width: 9748px;
  position: absolute;
  top: 3341px;
}

.overlap-group-container-1 {
  height: 4874px;
  margin-top: -0.07px;
  position: relative;
  width: 9748px;
}

.overlap-group-20 {
  height: 261px;
  left: 0;
  position: absolute;
  top: 0;
  width: 361px;
}

.vector-38-7 {
  height: 65px;
  left: 0;
  position: absolute;
  top: 0;
  width: 1px;
}

.overlap-group1-9 {
  height: 260px;
  left: 0;
  position: absolute;
  top: 0;
  width: 361px;
}

.overlap-group-23 {
  align-items: flex-end;
  background-color: var(--princess-perfume);
  display: flex;
  height: 260px;
  justify-content: flex-end;
  left: 0;
  min-width: 360px;
  padding: 11.1px 25px;
  position: absolute;
  top: 0;
}

.ema-container-2 {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  min-height: 173px;
  width: 65px;
}

.ema-1 {
  letter-spacing: 0.6px;
  line-height: 15.5px;
  min-height: 44px;
  text-align: center;
  width: 65px;
}

.ema-you-tube-1 {
  letter-spacing: 0.6px;
  line-height: 15.5px;
  margin-top: 85px;
  min-height: 44px;
  text-align: center;
  width: 65px;
}

.ema-container-3 {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  margin-left: 55px;
  min-height: 172px;
  width: 65px;
}

.ema-instagram-1 {
  letter-spacing: 0.6px;
  line-height: 15.5px;
  margin-top: 84px;
  min-height: 44px;
  text-align: center;
  width: 65px;
}

.ema-linked-in-1 {
  align-self: center;
  letter-spacing: 0.6px;
  line-height: 15.5px;
  margin-bottom: 63.95px;
  margin-left: 55px;
  min-height: 44px;
  text-align: center;
  width: 66px;
}

.group-6903-1 {
  display: flex;
  height: 130px;
  justify-content: flex-end;
  left: 120px;
  position: absolute;
  top: 0;
  width: 120px;
}

.vector-39-7 {
  height: 130px;
  margin-right: 119px;
  width: 1px;
}

.vector-35-9 {
  height: 130px;
  margin-right: -0.5px;
  width: 1px;
}

.vector-35-10 {
  height: 130px;
  left: 240px;
  position: absolute;
  top: 130px;
  width: 1px;
}

.vector-39-8 {
  height: 130px;
  left: 120px;
  position: absolute;
  top: 130px;
  width: 1px;
}

.vector-37-6 {
  height: 65px;
  left: 360px;
  position: absolute;
  top: 0;
  width: 1px;
}

.vector-36-8 {
  height: 1px;
  left: 0;
  position: absolute;
  top: 130px;
  width: 360px;
}

.vector-35-11 {
  height: 131px;
  left: 240px;
  position: absolute;
  top: 130px;
  width: 121px;
}

.group-container-7 {
  height: 4614px;
  left: 0;
  position: absolute;
  top: 260px;
  width: 9748px;
}

.group-6896-1 {
  align-items: flex-end;
  display: flex;
  height: 399px;
  left: 0;
  position: absolute;
  top: 636px;
  width: 360px;
}

.footer-2 {
  align-items: flex-end;
  display: flex;
  height: 399px;
  min-width: 360px;
}

.overlap-group3-2 {
  height: 640px;
  margin-bottom: -241px;
  position: relative;
  width: 360px;
}

.group-6840-5 {
  background-size: 100% 100%;
  height: 30px;
  left: 18px;
  position: absolute;
  top: 19px;
  width: 82px;
}

.overlap-group11-2 {
  height: 4614px;
  left: 0;
  position: absolute;
  top: 0;
  width: 9758px;
}

.rectangle-256 {
  background-color: var(--burnt-orange);
  height: 640px;
  left: 0;
  position: absolute;
  top: 0;
  width: 360px;
}

.group-6890-1 {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  left: 14px;
  min-height: 4396px;
  position: absolute;
  top: 218px;
  width: 9744px;
}

.overlap-group3-3 {
  height: 54px;
  position: relative;
  width: 334px;
}

.rectangle-257-1 {
  background-color: var(--burnt-orange);
  height: 54px;
  left: 29px;
  position: absolute;
  top: 0;
  width: 274px;
}

.your-email-address-1,
.first-name-1,
.last-name-1 {
  left: 0;
  letter-spacing: 0.36px;
  line-height: 21.5px;
  position: absolute;
  text-align: center;
  top: 15px;
  white-space: nowrap;
  width: 334px;
}

.overlap-group-21 {
  height: 54px;
  margin-top: 6px;
  position: relative;
  width: 334px;
}

.overlap-group-24 {
  height: 54px;
  margin-top: 6px;
  position: relative;
  width: 333px;
}

.phone-number-1 {
  left: 0;
  letter-spacing: 0.36px;
  line-height: 21.5px;
  position: absolute;
  text-align: center;
  top: 15px;
  white-space: nowrap;
  width: 333px;
}

.overlap-group4-2 {
  align-items: flex-end;
  background-color: var(--hit-pink);
  border-radius: 8px;
  display: flex;
  height: 47px;
  justify-content: flex-end;
  margin-left: 66px;
  margin-top: 31px;
  min-width: 198px;
  padding: 11px 28px;
}

.submit-1 {
  letter-spacing: 0.6px;
  line-height: 21.5px;
  min-height: 24px;
  text-align: center;
  white-space: nowrap;
  width: 141px;
}

.first-name-2 {
  align-self: flex-end;
  letter-spacing: 0.36px;
  line-height: 21.5px;
  margin-right: 12px;
  margin-top: 4060px;
  min-height: 24px;
  text-align: center;
  white-space: nowrap;
  width: 334px;
}

.updates-news-1 {
  left: 45px;
  letter-spacing: 0.64px;
  position: absolute;
  text-align: center;
  top: 81px;
  width: 273px;
}

.nav-5 {
  height: 65px;
  left: 0;
  position: fixed;
  top: 0;
  width: 360px;
}

.group-6825-3 {
  cursor: pointer;
  height: 18px;
  left: 310px;
  position: fixed;
  top: 23px;
  width: 37px;
}
</style>
