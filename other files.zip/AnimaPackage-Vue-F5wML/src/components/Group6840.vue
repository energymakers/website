<template>
  <div class="group-6840-1">
    <div class="overlap-group1-4">
      <textsearchfield42 />
      <div class="group-6839-5">
        <div class="group-6839-8">
          <div class="overlap-group-12">
            <textsearchfield5 :children="tEXTSEARCHFIELD5Props.children" />
            <img
              class="vector-41-2"
              src="https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-41-1@2x.png"
            />
            <img
              class="vector-42-2"
              src="https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61bf007560d7a2ff15bd384e/img/vector-42-1@2x.png"
            />
          </div>
        </div>
      </div>
    </div>
    <div class="text-search-field-container-3">
      <textsearchfield5 :children="tEXTSEARCHFIELD52Props.children" />
      <textsearchfield6 />
    </div>
  </div>
</template>

<script>
import Textsearchfield42 from "./Textsearchfield42";
import Textsearchfield5 from "./Textsearchfield5";
import Textsearchfield6 from "./Textsearchfield6";
export default {
  name: "Group6840",
  components: {
    Textsearchfield42,
    Textsearchfield5,
    Textsearchfield6,
  },
  props: ["tEXTSEARCHFIELD5Props", "tEXTSEARCHFIELD52Props"],
};
</script>

<style>
.group-6840-1,
.group-6840-2,
.group-6838-2 {
  align-items: flex-end;
  background-color: var(--ema-violet);
  display: flex;
  height: 625px;
  left: 0;
  min-width: 360px;
  padding: 63.7px 16px;
  position: absolute;
  top: 0;
}

.overlap-group1-4,
.overlap-group2-3,
.overlap-group1-5 {
  height: 448px;
  position: relative;
  width: 154px;
}

.group-6839-5,
.group-6839-9,
.group-6839-11 {
  display: flex;
  height: 284px;
  left: 0;
  position: absolute;
  top: 0;
  width: 152px;
}

.group-6839-8,
.group-6839-10,
.group-6839-12 {
  align-items: flex-start;
  display: flex;
  height: 284.09px;
  min-width: 152px;
}

.overlap-group-12,
.overlap-group-14,
.overlap-group-15 {
  height: 284px;
  position: relative;
  width: 152px;
}

.vector-41-2,
.vector-41-4,
.vector-41-5 {
  height: 2px;
  left: 1px;
  position: absolute;
  top: 94px;
  width: 126px;
}

.vector-42-2,
.vector-42-4,
.vector-42-5 {
  height: 2px;
  left: 1px;
  position: absolute;
  top: 142px;
  width: 77px;
}

.text-search-field-container-3,
.text-search-field-container-4,
.text-search-field-container-5 {
  height: 448px;
  margin-left: 14px;
  position: relative;
  width: 152px;
}
</style>
