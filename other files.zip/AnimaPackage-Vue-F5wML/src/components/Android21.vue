<template>
  <div class="container-center-horizontal">
    <div class="android-21 screen">
      <div class="overlap-group12">
        <div class="overlap-group13">
          <div class="rectangle-261"></div>
          <img class="x218432609" :src="x218432609" />
        </div>
        <p class="university-of-zambia gellix-regular-normal-white-15-9px" v-html="universityOfZambia"></p>
        <textsearchfield :children="textsearchfieldProps.children" :className="textsearchfieldProps.className" />
      </div>
      <div class="nav-4">
        <div class="group-container-3">
          <div class="overlap-group-16">
            <div class="group-6806-3"></div>
            <img class="vector-35-7" :src="vector35" /><img class="vector-36-6" :src="vector36" />
          </div>
          <router-link to="/mob-website-1">
            <div class="group-6810-3"><frame /></div
          ></router-link>
        </div>
      </div>
      <a href="javascript:ShowOverlay('android-24', 'animate-appear');">
        <div class="group-6825-2">
          <img class="vector-38-5" :src="vector38" /><img class="vector-37-4" :src="vector37" /><img
            class="vector-39-5"
            :src="vector39"
          /></div></a
      ><group68132 />
      <div class="overlap-group11-1">
        <div class="group-6912">
          <div class="rectangle-261-1"></div>
          <p class="copperbelt-universit-1 gellix-regular-normal-white-15-9px" v-html="copperbeltUniversit"></p>
          <textsearchfield :children="textsearchfield2Props.children" :className="textsearchfield2Props.className" />
          <group68132 :className="group68132Props.className" />
        </div>
        <img class="cbu-1" :src="cbu1" />
      </div>
      <div class="footer-1">
        <div class="overlap-group9-1">
          <div class="group-6838-3">
            <div class="group-container-4">
              <div class="overlap-group4-1">
                <div class="text-search-field-42">
                  <div class="search-icon-41">
                    <router-link to="/android-25">
                      <p class="about-us-mission-v-3 gellix-regular-normal-white-12px-2">
                        <span class="span-17 gellix-regular-normal-white-12px">{{ spanText }}</span
                        ><span class="span-17 gellix-regular-normal-dull-lavender-12px">{{ spanText2 }}</span>
                      </p>
                    </router-link>
                    <div class="news-latest-news-newsletter-gallery-1 gellix-regular-normal-white-12px-2">
                      <span class="span-17 gellix-regular-normal-white-12px">{{ spanText3 }}</span
                      ><span class="span-17 gellix-regular-normal-dull-lavender-12px">{{ spanText4 }}</span>
                    </div>
                  </div>
                </div>
                <group6839
                  :vector41="group6839Props.vector41"
                  :vector42="group6839Props.vector42"
                  :className="group6839Props.className"
                  :tEXTSEARCHFIELD4Props="group6839Props.tEXTSEARCHFIELD4Props"
                />
              </div>
              <div class="text-search-field-container-6">
                <textsearchfield2 :className="textsearchfield2Props2.className" />
                <textsearchfield32 :className="textsearchfield32Props.className" />
              </div>
              <div class="group-6840-3">
                <div class="overlap-group1-6">
                  <textsearchfield42 :className="textsearchfield42Props.className" />
                  <div class="group-6839-13">
                    <div class="group-6839-14">
                      <div class="overlap-group-17">
                        <textsearchfield5
                          :children="textsearchfield5Props.children"
                          :className="textsearchfield5Props.className"
                        />
                        <img class="vector-41-6" :src="vector41" /><img class="vector-42-6" :src="vector42" />
                      </div>
                    </div>
                  </div>
                </div>
                <div class="text-search-field-container-7">
                  <textsearchfield5
                    :children="textsearchfield52Props.children"
                    :className="textsearchfield52Props.className"
                  />
                  <textsearchfield6 :className="textsearchfield6Props.className" />
                </div>
              </div>
            </div>
          </div>
          <div class="group-6840-4" :style="{ 'background-image': 'url(' + group6840 + ')' }"></div>
          <div class="group-6841">
            <div class="group-container-5">
              <div class="overlap-group6-1">
                <div class="text-search-field-43">
                  <div class="search-icon-42">
                    <router-link to="/android-25">
                      <p class="about-us-mission-v-6 gellix-regular-normal-white-12px-2">
                        <span class="span-17 gellix-regular-normal-white-12px">{{ spanText5 }}</span
                        ><span class="span-17 gellix-regular-normal-dull-lavender-12px">{{ spanText6 }}</span>
                      </p>
                    </router-link>
                    <div class="news-latest-news-newsletter-gallery-2 gellix-regular-normal-white-12px-2">
                      <span class="span-17 gellix-regular-normal-white-12px">{{ spanText7 }}</span
                      ><span class="span-17 gellix-regular-normal-dull-lavender-12px">{{ spanText8 }}</span>
                    </div>
                  </div>
                </div>
                <group6839
                  :vector41="group68392Props.vector41"
                  :vector42="group68392Props.vector42"
                  :tEXTSEARCHFIELD4Props="group68392Props.tEXTSEARCHFIELD4Props"
                />
              </div>
              <div class="text-search-field-container-8">
                <textsearchfield2 />
                <textsearchfield32 />
              </div>
              <group6840
                :tEXTSEARCHFIELD5Props="group6840Props.tEXTSEARCHFIELD5Props"
                :tEXTSEARCHFIELD52Props="group6840Props.tEXTSEARCHFIELD52Props"
              />
            </div>
          </div>
          <div class="group-6842" :style="{ 'background-image': 'url(' + group6842 + ')' }"></div>
          <frame6 />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Textsearchfield from "./Textsearchfield";
import Frame from "./Frame";
import Group68132 from "./Group68132";
import Group6839 from "./Group6839";
import Textsearchfield2 from "./Textsearchfield2";
import Textsearchfield32 from "./Textsearchfield32";
import Textsearchfield42 from "./Textsearchfield42";
import Textsearchfield5 from "./Textsearchfield5";
import Textsearchfield6 from "./Textsearchfield6";
import Group6840 from "./Group6840";
import Frame6 from "./Frame6";
export default {
  name: "Android21",
  components: {
    Textsearchfield,
    Frame,
    Group68132,
    Group6839,
    Textsearchfield2,
    Textsearchfield32,
    Textsearchfield42,
    Textsearchfield5,
    Textsearchfield6,
    Group6840,
    Frame6,
  },
  props: [
    "x218432609",
    "universityOfZambia",
    "vector35",
    "vector36",
    "vector38",
    "vector37",
    "vector39",
    "copperbeltUniversit",
    "cbu1",
    "spanText",
    "spanText2",
    "spanText3",
    "spanText4",
    "vector41",
    "vector42",
    "group6840",
    "spanText5",
    "spanText6",
    "spanText7",
    "spanText8",
    "group6842",
    "textsearchfieldProps",
    "textsearchfield2Props",
    "group68132Props",
    "group6839Props",
    "textsearchfield2Props2",
    "textsearchfield32Props",
    "textsearchfield42Props",
    "textsearchfield5Props",
    "textsearchfield52Props",
    "textsearchfield6Props",
    "group68392Props",
    "group6840Props",
  ],
};
</script>

<style>
.android-21 {
  align-items: center;
  background-color: var(--ema-violet);
  display: flex;
  flex-direction: column;
  min-height: 640px;
  overflow-x: hidden;
  position: relative;
  width: 360px;
}

.overlap-group12 {
  align-items: center;
  background-color: var(--ema-violet);
  display: flex;
  flex-direction: column;
  margin-left: 2px;
  min-height: 640px;
  padding: 26px 0;
  position: relative;
  width: 360px;
  z-index: 1;
}

.overlap-group13 {
  height: 219px;
  margin-top: 59px;
  position: relative;
  width: 330px;
}

.rectangle-261 {
  background-color: var(--ema-white);
  border-radius: 12px;
  height: 219px;
  left: 0;
  position: absolute;
  top: 0;
  width: 328px;
}

.x218432609 {
  height: 219px;
  left: 0;
  position: absolute;
  top: 0;
  width: 330px;
}

.university-of-zambia {
  letter-spacing: 0.48px;
  line-height: 21.3px;
  margin-right: 2px;
  margin-top: 21px;
  min-height: 217px;
  width: 324px;
}

.nav-4 {
  align-items: flex-end;
  display: flex;
  height: 64px;
  left: 0;
  min-width: 360px;
  position: fixed;
  top: 0;
  z-index: 5;
}

.group-container-3 {
  height: 65px;
  margin-bottom: -0.5px;
  position: relative;
  width: 360px;
}

.overlap-group-16 {
  height: 65px;
  left: 0;
  position: absolute;
  top: 0;
  width: 360px;
}

.group-6806-3 {
  background-color: var(--dull-lavender-2);
  height: 64px;
  left: 296px;
  position: absolute;
  top: 0;
  width: 64px;
}

.vector-35-7 {
  height: 64px;
  left: 295px;
  position: absolute;
  top: 0;
  width: 2px;
}

.vector-36-6 {
  height: 1px;
  left: 0;
  position: absolute;
  top: 64px;
  width: 360px;
}

.group-6810-3 {
  cursor: pointer;
  display: flex;
  height: 30px;
  left: 18px;
  position: absolute;
  top: 19px;
  width: 82px;
}

.group-6825-2 {
  align-items: flex-end;
  cursor: pointer;
  display: flex;
  flex-direction: column;
  height: 16px;
  left: 311px;
  position: fixed;
  top: 24px;
  width: 35px;
  z-index: 6;
}

.vector-38-5 {
  height: 1px;
  margin-right: -0.4px;
  margin-top: -0.5px;
  width: 36px;
}

.vector-37-4 {
  height: 1px;
  margin-right: -0.4px;
  margin-top: 7px;
  width: 36px;
}

.vector-39-5 {
  height: 1px;
  margin-right: -0.4px;
  margin-top: 7px;
  width: 36px;
}

.overlap-group11-1 {
  height: 685px;
  margin-left: 4px;
  margin-top: 33px;
  position: relative;
  width: 330px;
  z-index: 3;
}

.group-6912 {
  display: flex;
  flex-direction: column;
  height: 685px;
  left: 0;
  position: absolute;
  top: 0;
  width: 330px;
}

.rectangle-261-1 {
  background-color: var(--ema-white);
  border-radius: 12px;
  height: 219px;
  width: 328px;
}

.copperbelt-universit-1 {
  height: 259px;
  letter-spacing: 0.48px;
  line-height: 21.3px;
  margin-left: 2px;
  margin-top: 21px;
  width: 324px;
}

.cbu-1 {
  height: 220px;
  left: 49px;
  object-fit: cover;
  position: absolute;
  top: 0;
  width: 219px;
}

.footer-1 {
  align-items: flex-start;
  display: flex;
  height: 399px;
  justify-content: flex-end;
  margin-top: 67px;
  min-width: 360px;
  z-index: 4;
}

.overlap-group9-1 {
  height: 640px;
  margin-top: -67.93px;
  position: relative;
  width: 360px;
}

.group-6838-3 {
  align-items: flex-start;
  background-color: var(--ema-violet);
  display: flex;
  height: 622px;
  left: 0;
  min-width: 360px;
  position: absolute;
  top: 18px;
}

.group-container-4 {
  height: 620px;
  position: relative;
  width: 360px;
}

.overlap-group4-1 {
  height: 445px;
  left: 16px;
  position: absolute;
  top: 113px;
  width: 154px;
}

.text-search-field-42 {
  align-items: center;
  display: flex;
  height: 277px;
  left: 2px;
  position: absolute;
  top: 169px;
  width: 152px;
}

.search-icon-41 {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  min-height: 276.74px;
  width: 156px;
}

.about-us-mission-v-3 {
  cursor: pointer;
  letter-spacing: 0.6px;
  line-height: 15.5px;
  min-height: 94px;
  width: 102px;
}

.span-17 {
  letter-spacing: 0.07px;
}

.news-latest-news-newsletter-gallery-1 {
  letter-spacing: 0.6px;
  line-height: 15.5px;
  margin-top: 20px;
  min-height: 163px;
  width: 152px;
}

.text-search-field-container-6 {
  height: 445px;
  left: 184px;
  position: absolute;
  top: 113px;
  width: 152px;
}

.group-6840-3 {
  align-items: flex-end;
  background-color: var(--ema-violet);
  display: flex;
  height: 620px;
  left: 0;
  min-width: 360px;
  padding: 63.2px 16px;
  position: absolute;
  top: 0;
}

.overlap-group1-6 {
  height: 444px;
  position: relative;
  width: 154px;
}

.group-6839-13 {
  display: flex;
  height: 282px;
  left: 0;
  position: absolute;
  top: 0;
  width: 152px;
}

.group-6839-14 {
  align-items: flex-start;
  display: flex;
  height: 281.79px;
  min-width: 152px;
}

.overlap-group-17 {
  height: 282px;
  position: relative;
  width: 152px;
}

.vector-41-6 {
  height: 2px;
  left: 1px;
  position: absolute;
  top: 93px;
  width: 126px;
}

.vector-42-6 {
  height: 2px;
  left: 1px;
  position: absolute;
  top: 141px;
  width: 77px;
}

.text-search-field-container-7 {
  height: 444px;
  margin-left: 14px;
  position: relative;
  width: 152px;
}

.group-6840-4 {
  background-size: 100% 100%;
  height: 30px;
  left: 17px;
  position: absolute;
  top: 87px;
  width: 82px;
}

.group-6841 {
  align-items: flex-start;
  background-color: var(--ema-violet);
  display: flex;
  height: 627px;
  left: 0;
  min-width: 360px;
  position: absolute;
  top: 0;
}

.group-container-5 {
  height: 625px;
  position: relative;
  width: 360px;
}

.overlap-group6-1 {
  height: 449px;
  left: 16px;
  position: absolute;
  top: 114px;
  width: 154px;
}

.text-search-field-43 {
  align-items: center;
  display: flex;
  height: 279px;
  left: 2px;
  position: absolute;
  top: 170px;
  width: 152px;
}

.search-icon-42 {
  align-items: flex-start;
  display: flex;
  flex-direction: column;
  min-height: 279px;
  width: 156px;
}

.about-us-mission-v-6 {
  cursor: pointer;
  letter-spacing: 0.6px;
  line-height: 15.5px;
  min-height: 95px;
  width: 102px;
}

.news-latest-news-newsletter-gallery-2 {
  letter-spacing: 0.6px;
  line-height: 15.5px;
  margin-top: 20px;
  min-height: 164px;
  width: 152px;
}

.text-search-field-container-8 {
  height: 449px;
  left: 184px;
  position: absolute;
  top: 114px;
  width: 152px;
}

.group-6842 {
  background-size: 100% 100%;
  height: 30px;
  left: 17px;
  position: absolute;
  top: 19px;
  width: 82px;
}
</style>
