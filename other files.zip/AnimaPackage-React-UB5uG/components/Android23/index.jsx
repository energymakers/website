import React from "react";
import { Link } from "react-router-dom";
import SearchIcon3 from "../SearchIcon3";
import TEXTSEARCHFIELD7 from "../TEXTSEARCHFIELD7";
import SearchIcon4 from "../SearchIcon4";
import SearchIcon5 from "../SearchIcon5";
import TEXTSEARCHFIELD8 from "../TEXTSEARCHFIELD8";
import Frame from "../Frame";
import XNav from "../XNav";
import "./Android23.css";

function Android23(props) {
  const {
    vector38,
    twitterFacebook,
    linkedinInstagram,
    vector35,
    vector39,
    vector36,
    vector37,
    newsletterSignUp,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="android-23 screen">
        <div className="overlap-group2-1">
          <div className="rectangle-251"></div>
          <div className="group-6820">
            <Link to="/android-21">
              <div className="text-search-field-19">
                <SearchIcon3 />
              </div>
            </Link>
            <TEXTSEARCHFIELD7 />
            <Link to="/android-25">
              <div className="text-search-field-21">
                <SearchIcon4 />
              </div>
            </Link>
            <Link to="/frame-21">
              <div className="text-search-field-22">
                <SearchIcon5 />
              </div>
            </Link>
            <TEXTSEARCHFIELD8 />
          </div>
          <Link to="/mob-website-1">
            <div className="group-6810-1">
              <Frame />
            </div>
          </Link>
          <img className="vector-38-2" src={vector38} />
          <div className="overlap-group-6">
            <div className="group-6822 gellix-regular-normal-white-12px">
              <div className="group-6822-item">{twitterFacebook}</div>
              <div className="group-6822-item">{linkedinInstagram}</div>
            </div>
            <img className="vector-35-3" src={vector35} />
            <img className="vector-39-2" src={vector39} />
            <img className="vector-36-2" src={vector36} />
            <img className="vector-37-1" src={vector37} />
          </div>
          <div className="overlap-group1-2">
            <div className="rectangle-65"></div>
            <div className="search-icon-16">
              <div className="newsletter-sign-up valign-text-middle gellix-regular-normal-white-12px">
                {newsletterSignUp}
              </div>
            </div>
          </div>
        </div>
        <XNav />
      </div>
    </div>
  );
}

export default Android23;
