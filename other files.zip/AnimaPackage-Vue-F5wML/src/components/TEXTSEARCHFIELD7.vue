<template>
  <div class="text-search-field-23">
    <div class="search-icon-19">
      <div class="projects valign-text-middle gellix-regular-normal-white-18px">PROJECTS</div>
    </div>
  </div>
</template>

<script>
export default {
  name: "TEXTSEARCHFIELD7",
};
</script>

<style>
.text-search-field-23,
.text-search-field-24 {
  align-items: center;
  display: flex;
  height: 35.71px;
  justify-content: center;
  margin-left: 26px;
  margin-top: 12.1px;
  width: 163.06px;
}

.search-icon-19,
.search-icon-20 {
  align-items: center;
  display: flex;
  justify-content: center;
  margin-left: 2px;
  margin-top: 0.5px;
  width: 165.06px;
}

.projects,
.projects-1 {
  height: 20.13px;
  letter-spacing: 0.9px;
  line-height: 14.5px;
  margin-left: -2px;
  text-align: center;
  width: 163.06px;
}
</style>
