import React from "react";
import { Link } from "react-router-dom";
import SearchIcon3 from "../SearchIcon3";
import TEXTSEARCHFIELD7 from "../TEXTSEARCHFIELD7";
import SearchIcon4 from "../SearchIcon4";
import SearchIcon5 from "../SearchIcon5";
import TEXTSEARCHFIELD8 from "../TEXTSEARCHFIELD8";
import Frame from "../Frame";
import XNav from "../XNav";
import "./Android24.css";

function Android24(props) {
  const {
    vector38,
    twitterFacebook,
    linkedinInstagram,
    vector35,
    vector39,
    vector36,
    vector37,
    newsletterSignUp,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="android-24 screen">
        <div className="overlap-group2-4">
          <div className="rectangle-251-1"></div>
          <div className="group-6820-1">
            <Link to="/android-21">
              <div className="text-search-field-44">
                <SearchIcon3 />
              </div>
            </Link>
            <TEXTSEARCHFIELD7 />
            <Link to="/android-25">
              <div className="text-search-field-45">
                <SearchIcon4 />
              </div>
            </Link>
            <Link to="/frame-21">
              <div className="text-search-field-46">
                <SearchIcon5 />
              </div>
            </Link>
            <TEXTSEARCHFIELD8 />
          </div>
          <div className="text-search-field-47"></div>
          <Link to="/mob-website-1">
            <div className="group-6810-4">
              <Frame />
            </div>
          </Link>
          <img className="vector-38-6" src={vector38} />
          <div className="overlap-group-18">
            <div className="group-6822-1 gellix-regular-normal-white-12px">
              <div className="group-6822-item-1">{twitterFacebook}</div>
              <div className="group-6822-item-1">{linkedinInstagram}</div>
            </div>
            <img className="vector-35-8" src={vector35} />
            <img className="vector-39-6" src={vector39} />
            <img className="vector-36-7" src={vector36} />
            <img className="vector-37-5" src={vector37} />
          </div>
          <div className="overlap-group1-7">
            <div className="rectangle-65-1"></div>
            <div className="search-icon-43">
              <div className="newsletter-sign-up-1 valign-text-middle gellix-regular-normal-white-12px">
                {newsletterSignUp}
              </div>
            </div>
          </div>
        </div>
        <XNav />
      </div>
    </div>
  );
}

export default Android24;
