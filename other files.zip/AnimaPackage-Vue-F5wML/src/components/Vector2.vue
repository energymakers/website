<template>
  <div :class="[`vector-14`, className || ``]"><img class="vector-15" :src="src" /></div>
</template>

<script>
export default {
  name: "Vector2",
  props: ["src", "className"],
};
</script>

<style>
.vector-14 {
  align-items: center;
  display: flex;
  height: 36px;
  left: 161px;
  min-width: 41px;
  padding: 0 20.2px;
  position: absolute;
  top: 157px;
}

.vector-15 {
  height: 1px;
  width: 1px;
}

.vector-14.vector-16 {
  align-items: flex-start;
  height: 37px;
  padding: unset;
  top: 160px;
}

.vector-14.vector-16 .vector-15 {
  height: 38px;
  margin-top: -0.47px;
  width: 41px;
}
</style>
