import React from "react";
import "./Frame6.css";

function Frame6(props) {
  const { className } = props;

  return (
    <div className={`frame-6 ${className || ""}`}>
      <p className="copyright-2021-energy-makers-academy valign-text-middle gellix-regular-normal-white-11px">
        © Copyright 2021, Energy Makers Academy
      </p>
    </div>
  );
}

export default Frame6;
