<template>
  <div :class="[`group-6813-2`, className || ``]">
    <div class="group-6813-1">
      <img
        class="vector-25-2"
        src="https://anima-uploads.s3.amazonaws.com/projects/61b8c2a948d8dc1b95e34253/releases/61c390fadbfb8eee2ef63e4f/img/vector-25-3@2x.png"
      />
    </div>
  </div>
</template>

<script>
export default {
  name: "Group68132",
  props: ["className"],
};
</script>

<style>
.group-6813-2 {
  display: flex;
  margin-left: 0.79px;
  margin-top: 1px;
  width: 323px;
  z-index: 2;
}

.group-6813-1 {
  display: flex;
  flex: 1;
  height: 0;
}

.vector-25-2 {
  flex: 1;
  height: 1px;
  margin-left: -0.1px;
  margin-right: -0.1px;
  margin-top: -0.5px;
}

.group-6813-2.group-6911 {
  margin-left: 2px;
  margin-top: 104.9px;
  width: 322.79px;
  z-index: unset;
}
</style>
