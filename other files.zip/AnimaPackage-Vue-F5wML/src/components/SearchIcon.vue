<template>
  <div class="search-icon-1">
    <div class="join-a-programme valign-text-middle gellix-regular-normal-minsk-12px">{{ joinAProgramme }}</div>
  </div>
</template>

<script>
export default {
  name: "SearchIcon",
  props: ["joinAProgramme"],
};
</script>

<style>
.search-icon-1,
.search-icon-2 {
  display: flex;
  justify-content: center;
  margin-left: 2.7px;
  margin-top: 15px;
  width: 152px;
}

.join-a-programme,
.partner-with-us,
.join-a-programme-1,
.partner-with-us-1,
.join-a-programme-2,
.join-a-programme-3,
.partner-with-us-2,
.join-a-programme-4,
.learn-more {
  height: 18px;
  letter-spacing: 0.6px;
  line-height: 14.5px;
  margin-left: -2px;
  text-align: center;
  width: 150px;
}
</style>
