<template>
  <div class="text-search-field-10">
    <div class="search-icon-5">
      <div class="upcoming-programmes gellix-regular-normal-shamrock-12px">UPCOMING<br />PROGRAMMES</div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Textsearchfield3",
};
</script>

<style>
.text-search-field-10,
.text-search-field-11 {
  display: flex;
  height: 87px;
  justify-content: center;
  left: 80px;
  position: absolute;
  top: 680px;
  width: 270px;
}

.search-icon-5,
.search-icon-6 {
  display: flex;
  justify-content: center;
  margin-left: 2px;
  width: 272px;
}

.upcoming-programmes,
.upcoming-programmes-1 {
  height: 87px;
  letter-spacing: 0.6px;
  line-height: 15.5px;
  margin-left: -2px;
  width: 270px;
}
</style>
