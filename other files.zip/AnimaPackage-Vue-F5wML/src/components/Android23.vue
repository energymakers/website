<template>
  <div class="container-center-horizontal">
    <div class="android-23 screen">
      <div class="overlap-group2-1">
        <div class="rectangle-251"></div>
        <div class="group-6820">
          <router-link to="/android-21">
            <div class="text-search-field-19"><search-icon3 /></div></router-link
          ><textsearchfield7 />
          <router-link to="/android-25">
            <div class="text-search-field-21"><search-icon4 /></div></router-link
          ><router-link to="/frame-21">
            <div class="text-search-field-22"><search-icon5 /></div></router-link
          ><textsearchfield8 />
        </div>
        <router-link to="/mob-website-1">
          <div class="group-6810-1"><frame /></div></router-link
        ><img class="vector-38-2" :src="vector38" />
        <div class="overlap-group-6">
          <div class="group-6822 gellix-regular-normal-white-12px">
            <div class="group-6822-item" v-html="twitterFacebook"></div>
            <div class="group-6822-item" v-html="linkedinInstagram"></div>
          </div>
          <img class="vector-35-3" :src="vector35" /><img class="vector-39-2" :src="vector39" /><img
            class="vector-36-2"
            :src="vector36"
          /><img class="vector-37-1" :src="vector37" />
        </div>
        <div class="overlap-group1-2">
          <div class="rectangle-65"></div>
          <div class="search-icon-16">
            <div class="newsletter-sign-up valign-text-middle gellix-regular-normal-white-12px">
              {{ newsletterSignUp }}
            </div>
          </div>
        </div>
      </div>
      <x-nav />
    </div>
  </div>
</template>

<script>
import SearchIcon3 from "./SearchIcon3";
import TEXTSEARCHFIELD7 from "./TEXTSEARCHFIELD7";
import SearchIcon4 from "./SearchIcon4";
import SearchIcon5 from "./SearchIcon5";
import TEXTSEARCHFIELD8 from "./TEXTSEARCHFIELD8";
import Frame from "./Frame";
import XNav from "./XNav";
export default {
  name: "Android23",
  components: {
    SearchIcon3,
    TEXTSEARCHFIELD7,
    SearchIcon4,
    SearchIcon5,
    TEXTSEARCHFIELD8,
    Frame,
    XNav,
  },
  props: [
    "vector38",
    "twitterFacebook",
    "linkedinInstagram",
    "vector35",
    "vector39",
    "vector36",
    "vector37",
    "newsletterSignUp",
  ],
};
</script>

<style>
.android-23 {
  align-items: flex-start;
  display: flex;
  position: relative;
  width: 360px;
}

.overlay .android-23 {
  background-color: #00000000;
}

.overlap-group2-1 {
  height: 640px;
  position: relative;
  width: 297px;
  z-index: 1;
}

.rectangle-251 {
  background-color: var(--blue-violet);
  box-shadow: 3px 4px 12px #5d4dc4;
  height: 640px;
  left: 1px;
  position: absolute;
  top: 0;
  width: 296px;
}

.group-6820 {
  display: flex;
  flex-direction: column;
  height: 227px;
  left: 41px;
  position: absolute;
  top: 127px;
  width: 217px;
}

.text-search-field-19 {
  align-items: center;
  cursor: pointer;
  display: flex;
  height: 35.71px;
  justify-content: center;
  position: relative;
  width: 216.56px;
}

.text-search-field-21 {
  align-items: center;
  cursor: pointer;
  display: flex;
  height: 35.71px;
  justify-content: center;
  margin-left: 42px;
  margin-top: 12.1px;
  position: relative;
  width: 131.76px;
}

.text-search-field-22 {
  align-items: center;
  cursor: pointer;
  display: flex;
  height: 35.71px;
  justify-content: center;
  margin-left: 46px;
  margin-top: 12.1px;
  position: relative;
  width: 124.64px;
}

.group-6810-1 {
  cursor: pointer;
  display: flex;
  height: 30px;
  left: 110px;
  position: absolute;
  top: 19px;
  width: 82px;
}

.vector-38-2 {
  height: 1px;
  left: 0;
  position: absolute;
  top: 64px;
  width: 296px;
}

.overlap-group-6 {
  height: 124px;
  left: 1px;
  position: absolute;
  top: 414px;
  width: 300px;
}

.group-6822 {
  align-items: flex-start;
  display: flex;
  height: 115px;
  left: 0;
  min-width: 300px;
  position: absolute;
  top: 4px;
}

.group-6822-item {
  letter-spacing: 0.48px;
  line-height: 57.2px;
  min-height: 115px;
  text-align: center;
  width: 148px;
}

.vector-35-3 {
  height: 1px;
  left: 0;
  position: absolute;
  top: 0;
  width: 296px;
}

.vector-39-2 {
  height: 1px;
  left: 0;
  position: absolute;
  top: 123px;
  width: 296px;
}

.vector-36-2 {
  height: 1px;
  left: 0;
  position: absolute;
  top: 62px;
  width: 296px;
}

.vector-37-1 {
  height: 123px;
  left: 148px;
  position: absolute;
  top: 0;
  width: 1px;
}

.overlap-group1-2 {
  height: 47px;
  left: 29px;
  position: absolute;
  top: 567px;
  width: 242px;
}

.rectangle-65 {
  background-color: var(--biloba-flower-2);
  border-radius: 8px;
  height: 47px;
  left: 19px;
  position: absolute;
  top: 0;
  width: 201px;
}

.search-icon-16 {
  align-items: center;
  display: flex;
  height: 18px;
  justify-content: center;
  left: 0;
  position: absolute;
  top: 15px;
  width: 242px;
}

.newsletter-sign-up {
  height: 18.4px;
  letter-spacing: 0.6px;
  line-height: 14.5px;
  margin-left: -2px;
  text-align: center;
  width: 239.73px;
}

#overlay-android-23 {
  background-color: transparent;
}
</style>
