import React from "react";
import { Link } from "react-router-dom";
import Group6813 from "../Group6813";
import Textsearchfield from "../Textsearchfield";
import Group6839 from "../Group6839";
import Textsearchfield2 from "../Textsearchfield2";
import Textsearchfield3 from "../Textsearchfield3";
import Group6840 from "../Group6840";
import Frame6 from "../Frame6";
import Group6810 from "../Group6810";
import Group6825 from "../Group6825";
import "./Android25.css";

function Android25(props) {
  const {
    polygon1,
    partnersOfEma,
    getInvolvedWithEma,
    spanText,
    spanText2,
    spanText3,
    spanText4,
    spanText5,
    spanText6,
    group6840,
    vector35,
    vector36,
    textsearchfieldProps,
    group6839Props,
    group6840Props,
    frame6Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="android-25 screen">
        <div className="overlap-group7-1">
          <div className="rectangle-250-1"></div>
          <div className="group-6817">
            <div className="group-6811">
              <img className="polygon-1" src={polygon1} />
            </div>
          </div>
          <div className="overlap-group-9">
            <Group6813 />
            <div className="text-search-field-27">
              <div className="search-icon-27">
                <p className="partners-of-ema valign-text-middle gellix-regular-normal-minsk-12px">{partnersOfEma}</p>
              </div>
            </div>
          </div>
          <div className="overlap-group1-3">
            <Group6813 />
            <div className="text-search-field-28">
              <div className="search-icon-28">
                <p className="get-involved-with-ema valign-text-middle gellix-regular-normal-minsk-12px">
                  {getInvolvedWithEma}
                </p>
              </div>
            </div>
          </div>
          <div className="mission-and-vision-t">
            <span className="span0">{spanText}</span>
            <span className="span1">{spanText2}</span>
          </div>
          <div className="overlap-group2-2">
            <Group6813 />
            <Textsearchfield>{textsearchfieldProps.children}</Textsearchfield>
          </div>
          <div className="group-6838-1">
            <div className="group-container-1">
              <div className="overlap-group4">
                <div className="text-search-field-29">
                  <div className="search-icon-29">
                    <Link to="/android-25">
                      <p className="about-us-mission-v-1 gellix-regular-normal-white-12px-2">
                        <span className="span-13 gellix-regular-normal-white-12px">{spanText3}</span>
                        <span className="span-13 gellix-regular-normal-dull-lavender-12px">{spanText4}</span>
                      </p>
                    </Link>
                    <div className="news-latest-news-newsletter-gallery gellix-regular-normal-white-12px-2">
                      <span className="span-13 gellix-regular-normal-white-12px">{spanText5}</span>
                      <span className="span-13 gellix-regular-normal-dull-lavender-12px">{spanText6}</span>
                    </div>
                  </div>
                </div>
                <Group6839
                  vector41={group6839Props.vector41}
                  vector42={group6839Props.vector42}
                  tEXTSEARCHFIELD4Props={group6839Props.tEXTSEARCHFIELD4Props}
                />
              </div>
              <div className="text-search-field-container-2">
                <Textsearchfield2 />
                <Textsearchfield3 />
              </div>
              <Group6840
                tEXTSEARCHFIELD5Props={group6840Props.tEXTSEARCHFIELD5Props}
                tEXTSEARCHFIELD52Props={group6840Props.tEXTSEARCHFIELD52Props}
              />
            </div>
          </div>
          <div className="group-6840" style={{ backgroundImage: `url(${group6840})` }}></div>
          <Frame6 className={frame6Props.className} />
        </div>
        <a href="javascript:ShowOverlay('android-23', 'animate-appear');">
          <div className="nav-3">
            <div className="group-container-2">
              <div className="group-6808-3">
                <div className="overlap-group-10">
                  <div className="group-6806-2"></div>
                  <img className="vector-35-6" src={vector35} />
                  <img className="vector-36-5" src={vector36} />
                </div>
              </div>
              <Group6810 />
            </div>
          </div>
        </a>
        <Group6825 />
      </div>
    </div>
  );
}

export default Android25;
