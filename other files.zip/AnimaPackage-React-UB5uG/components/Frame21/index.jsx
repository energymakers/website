import React from "react";
import { Link } from "react-router-dom";
import Frame6 from "../Frame6";
import "./Frame21.css";

function Frame21(props) {
  const {
    spanText,
    spanText2,
    spanText3,
    spanText4,
    spanText5,
    spanText6,
    spanText7,
    spanText8,
    spanText9,
    spanText10,
    spanText11,
    spanText12,
    spanText13,
    spanText14,
    spanText15,
    ema326JosephMwil,
    programmesUniversit,
    socialMediaFaceb,
    frame6Props,
  } = props;

  return (
    <div className="container-center-horizontal">
      <div className="frame-21 screen">
        <a href="javascript:ShowOverlay('android-23', 'animate-appear');">
          <div className="nav-6">
            <div className="overlap-group4-3">
              <div className="overlap-group-26">
                <div className="rectangle-236"></div>
                <div className="group-6806-4"></div>
                <img className="vector-35-12" src="/img/vector-35-10@2x.svg" />
                <img className="vector-36-9" src="/img/vector-36-2@2x.svg" />
              </div>
              <div className="frame-5">
                <img className="vector-48" src="/img/vector-5@2x.svg" />
              </div>
            </div>
          </div>
        </a>
        <div className="overlap-group5-1">
          <div className="group-6841-1">
            <div className="overlap-group3-4 gellix-regular-normal-white-12px-2">
              <div className="group-6815">
                <Link to="/android-25">
                  <p className="about-us-mission-v-7 gellix-regular-normal-white-12px-2">
                    <span className="span-20 gellix-regular-normal-white-12px">{spanText}</span>
                    <span className="span-20 gellix-regular-normal-dull-lavender-12px">{spanText2}</span>
                  </p>
                </Link>
                <div className="news-latest-news-newsletter-gallery-3 gellix-regular-normal-white-12px-2">
                  <span className="span-20 gellix-regular-normal-white-12px">{spanText3}</span>
                  <span className="span-20 gellix-regular-normal-dull-lavender-12px">{spanText4}</span>
                </div>
              </div>
              <p className="programmes-programme-2">
                <span className="span-20 gellix-regular-normal-white-12px">{spanText5}</span>
                <span className="span-20 gellix-regular-normal-dull-lavender-12px">{spanText6}</span>
                <span className="span-20 gellix-regular-normal-white-12px">{spanText7}</span>
                <span className="span-20 gellix-regular-normal-dull-lavender-12px">{spanText8}</span>
              </p>
              <p className="social-media-faceb-4">
                <span className="span-20 gellix-regular-normal-white-12px">{spanText9}</span>
                <span className="span-20 gellix-regular-normal-dull-lavender-12px">{spanText10}</span>
              </p>
              <div className="overlap-group-27">
                <p className="ema-326-joseph-mwil-4">
                  <span className="span-20 gellix-regular-normal-white-12px">{spanText11}</span>
                  <span className="span-20 gellix-regular-normal-dull-lavender-12px">{spanText12}</span>
                </p>
                <img className="vector-41-7" src="/img/vector-41@2x.svg" />
                <img className="vector-42-7" src="/img/vector-42@2x.svg" />
              </div>
              <div className="group-6840-6">
                <div className="overlap-group1-10">
                  <p className="about-us-mission-v-8">
                    <span className="span-20 gellix-regular-normal-white-12px">{spanText13}</span>
                    <span className="span-20 gellix-regular-normal-tasman-12px">{spanText14}</span>
                    <span className="span-20 gellix-regular-normal-white-12px">{spanText15}</span>
                  </p>
                  <div className="overlap-group-28">
                    <p className="ema-326-joseph-mwil-7 gellix-regular-normal-white-12px">{ema326JosephMwil}</p>
                    <img className="vector-41-7" src="/img/vector-41-8@2x.svg" />
                    <img className="vector-42-7" src="/img/vector-42-8@2x.svg" />
                  </div>
                </div>
                <div className="overlap-group2-5 gellix-regular-normal-white-12px">
                  <p className="programmes-universit-1">{programmesUniversit}</p>
                  <p className="social-media-faceb-7">{socialMediaFaceb}</p>
                </div>
              </div>
            </div>
          </div>
          <div className="group-6842-1"></div>
          <Frame6 className={frame6Props.className} />
        </div>
      </div>
    </div>
  );
}

export default Frame21;
