<template>
  <div class="vector-12"><img class="vector-13" :src="src" /></div>
</template>

<script>
export default {
  name: "Vector",
  props: ["src"],
};
</script>

<style>
.vector-12 {
  align-items: center;
  display: flex;
  height: 33px;
  left: 45px;
  min-width: 33px;
  padding: 0 16.2px;
  position: absolute;
  top: 157px;
}

.vector-13 {
  height: 1px;
  width: 1px;
}
</style>
