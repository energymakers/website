import React from "react";
import "./Vector32.css";

function Vector32(props) {
  const { src } = props;

  return <div className="vector-47" style={{ backgroundImage: `url(${src})` }}></div>;
}

export default Vector32;
