<template>
  <div class="search-icon-21"><div class="about valign-text-middle gellix-regular-normal-white-18px">ABOUT</div></div>
</template>

<script>
export default {
  name: "SearchIcon4",
};
</script>

<style>
.search-icon-21,
.search-icon-22 {
  align-items: center;
  display: flex;
  justify-content: center;
  margin-left: 1.5px;
  margin-top: 0.5px;
  width: 132.96px;
}

.about,
.about-1 {
  height: 20.13px;
  letter-spacing: 0.9px;
  line-height: 14.5px;
  margin-left: -2px;
  text-align: center;
  width: 130.96px;
}
</style>
