import React from "react";
import "./Vector3.css";

function Vector3(props) {
  const { src } = props;

  return (
    <div className="vector-17">
      <img className="vector-18" src={src} />
    </div>
  );
}

export default Vector3;
