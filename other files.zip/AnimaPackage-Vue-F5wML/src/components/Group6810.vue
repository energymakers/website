<template>
  <div class="group-6810-2"><frame /></div>
</template>

<script>
import Frame from "./Frame";
export default {
  name: "Group6810",
  components: {
    Frame,
  },
};
</script>

<style>
.group-6810-2 {
  display: flex;
  height: 30px;
  left: 18px;
  position: absolute;
  top: 19px;
  width: 82px;
}
</style>
