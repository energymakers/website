<template>
  <div :class="[`text-search-field-30`, className || ``]">
    <div class="search-icon-31">
      <p class="meet-the-ema-team valign-text-middle gellix-regular-normal-minsk-12px">{{ children }}</p>
    </div>
  </div>
</template>

<script>
export default {
  name: "Textsearchfield",
  props: ["children", "className"],
};
</script>

<style>
.text-search-field-30 {
  align-items: center;
  background-color: var(--biloba-flower);
  border-radius: 8px;
  display: flex;
  height: 47px;
  justify-content: center;
  left: 1px;
  position: absolute;
  top: 263px;
  width: 201px;
}

.search-icon-31 {
  align-items: center;
  display: flex;
  justify-content: center;
  margin-left: 2.4px;
  margin-top: 0.7px;
  width: 178.27px;
}

.meet-the-ema-team {
  height: 18.4px;
  letter-spacing: 0.6px;
  line-height: 14.5px;
  margin-left: -2px;
  text-align: center;
  width: 176.27px;
}

.text-search-field-30.text-search-field-31 {
  background-color: var(--shamrock);
  left: unset;
  margin-right: 14.68px;
  margin-top: 25px;
  position: unset;
  top: unset;
}

.text-search-field-30.text-search-field-32 {
  background-color: var(--shamrock);
  left: unset;
  margin-left: 57.2px;
  margin-top: 34px;
  position: unset;
  top: unset;
  width: 200.97px;
}
</style>
