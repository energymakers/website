import React from "react";
import "./Vector5.css";

function Vector5(props) {
  const { src, className } = props;

  return (
    <div className={`vector-22 ${className || ""}`}>
      <img className="vector-23" src={src} />
    </div>
  );
}

export default Vector5;
