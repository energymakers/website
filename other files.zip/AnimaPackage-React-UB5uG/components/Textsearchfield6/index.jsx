import React from "react";
import "./Textsearchfield6.css";

function Textsearchfield6(props) {
  const { className } = props;

  return (
    <div className={`text-search-field-40 ${className || ""}`}>
      <div className="search-icon-39">
        <p className="social-media-faceb-2 gellix-regular-normal-white-12px">
          SOCIAL MEDIA
          <br />↗ Facebook
          <br />↗ Twitter
          <br />↗ LinkedIn
          <br />↗ YouTube
          <br />↗ Instagram
        </p>
      </div>
    </div>
  );
}

export default Textsearchfield6;
